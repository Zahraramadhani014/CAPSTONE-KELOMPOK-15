package dao;

import java.math.BigDecimal;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class TagihanDao {

    // --- DTO kecil untuk dipakai layar pembayaran ---
    public static final class UnpaidBill {

        public final int idTagihan;
        public final BigDecimal total;

        public UnpaidBill(int idTagihan, BigDecimal total) {
            this.idTagihan = idTagihan;
            this.total = total;
        }
    }

    private static final String SQL_FIND_LATEST_UNPAID_BY_NIK = """
        SELECT t.id_tagihan, t.total_tagihan
        FROM tagihan_bulanan t
        JOIN rumah r  ON r.id_rumah     = t.RUMAH_id_rumah
        JOIN warga w  ON w.id_user      = r.USER_id_user  -- <== penting: join pakai id_user
        WHERE w.nik = ? AND t.status_tagihan = 'BELUM LUNAS'
        ORDER BY STR_TO_DATE(CONCAT(t.periode,'-01'), '%Y-%m-%d') DESC, t.id_tagihan DESC
        LIMIT 1
    """;

    /**
     * Ambil 1 tagihan terbaru yang statusnya BELUM LUNAS untuk NIK tertentu.
     */
    public UnpaidBill findLatestUnpaidByNik(String nik) throws SQLException {
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_FIND_LATEST_UNPAID_BY_NIK)) {
            ps.setString(1, nik);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new UnpaidBill(rs.getInt(1), rs.getBigDecimal(2));
                }
                return null;
            }
        }
    }

    // ====== (opsional) fungsi bantu debugging cepat ======
    /**
     * Cek: ada berapa tagihan BELUM LUNAS untuk NIK ini menurut join.
     */
    public int countUnpaidByNik(String nik) throws SQLException {
        final String sql = """
            SELECT COUNT(*)
            FROM tagihan_bulanan t
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN warga w ON w.id_user  = r.USER_id_user
            WHERE w.nik = ? AND t.status_tagihan='BELUM LUNAS'
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nik);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    /**
     * Cek: list semua tagihan milik NIK ini (status apa pun) untuk verifikasi
     * relasi.
     */
    public ResultSet listAllByNik(Connection c, String nik) throws SQLException {
        final String sql = """
            SELECT t.id_tagihan, t.periode, t.status_tagihan, t.total_tagihan, r.id_rumah, r.USER_id_user, w.id_user, w.nik
            FROM tagihan_bulanan t
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN warga w ON w.id_user  = r.USER_id_user
            WHERE w.nik = ?
            ORDER BY t.periode DESC, t.id_tagihan DESC
        """;
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, nik);
        return ps.executeQuery(); // panggil lalu println di tempat kamu jika perlu
    }

    /* ==========================
       UTIL / LOOKUP
       ========================== */
    /**
     * Ambil total_tagihan berdasar id_tagihan.
     */
    public BigDecimal getTotalById(int idTagihan) throws SQLException {
        final String sql = "SELECT total_tagihan FROM tagihan_bulanan WHERE id_tagihan = ?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTagihan);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBigDecimal(1) : null;
            }
        }
    }

    /**
     * Set status tagihan jadi LUNAS.
     */
    public int updateStatusLunas(int idTagihan) throws SQLException {
        final String sql = "UPDATE tagihan_bulanan SET status_tagihan='LUNAS' WHERE id_tagihan=?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTagihan);
            return ps.executeUpdate();
        }
    }

    /**
     * Ambil id_rumah dari id_tagihan (berguna saat tambah/clone).
     */
    public Integer findRumahIdByIdTagihan(int idTagihan) throws SQLException {
        final String sql = "SELECT RUMAH_id_rumah FROM tagihan_bulanan WHERE id_tagihan = ?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTagihan);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : null;
            }
        }
    }

    /* ==========================
       LISTING
      ========================== */
    /**
     * Daftar tagihan milik 1 warga (filter by NIK). Hasil siap ke JTable.
     */
    public DefaultTableModel listTagihanByNik(String nik) throws SQLException {
        final String sql
                = "SELECT t.id_tagihan, t.periode, t.total_kwh, t.tarif_per_kwh, "
                + "       t.total_tagihan, t.status_tagihan "
                + "FROM tagihan_bulanan t "
                + "JOIN rumah  r ON r.id_rumah  = t.RUMAH_id_rumah "
                + "JOIN warga  w ON w.id_user   = r.USER_id_user "
                + "WHERE w.nik = ? "
                + "ORDER BY t.periode DESC, t.id_tagihan DESC";

        String[] cols = {"id_tagihan", "periode", "total_kwh", "tarif_per_kwh", "total_tagihan", "status_tagihan"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, nik);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id_tagihan"),
                        rs.getString("periode"),
                        rs.getBigDecimal("total_kwh"),
                        rs.getBigDecimal("tarif_per_kwh"),
                        rs.getBigDecimal("total_tagihan"),
                        rs.getString("status_tagihan")
                    });
                }
            }
        }
        return model;
    }

    /**
     * Daftar tagihan yang boleh dilihat petugas komunitas (berdasarkan id_user
     * petugas).
     */
    public DefaultTableModel loadTableByKomunitasPetugas(String idUserPetugas) throws SQLException {
        String[] cols = {"id_tagihan", "periode", "total_kwh", "tarif_per_kwh", "total_tagihan", "status_tagihan"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql = """
            SELECT t.id_tagihan, t.periode, t.total_kwh, t.tarif_per_kwh, t.total_tagihan, t.status_tagihan
            FROM tagihan_bulanan t
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE ak.id_user = ?
            ORDER BY t.id_tagihan
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getBigDecimal(3),
                        rs.getBigDecimal(4), rs.getBigDecimal(5), rs.getString(6)
                    });
                }
            }
        }
        return m;
    }

    /**
     * Daftar tagihan untuk SUPERADMIN (full).
     */
    public DefaultTableModel loadTableForAdmin() throws SQLException {
        String[] cols = {"id_tagihan", "periode", "total_kwh", "tarif_per_kwh", "total_tagihan", "status_tagihan"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql = """
            SELECT id_tagihan, periode, total_kwh, tarif_per_kwh, total_tagihan, status_tagihan
            FROM tagihan_bulanan
            ORDER BY id_tagihan
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1), rs.getString(2), rs.getBigDecimal(3),
                    rs.getBigDecimal(4), rs.getBigDecimal(5), rs.getString(6)
                });
            }
        }
        return m;
    }

    /* ==========================
       INSERT / UPDATE / DELETE
       (dibatasi komunitas petugas)
       ========================== */
    /**
     * Tambah tagihan (PETUGAS) untuk id_rumah yang berada di komunitasnya. Jika
     * totalTagihanOrNull = null dan total_kwh & tarif_per_kwh tersedia,
     * dihitung otomatis.
     */
    public int insertByPetugas(
            int idTagihan,
            String periode,
            BigDecimal totalKwh,
            BigDecimal tarifPerKwh,
            BigDecimal totalTagihanOrNull,
            String statusTagihan,
            int idRumah,
            String idUserPetugas
    ) throws SQLException {

        BigDecimal total = totalTagihanOrNull;
        if (total == null && totalKwh != null && tarifPerKwh != null) {
            total = totalKwh.multiply(tarifPerKwh);
        }

        final String sql = """
            INSERT INTO tagihan_bulanan
                (id_tagihan, periode, total_kwh, tarif_per_kwh, total_tagihan, status_tagihan, RUMAH_id_rumah)
            SELECT ?, ?, ?, ?, ?, ?, r.id_rumah
            FROM rumah r
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE r.id_rumah = ? AND ak.id_user = ?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, idTagihan);
            ps.setString(i++, periode);
            ps.setBigDecimal(i++, totalKwh);
            ps.setBigDecimal(i++, tarifPerKwh);
            ps.setBigDecimal(i++, total);
            ps.setString(i++, statusTagihan);
            ps.setInt(i++, idRumah);          // guard komunitas
            ps.setString(i, idUserPetugas);  // guard komunitas
            return ps.executeUpdate();
        }
    }

    /**
     * Perbarui tagihan (PETUGAS), dibatasi komunitas. total_tagihan auto
     * dihitung bila null.
     */
    public int updateByPetugas(
            int idTagihan,
            String periode,
            BigDecimal totalKwh,
            BigDecimal tarifPerKwh,
            BigDecimal totalTagihanOrNull,
            String statusTagihan,
            String idUserPetugas
    ) throws SQLException {

        BigDecimal total = totalTagihanOrNull;
        if (total == null && totalKwh != null && tarifPerKwh != null) {
            total = totalKwh.multiply(tarifPerKwh);
        }

        final String sql = """
            UPDATE tagihan_bulanan t
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            SET t.periode = ?, t.total_kwh = ?, t.tarif_per_kwh = ?, t.total_tagihan = ?, t.status_tagihan = ?
            WHERE t.id_tagihan = ? AND ak.id_user = ?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, periode);
            ps.setBigDecimal(i++, totalKwh);
            ps.setBigDecimal(i++, tarifPerKwh);
            ps.setBigDecimal(i++, total);
            ps.setString(i++, statusTagihan);
            ps.setInt(i++, idTagihan);
            ps.setString(i, idUserPetugas);
            return ps.executeUpdate();
        }
    }

    /**
     * Hapus tagihan (PETUGAS), dibatasi komunitas.
     */
    public int deleteByPetugas(int idTagihan, String idUserPetugas) throws SQLException {
        final String sql = """
            DELETE t FROM tagihan_bulanan t
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE t.id_tagihan = ? AND ak.id_user = ?
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTagihan);
            ps.setString(2, idUserPetugas);
            return ps.executeUpdate();
        }
    }

    /* ==========================
       CRUD SUPERADMIN (opsional)
       ========================== */
    /**
     * Ambil id berikutnya: MAX(id)+1.
     */
    public int nextId() throws SQLException {
        final String sql = "SELECT COALESCE(MAX(id_tagihan),0)+1 FROM tagihan_bulanan";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public int insertAdmin(int idTagihan, String periode,
            BigDecimal totalKwh, BigDecimal tarifPerKwh,
            BigDecimal totalTagihan, String statusTagihan,
            int idRumah) throws SQLException {
        final String sql = """
            INSERT INTO tagihan_bulanan
              (id_tagihan, periode, total_kwh, tarif_per_kwh, total_tagihan, status_tagihan, RUMAH_id_rumah)
            VALUES (?,?,?,?,?,?,?)
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, idTagihan);
            ps.setString(i++, periode);
            ps.setBigDecimal(i++, totalKwh);
            ps.setBigDecimal(i++, tarifPerKwh);
            ps.setBigDecimal(i++, totalTagihan);
            ps.setString(i++, statusTagihan);
            ps.setInt(i++, idRumah);
            return ps.executeUpdate();
        }
    }

    public int updateAdmin(int idTagihan, String periode,
            BigDecimal totalKwh, BigDecimal tarifPerKwh,
            BigDecimal totalTagihan, String statusTagihan) throws SQLException {
        final String sql = """
            UPDATE tagihan_bulanan
               SET periode=?, total_kwh=?, tarif_per_kwh=?, total_tagihan=?, status_tagihan=?
             WHERE id_tagihan=?
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, periode);
            ps.setBigDecimal(i++, totalKwh);
            ps.setBigDecimal(i++, tarifPerKwh);
            ps.setBigDecimal(i++, totalTagihan);
            ps.setString(i++, statusTagihan);
            ps.setInt(i++, idTagihan);
            return ps.executeUpdate();
        }
    }

    public int deleteAdmin(int idTagihan) throws SQLException {
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM tagihan_bulanan WHERE id_tagihan=?")) {
            ps.setInt(1, idTagihan);
            return ps.executeUpdate();
        }
    }
}
