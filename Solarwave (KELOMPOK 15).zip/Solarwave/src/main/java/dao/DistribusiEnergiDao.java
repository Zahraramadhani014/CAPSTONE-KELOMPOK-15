package dao;

import java.math.BigDecimal;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class DistribusiEnergiDao {

    /* ======================
       VIEW: SUPERADMIN (FULL)
       ====================== */
    public DefaultTableModel loadTableForAdmin() throws SQLException {
        String[] cols = {
            "id_distribusi", "tanggal_distribusi", "pemakaian_kwh",
            "biaya_per_kwh", "catatan", "RUMAH_id_rumah"
        };
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql = """
            SELECT id_distribusi, tanggal_distribusi, pemakaian_kwh,
                   biaya_per_kwh, catatan, RUMAH_id_rumah
            FROM distribusi_energi
            ORDER BY id_distribusi
        """;

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1), rs.getDate(2), rs.getBigDecimal(3),
                    rs.getBigDecimal(4), rs.getString(5), rs.getInt(6)
                });
            }
        }
        return m;
    }

    /* ======================
       VIEW: PETUGAS (TERBATAS)
       ====================== */
    public DefaultTableModel loadTableByKomunitasPetugas(String idUserPetugas) throws SQLException {
        String[] cols = {"id_distribusi","tanggal_distribusi","pemakaian_kwh","biaya_per_kwh","catatan"};
        DefaultTableModel m = new DefaultTableModel(cols, 0){
            @Override public boolean isCellEditable(int r,int c){ return false; }
        };

        final String sql = """
            SELECT d.id_distribusi, d.tanggal_distribusi, d.pemakaian_kwh, d.biaya_per_kwh, d.catatan
            FROM distribusi_energi d
            JOIN rumah r ON r.id_rumah = d.RUMAH_id_rumah
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE ak.id_user = ?
            ORDER BY d.id_distribusi
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getInt(1), rs.getDate(2), rs.getBigDecimal(3),
                        rs.getBigDecimal(4), rs.getString(5)
                    });
                }
            }
        }
        return m;
    }

    /* ======================
       INSERT / UPDATE / DELETE
       ====================== */

    public int insertByPetugas(int id, Date tgl, BigDecimal kwh, BigDecimal biaya,
                               String catatan, int idRumah, String idUserPetugas) throws SQLException {
        final String sql = """
            INSERT INTO distribusi_energi
                (id_distribusi, tanggal_distribusi, pemakaian_kwh, biaya_per_kwh, catatan, RUMAH_id_rumah)
            SELECT ?, ?, ?, ?, ?, r.id_rumah
            FROM rumah r
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE r.id_rumah = ? AND ak.id_user = ?
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, id);
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i++, idRumah);
            ps.setString(i,   idUserPetugas);
            return ps.executeUpdate();
        }
    }

    public int updateByPetugas(int idDistribusi, Date tgl, BigDecimal kwh, BigDecimal biaya,
                               String catatan, String idUserPetugas) throws SQLException {
        final String sql =
            "UPDATE distribusi_energi de " +
            "JOIN rumah r ON r.id_rumah = de.RUMAH_id_rumah " +
            "JOIN (SELECT KOMUNITAS_id_komunitas FROM anggota_komunitas WHERE id_user=? LIMIT 1) ak " +
            "  ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "SET de.tanggal_distribusi = ?, de.pemakaian_kwh = ?, de.biaya_per_kwh = ?, de.catatan = ? " +
            "WHERE de.id_distribusi = ?";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, idUserPetugas);
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i,   idDistribusi);
            return ps.executeUpdate();
        }
    }

    public int deleteByPetugas(int idDistribusi, String idUserPetugas) throws SQLException {
        final String sql =
            "DELETE de " +
            "FROM distribusi_energi de " +
            "JOIN rumah r ON r.id_rumah = de.RUMAH_id_rumah " +
            "JOIN (SELECT KOMUNITAS_id_komunitas FROM anggota_komunitas WHERE id_user=? LIMIT 1) ak " +
            "  ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "WHERE de.id_distribusi = ?";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            ps.setInt(2, idDistribusi);
            return ps.executeUpdate();
        }
    }

    /* === CRUD untuk SUPERADMIN (konsisten BigDecimal) === */
    
    /** Ambil id_distribusi berikutnya (karena PK tidak AUTO_INCREMENT). */
    public int nextDistribusiId() throws SQLException {
        final String sql = "SELECT COALESCE(MAX(id_distribusi), 0) + 1 FROM distribusi_energi";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public int insertAdmin(int id, Date tgl, BigDecimal kwh, BigDecimal biaya,
                           String catatan, int idRumah) throws SQLException {
        final String sql = """
            INSERT INTO distribusi_energi
                (id_distribusi, tanggal_distribusi, pemakaian_kwh, biaya_per_kwh, catatan, RUMAH_id_rumah)
            VALUES (?, ?, ?, ?, ?, ?)
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, id);
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i,   idRumah);
            return ps.executeUpdate();
        }
    }

    public int updateAdmin(int id, Date tgl, BigDecimal kwh, BigDecimal biaya,
                           String catatan) throws SQLException {
        final String sql = """
            UPDATE distribusi_energi
            SET tanggal_distribusi=?, pemakaian_kwh=?, biaya_per_kwh=?, catatan=?
            WHERE id_distribusi=?
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i,   id);
            return ps.executeUpdate();
        }
    }

    public int deleteAdmin(int id) throws SQLException {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "DELETE FROM distribusi_energi WHERE id_distribusi=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }
}
