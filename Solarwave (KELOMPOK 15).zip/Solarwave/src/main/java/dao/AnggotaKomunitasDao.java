package dao;

import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class AnggotaKomunitasDao {

    /**
     * === AMBIL SEMUA DATA (Super Admin view) ===
     */
    public DefaultTableModel loadTableModelForAdmin() throws SQLException {
        String[] cols = {
            "id_user", "nama", "no_kartu_anggota", "alamat", "no_telepon",
            "email", "area_tanggung_jawab", "tanggal_bergabung",
            "username", "password"
        };

        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        String sql = """
            SELECT u.id_user, u.nama, ak.no_kartu_anggota, u.alamat, u.no_telepon,
                   u.email, ak.area_tanggung_jawab, ak.tanggal_bergabung,
                   u.username, u.password
            FROM user u
            JOIN anggota_komunitas ak ON ak.id_user = u.id_user
            ORDER BY u.id_user
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_user"),
                    rs.getString("nama"),
                    rs.getString("no_kartu_anggota"),
                    rs.getString("alamat"),
                    rs.getString("no_telepon"),
                    rs.getString("email"),
                    rs.getString("area_tanggung_jawab"),
                    rs.getDate("tanggal_bergabung"),
                    rs.getString("username"),
                    rs.getString("password")
                });
            }
        }
        return model;
    }

    public String nextUserId() throws java.sql.SQLException {
        final String sql = "SELECT MAX(CAST(SUBSTRING(id_user,4) AS UNSIGNED)) FROM user";
        try (java.sql.Connection c = DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {
            int last = 0;
            if (rs.next()) {
                last = rs.getInt(1);
            }
            return String.format("USR%03d", last + 1);
        }
    }

    /**
     * === TAMBAH BARU (user + anggota_komunitas) ===
     */
    public int insertAnggota(
            String idUser, String nama, String alamat, String noTelp, String email,
            String username, String password,
            String noKartu, String area, java.sql.Date tglBergabung /* boleh null */,
            int idKomunitas
    ) throws java.sql.SQLException {

        final String sqlUser
                = "INSERT INTO user (id_user, nama, alamat, no_telepon, email, username, password, role) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, 'ANGGOTA_KOMUNITAS')";

        final String sqlAnggota
                = "INSERT INTO anggota_komunitas "
                + "(id_user, no_kartu_anggota, area_tanggung_jawab, tanggal_bergabung, KOMUNITAS_id_komunitas) "
                + "VALUES (?, ?, ?, COALESCE(?, CURRENT_DATE), ?)";

        try (java.sql.Connection c = DB.getConnection()) {
            c.setAutoCommit(false);
            try (java.sql.PreparedStatement pu = c.prepareStatement(sqlUser); java.sql.PreparedStatement pa = c.prepareStatement(sqlAnggota)) {

                // user
                pu.setString(1, idUser);
                pu.setString(2, nama);
                pu.setString(3, alamat);
                pu.setString(4, noTelp);
                pu.setString(5, email);
                pu.setString(6, username);
                pu.setString(7, password);
                pu.executeUpdate();

                // anggota_komunitas
                pa.setString(1, idUser);
                pa.setString(2, noKartu);
                pa.setString(3, area);
                if (tglBergabung == null) {
                    pa.setNull(4, java.sql.Types.DATE);
                } else {
                    pa.setDate(4, tglBergabung);
                }
                pa.setInt(5, idKomunitas);
                int ok = pa.executeUpdate();

                c.commit();
                return ok;
            } catch (Exception ex) {
                c.rollback();
                throw ex;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    /**
     * === UPDATE (gabungan user + anggota_komunitas) ===
     */
    public int updateAnggota(
            String idUser, String nama, String alamat, String noTelp, String email,
            String username, String newPasswordOrNull,
            String noKartu, String area, java.sql.Date tglBergabungOrNull
    ) throws java.sql.SQLException {

        final String sqlUser
                = "UPDATE user SET nama=?, alamat=?, no_telepon=?, email=?, username=? "
                + (newPasswordOrNull != null ? ", password=? " : " ")
                + "WHERE id_user=?";

        final String sqlAnggota
                = "UPDATE anggota_komunitas SET no_kartu_anggota=?, area_tanggung_jawab=? "
                + (tglBergabungOrNull != null ? ", tanggal_bergabung=? " : " ")
                + "WHERE id_user=?";

        try (java.sql.Connection c = DB.getConnection()) {
            c.setAutoCommit(false);
            try (java.sql.PreparedStatement pu = c.prepareStatement(sqlUser); java.sql.PreparedStatement pa = c.prepareStatement(sqlAnggota)) {

                int i = 1;
                pu.setString(i++, nama);
                pu.setString(i++, alamat);
                pu.setString(i++, noTelp);
                pu.setString(i++, email);
                pu.setString(i++, username);
                if (newPasswordOrNull != null) {
                    pu.setString(i++, newPasswordOrNull);
                }
                pu.setString(i, idUser);
                pu.executeUpdate();

                int j = 1;
                pa.setString(j++, noKartu);
                pa.setString(j++, area);
                if (tglBergabungOrNull != null) {
                    pa.setDate(j++, tglBergabungOrNull);
                }
                pa.setString(j, idUser);
                int ok = pa.executeUpdate();

                c.commit();
                return ok;
            } catch (Exception ex) {
                c.rollback();
                throw ex;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    /**
     * === HAPUS (hapus anggota_komunitas + user) ===
     */
    public int deleteByIdUser(String idUser) throws SQLException {
        try (Connection c = DB.getConnection()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);

            try {
                int count = 0;
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM anggota_komunitas WHERE id_user=?")) {
                    ps.setString(1, idUser);
                    count += ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM user WHERE id_user=?")) {
                    ps.setString(1, idUser);
                    count += ps.executeUpdate();
                }

                c.commit();
                c.setAutoCommit(old);
                return count;

            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }
}
