package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Model.AuthUser;

public class UserDao {

    public AuthUser login(String username, String password) throws SQLException {
        String sql = "SELECT u.id_user, u.username, u.role, w.nik " +
                     "FROM `user` u LEFT JOIN warga w ON w.id_user = u.id_user " +
                     "WHERE u.username=? AND u.password=? LIMIT 1";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                Model.AuthUser au = new Model.AuthUser();
                au.setIdUser(rs.getString("id_user"));
                au.setUsername(rs.getString("username"));
                au.setRole(rs.getString("role"));
                au.setNik(rs.getString("nik")); // bisa null
                return au;
            }
        }
    }
}
