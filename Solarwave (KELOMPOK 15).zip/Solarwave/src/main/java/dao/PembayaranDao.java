package dao;

import javax.swing.table.DefaultTableModel;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PembayaranDao {

    /* =========================================================
       UTIL
       ========================================================= */

    /** Generator ID INT sederhana: ambil MAX(pk) + 1. */
    private int nextIntId(Connection c, String table, String pk) throws SQLException {
        String sql = "SELECT COALESCE(MAX(" + pk + "),0) + 1 AS next_id FROM " + table;
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getInt("next_id");
        }
    }

    /* =========================================================
       INSERT (mode warga/petugas) + auto set tagihan LUNAS
       ========================================================= */

    /**
     * Insert pembayaran + set tagihan jadi LUNAS.
     * (Tidak memakai kolom tanggal_lunas karena tidak ada di tabel.)
     */
    public void insert(Connection c, String nik, int idTagihan,
                       BigDecimal jumlah, String metode) throws SQLException {

        boolean oldAuto = c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            int idBaru = nextIntId(c, "pembayaran", "id_pembayaran");

            // 1) INSERT pembayaran
            String sql = "INSERT INTO pembayaran "
                    + "(id_pembayaran, tanggal_pembayaran, metode_pembayaran, jumlah_bayar, "
                    + " status_pembayaran, TAGIHAN_BULANAN_id_tagihan, WARGA_nik) "
                    + "VALUES (?, NOW(), ?, ?, 'LUNAS', ?, ?)";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, idBaru);
                ps.setString(2, metode);
                ps.setBigDecimal(3, jumlah);
                ps.setInt(4, idTagihan);
                ps.setString(5, nik);
                ps.executeUpdate();
            }

            // 2) UPDATE status tagihan -> LUNAS
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE tagihan_bulanan SET status_tagihan='LUNAS' WHERE id_tagihan=?")) {
                ps.setInt(1, idTagihan);
                ps.executeUpdate();
            }

            c.commit();
        } catch (SQLException ex) {
            c.rollback();
            throw ex;
        } finally {
            c.setAutoCommit(oldAuto);
        }
    }

    /* =========================================================
       LIST / RIWAYAT (warga)
       ========================================================= */

    /** Ambil riwayat pembayaran berdasarkan NIK (string ringkas). */
    public List<String> findRiwayatByNik(String nik) throws SQLException {
        String sql = "SELECT id_pembayaran, tanggal_pembayaran, metode_pembayaran, jumlah_bayar "
                   + "FROM pembayaran WHERE WARGA_nik=? ORDER BY tanggal_pembayaran DESC";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nik);
            try (ResultSet rs = ps.executeQuery()) {
                List<String> out = new ArrayList<>();
                while (rs.next()) {
                    out.add("#" + rs.getInt("id_pembayaran") + " | "
                            + rs.getTimestamp("tanggal_pembayaran") + " | "
                            + rs.getString("metode_pembayaran") + " | "
                            + rs.getBigDecimal("jumlah_bayar"));
                }
                return out;
            }
        }
    }

    /** Riwayat pembayaran by NIK dalam bentuk TableModel (siap JTable, non-editable). */
    public DefaultTableModel tableModelRiwayatByNik(String nik) throws SQLException {
        String[] cols = {"id_pembayaran","tanggal_pembayaran","metode_pembayaran",
                         "jumlah_bayar","status_pembayaran"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        String sql = "SELECT id_pembayaran, tanggal_pembayaran, metode_pembayaran, "
                   + "       jumlah_bayar, status_pembayaran "
                   + "FROM pembayaran WHERE WARGA_nik=? ORDER BY tanggal_pembayaran DESC";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nik);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id_pembayaran"),
                        rs.getTimestamp("tanggal_pembayaran"),
                        rs.getString("metode_pembayaran"),
                        rs.getBigDecimal("jumlah_bayar"),
                        rs.getString("status_pembayaran")
                    });
                }
            }
        }
        return model;
    }

    /* =========================================================
       LIST (petugas komunitas)
       ========================================================= */

    /** Tabel pembayaran untuk PETUGAS – difilter komunitas petugas. */
    public DefaultTableModel tableModelByKomunitasPetugas(String idUserPetugas) throws SQLException {
        String[] cols = {"id_pembayaran","tanggal_pembayaran","metode_pembayaran","jumlah_bayar","status_pembayaran"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql = """
            SELECT p.id_pembayaran, p.tanggal_pembayaran, p.metode_pembayaran,
                   p.jumlah_bayar, p.status_pembayaran
            FROM pembayaran p
            JOIN tagihan_bulanan t ON t.id_tagihan = p.TAGIHAN_BULANAN_id_tagihan
            JOIN rumah r ON r.id_rumah = t.RUMAH_id_rumah
            JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            WHERE ak.id_user = ?
            ORDER BY p.id_pembayaran
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getInt(1), rs.getTimestamp(2), rs.getString(3),
                        rs.getBigDecimal(4), rs.getString(5)
                    });
                }
            }
        }
        return m;
    }

    /* =========================================================
       UPDATE (petugas komunitas, guard komunitas)
       ========================================================= */

    /**
     * Update pembayaran, dibatasi hanya data dalam komunitas si petugas.
     */
    public int updateByPetugas(
            int idPembayaran,
            Timestamp tanggalPembayaran,   // boleh null
            String metodePembayaran,
            BigDecimal jumlahBayar,
            String statusPembayaran,
            String idUserPetugas
    ) throws SQLException {

        final String sql = """
            UPDATE pembayaran p
            JOIN warga w  ON w.nik = p.WARGA_nik
            JOIN rumah r  ON r.USER_id_user = w.id_user
            JOIN ( SELECT KOMUNITAS_id_komunitas
                   FROM anggota_komunitas
                   WHERE id_user = ? LIMIT 1 ) ak
              ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
            SET p.tanggal_pembayaran = ?,
                p.metode_pembayaran  = ?,
                p.jumlah_bayar       = ?,
                p.status_pembayaran  = ?
            WHERE p.id_pembayaran = ?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, idUserPetugas);        // guard komunitas
            ps.setTimestamp(i++, tanggalPembayaran); // bisa null
            ps.setString(i++, metodePembayaran);
            ps.setBigDecimal(i++, jumlahBayar);
            ps.setString(i++, statusPembayaran);
            ps.setInt(i,   idPembayaran);
            return ps.executeUpdate();
        }
    }

    /* =========================================================
       CRUD untuk SUPERADMIN
       ========================================================= */
    
    // di dalam class PembayaranDao
    public int nextId() throws java.sql.SQLException {
        final String sql = "SELECT COALESCE(MAX(id_pembayaran),0)+1 FROM pembayaran";
        try (java.sql.Connection c = DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }
    
    // Ambil TOTAL TAGIHAN (full)
public java.math.BigDecimal getTotalTagihan(int idTagihan) throws java.sql.SQLException {
    try (var c = DB.getConnection();
         var ps = c.prepareStatement(
             "SELECT total_tagihan FROM tagihan_bulanan WHERE id_tagihan=?")) {
        ps.setInt(1, idTagihan);
        try (var rs = ps.executeQuery()) {
            if (!rs.next()) throw new java.sql.SQLException("ID Tagihan tidak ditemukan.");
            return rs.getBigDecimal(1).setScale(2, java.math.RoundingMode.HALF_UP);
        }
    }
}

//// (OPSIONAL) Ambil SISA TAGIHAN = total - sum(jumlah_bayar)
//// Pakai ini kalau ingin bisa cicilan / lebih dari 1 pembayaran per tagihan
//    public java.math.BigDecimal getSisaTagihan(int idTagihan) throws java.sql.SQLException {
//        try (var c = DB.getConnection(); var ps = c.prepareStatement(
//                "SELECT t.total_tagihan - IFNULL(SUM(p.jumlah_bayar),0) AS sisa "
//                + "FROM tagihan_bulanan t "
//                + "LEFT JOIN pembayaran p ON p.TAGIHAN_BULANAN_id_tagihan = t.id_tagihan "
//                + "WHERE t.id_tagihan=? "
//                + "GROUP BY t.total_tagihan")) {
//            ps.setInt(1, idTagihan);
//            try (var rs = ps.executeQuery()) {
//                if (!rs.next()) {
//                    throw new java.sql.SQLException("ID Tagihan tidak ditemukan.");
//                }
//                java.math.BigDecimal sisa = rs.getBigDecimal("sisa");
//                if (sisa == null) {
//                    sisa = java.math.BigDecimal.ZERO;
//                }
//                if (sisa.signum() < 0) {
//                    sisa = java.math.BigDecimal.ZERO; // jaga2
//                }
//                return sisa.setScale(2, java.math.RoundingMode.HALF_UP);
//            }
//        }
//    }



    /** List semua pembayaran untuk superadmin. */
    public DefaultTableModel loadTableForAdmin() throws SQLException {
        String[] cols = {"id_pembayaran","tanggal_pembayaran","metode_pembayaran","jumlah_bayar","status_pembayaran"};
        DefaultTableModel m = new DefaultTableModel(cols, 0){
            @Override public boolean isCellEditable(int r,int c){ return false; }
        };

        final String sql =
            "SELECT id_pembayaran, tanggal_pembayaran, metode_pembayaran, jumlah_bayar, status_pembayaran " +
            "FROM pembayaran ORDER BY id_pembayaran";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1),
                    rs.getTimestamp(2),
                    rs.getString(3),
                    rs.getBigDecimal(4),
                    rs.getString(5)
                });
            }
        }
        return m;
    }

    /** Tambah pembayaran (superadmin) – butuh FK id_tagihan & nik. */
    public int insertAdmin(
            int idPembayaran,
            Timestamp tanggalPembayaran,
            String metode,
            BigDecimal jumlahBayar,
            String statusPembayaran,
            int idTagihan,
            String nik
    ) throws SQLException {

        final String sql =
            "INSERT INTO pembayaran " +
            "(id_pembayaran, tanggal_pembayaran, metode_pembayaran, jumlah_bayar, status_pembayaran, " +
            " TAGIHAN_BULANAN_id_tagihan, WARGA_nik) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, idPembayaran);
            ps.setTimestamp(i++, tanggalPembayaran);
            ps.setString(i++, metode);
            ps.setBigDecimal(i++, jumlahBayar);
            ps.setString(i++, statusPembayaran);
            ps.setInt(i++, idTagihan);
            ps.setString(i  , nik);
            return ps.executeUpdate();
        }
    }

    /** Perbarui pembayaran (superadmin). */
    public int updateAdmin(
            int idPembayaran,
            Timestamp tanggalPembayaran,
            String metode,
            BigDecimal jumlahBayar,
            String statusPembayaran
    ) throws SQLException {

        final String sql =
            "UPDATE pembayaran SET tanggal_pembayaran=?, metode_pembayaran=?, jumlah_bayar=?, status_pembayaran=? " +
            "WHERE id_pembayaran=?";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setTimestamp(i++, tanggalPembayaran);
            ps.setString(i++, metode);
            ps.setBigDecimal(i++, jumlahBayar);
            ps.setString(i++, statusPembayaran);
            ps.setInt(i  , idPembayaran);
            return ps.executeUpdate();
        }
    }

    /** Hapus pembayaran (superadmin). */
    public int deleteAdmin(int idPembayaran) throws SQLException {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "DELETE FROM pembayaran WHERE id_pembayaran=?")) {
            ps.setInt(1, idPembayaran);
            return ps.executeUpdate();
        }
    }
}
