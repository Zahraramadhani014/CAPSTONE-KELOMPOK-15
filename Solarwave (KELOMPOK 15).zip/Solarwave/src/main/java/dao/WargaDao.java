package dao;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class WargaDao {

    /* ==============================
       UTIL & HELPER
       ============================== */
    private boolean exists(Connection c, String sql, String v) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, v);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /**
     * Cek apakah NIK sudah dipakai user lain (saat UPDATE).
     */
    private boolean nikDipakaiOlehUserLain(Connection c, String nik, String idUser) throws SQLException {
        String sql = "SELECT 1 FROM warga WHERE nik=? AND id_user<>? LIMIT 1";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nik);
            ps.setString(2, idUser);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /* ==============================
       QUERY SEDERHANA
       ============================== */
    /**
     * Ambil NIK berdasarkan id_user dari tabel warga.
     */
    public String findNikByUserId(String idUser) throws SQLException {
        String sql = "SELECT nik FROM warga WHERE id_user=?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUser);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("nik") : null;
            }
        }
    }

    /**
     * Ambil 1 baris data warga milik id_user tertentu, dalam urutan kolom:
     * id_user, nama, nik, no_kk, alamat, no_telepon, email, username, password,
     * tanggal_bergabung Cocok untuk ditampilkan sebagai satu record (Field |
     * Value) di UI.
     */
    public javax.swing.table.DefaultTableModel loadTableByUserId(String idUser) throws SQLException {
        String[] cols = {
            "id_user", "nama", "nik", "no_kk", "alamat",
            "no_telepon", "email", "username", "password", "tanggal_bergabung"
        };
        javax.swing.table.DefaultTableModel m = new javax.swing.table.DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql
                = "SELECT u.id_user, u.nama, w.nik, w.no_kk, "
                + "       u.alamat, u.no_telepon, u.email, u.username, u.password, w.tanggal_bergabung "
                + "FROM `user` u "
                + "LEFT JOIN warga w ON w.id_user = u.id_user "
                + "WHERE u.id_user=? "
                + "LIMIT 1";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUser);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getString("id_user"),
                        rs.getString("nama"),
                        rs.getString("nik"),
                        rs.getString("no_kk"),
                        rs.getString("alamat"),
                        rs.getString("no_telepon"),
                        rs.getString("email"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getDate("tanggal_bergabung")
                    });
                }
            }
        }
        return m;
    }

    /**
     * LIST umum: SEMUA warga/anggota komunitas (TANPA password). Dipakai
     * sebagai fallback.
     */
    public TableModel loadTableModel() throws SQLException {
        String[] cols = {"id_user", "nama", "nik", "no_kk", "alamat",
            "no_telepon", "email", "username", "tanggal_bergabung"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql
                = "SELECT u.id_user, u.nama, w.nik, w.no_kk, "
                + "       u.alamat, u.no_telepon, u.email, u.username, w.tanggal_bergabung "
                + "FROM `user` u "
                + "JOIN warga w ON w.id_user = u.id_user "
                + "WHERE u.role IN ('WARGA','ANGGOTA_KOMUNITAS') "
                + "ORDER BY u.id_user";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getString("id_user"),
                    rs.getString("nama"),
                    rs.getString("nik"),
                    rs.getString("no_kk"),
                    rs.getString("alamat"),
                    rs.getString("no_telepon"),
                    rs.getString("email"),
                    rs.getString("username"),
                    rs.getDate("tanggal_bergabung")
                });
            }
        }
        return m;
    }

    /* ===================== TABLE MODEL (Super Admin) ===================== */
    public DefaultTableModel loadTableModelForAdmin() throws SQLException {
        String[] cols = {
            "ID User", "Nama", "NIK", "No. KK", "Alamat",
            "No. Telp", "Email", "Tgl Bergabung", "Username", "Password"
        };
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql = """
            SELECT u.id_user, u.nama, w.nik, w.no_kk, u.alamat,
                   u.no_telepon, u.email, w.tanggal_bergabung,
                   u.username, u.password
              FROM user u
              JOIN warga w ON w.id_user = u.id_user
             ORDER BY u.id_user
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getString(7),
                    rs.getDate(8), rs.getString(9), rs.getString(10)
                });
            }
        }
        return m;
    }

    // WargaDao.java
    public DefaultTableModel loadTableModelForPetugas(String idUserPetugas) throws SQLException {
        String[] cols = {"ID User", "Nama", "NIK", "No KK", "Alamat", "No Telp", "Email", "Tgl Bergabung"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        final String sql = """
        SELECT u.id_user,
               u.nama,
               w.nik,
               w.no_kk,
               u.alamat,
               u.no_telepon,     -- <== kolom yang benar
               u.email,
               w.tanggal_bergabung
          FROM warga w
          JOIN user u              ON u.id_user = w.id_user   -- <== tabel yang benar
          JOIN rumah r             ON r.USER_id_user = u.id_user
          JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas
         WHERE ak.id_user = ?      -- id petugas komunitas yang login
         ORDER BY u.id_user
    """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), rs.getString(6), rs.getString(7), rs.getDate(8)
                    });
                }
            }
        }
        return m;
    }

    /* ===================== ID AUTO ===================== */
    /**
     * Format ID: USR000 (CHAR(6) atau lebih kalau >999). Ambil bagian angka
     * setelah prefix 'USR', cari max, lalu +1.
     */
    public String nextIdUser() throws SQLException {
        final String sql
                = "SELECT COALESCE(MAX(CAST(SUBSTRING(id_user, 4) AS UNSIGNED)), 0) + 1 AS n "
                + "FROM user "
                + "WHERE id_user LIKE 'USR%'";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            rs.next();
            int n = rs.getInt(1);                 // misal terakhir USR080 -> n = 81
            return "USR" + String.format("%03d", n); // -> USR081
        }
    }

    /* ==============================
       CRUD PENUH (Super Admin)
       ============================== */
    /**
     * INSERT user + warga (satu transaksi).
     */
    public int insertWarga(
            String idUser, String nama, String alamat, String noTelp, String email,
            String username, String password,
            String nik, String noKk, java.sql.Date tglBergabung,
            String role // "WARGA" atau "ANGGOTA_KOMUNITAS"
    ) throws SQLException {

        try (Connection c = DB.getConnection()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                // unik username & nik
                if (exists(c, "SELECT 1 FROM `user` WHERE username=? LIMIT 1", username)) {
                    throw new SQLException("Username sudah dipakai.");
                }
                if (exists(c, "SELECT 1 FROM warga WHERE nik=? LIMIT 1", nik)) {
                    throw new SQLException("NIK sudah dipakai.");
                }

                // 1) user
                String su = "INSERT INTO `user`(id_user,nama,alamat,no_telepon,email,username,password,role) "
                        + "VALUES(?,?,?,?,?,?,?,?)";
                try (PreparedStatement ps = c.prepareStatement(su)) {
                    ps.setString(1, idUser);
                    ps.setString(2, nama);
                    ps.setString(3, alamat);
                    ps.setString(4, noTelp);
                    ps.setString(5, email);
                    ps.setString(6, username);
                    ps.setString(7, password);
                    ps.setString(8, role);
                    ps.executeUpdate();
                }

                // 2) warga
                String sw = "INSERT INTO warga(id_user,nik,no_kk,tanggal_bergabung) VALUES(?,?,?,?)";
                try (PreparedStatement ps = c.prepareStatement(sw)) {
                    ps.setString(1, idUser);
                    ps.setString(2, nik);
                    ps.setString(3, noKk);
                    ps.setDate(4, tglBergabung);
                    ps.executeUpdate();
                }

                c.commit();
                c.setAutoCommit(old);
                return 2;
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        }
    }

    /**
     * UPDATE user + warga (password opsional; kosong = tidak diganti).
     */
    public int updateWarga(
            String idUser, String nama, String alamat, String noTelepon, String email,
            String username, String passwordOrNull,
            String nik, String noKk, java.sql.Date tglBergabung
    ) throws SQLException {

        try (Connection c = DB.getConnection()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                if (nikDipakaiOlehUserLain(c, nik, idUser)) {
                    throw new SQLException("NIK sudah dipakai pengguna lain.");
                }

                // username unik (kecuali dirinya)
                String qUser = "SELECT 1 FROM `user` WHERE username=? AND id_user<>? LIMIT 1";
                try (PreparedStatement ps = c.prepareStatement(qUser)) {
                    ps.setString(1, username);
                    ps.setString(2, idUser);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            throw new SQLException("Username sudah dipakai pengguna lain.");
                        }
                    }
                }

                StringBuilder su = new StringBuilder(
                        "UPDATE `user` SET nama=?, alamat=?, no_telepon=?, email=?, username=?");
                boolean gantiPass = passwordOrNull != null && !passwordOrNull.isBlank();
                if (gantiPass) {
                    su.append(", password=?");
                }
                su.append(" WHERE id_user=?");

                int changed = 0;
                try (PreparedStatement ps = c.prepareStatement(su.toString())) {
                    int i = 1;
                    ps.setString(i++, nama);
                    ps.setString(i++, alamat);
                    ps.setString(i++, noTelepon);
                    ps.setString(i++, email);
                    ps.setString(i++, username);
                    if (gantiPass) {
                        ps.setString(i++, passwordOrNull);
                    }
                    ps.setString(i, idUser);
                    changed += ps.executeUpdate();
                }

                String sw = "UPDATE warga SET nik=?, no_kk=?, tanggal_bergabung=? WHERE id_user=?";
                try (PreparedStatement ps = c.prepareStatement(sw)) {
                    ps.setString(1, nik);
                    ps.setString(2, noKk);
                    ps.setDate(3, tglBergabung);
                    ps.setString(4, idUser);
                    changed += ps.executeUpdate();
                }

                c.commit();
                c.setAutoCommit(old);
                return changed;
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        }
    }

    /**
     * DELETE warga + user (satu transaksi).
     */
    public int deleteByIdUser(String idUser) throws SQLException {
        try (Connection c = DB.getConnection()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                int changed = 0;
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM warga WHERE id_user=?")) {
                    ps.setString(1, idUser);
                    changed += ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM `user` WHERE id_user=?")) {
                    ps.setString(1, idUser);
                    changed += ps.executeUpdate();
                }
                c.commit();
                c.setAutoCommit(old);
                return changed;
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        }
    }

    /* ==============================
       GET ONE (untuk isi field dari JTable)
       ============================== */
    public Map<String, Object> findOneByIdUser(String idUser) throws SQLException {
        String sql
                = "SELECT u.id_user, u.nama, w.nik, w.no_kk, "
                + "       u.alamat, u.no_telepon, u.email, u.username, w.tanggal_bergabung "
                + "FROM `user` u JOIN warga w ON w.id_user = u.id_user "
                + "WHERE u.id_user=? LIMIT 1";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUser);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return java.util.Collections.emptyMap();
                }
                Map<String, Object> m = new HashMap<>();
                m.put("id_user", rs.getString("id_user"));
                m.put("nama", rs.getString("nama"));
                m.put("nik", rs.getString("nik"));
                m.put("no_kk", rs.getString("no_kk"));
                m.put("alamat", rs.getString("alamat"));
                m.put("no_telepon", rs.getString("no_telepon"));
                m.put("email", rs.getString("email"));
                m.put("username", rs.getString("username"));
                m.put("tanggal_bergabung", rs.getDate("tanggal_bergabung"));
                return m;
            }
        }
    }
}
