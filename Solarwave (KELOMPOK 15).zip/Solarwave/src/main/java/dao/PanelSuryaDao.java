package dao;

import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class PanelSuryaDao {

    /* ======================
       VIEW: SUPERADMIN (FULL)
       ====================== */
    /** Tampilkan semua panel, termasuk id komunitas. */
    public DefaultTableModel loadTableForAdmin() throws SQLException {
        String[] cols = {
            "kode_panel", "kapasitas_watt", "tanggal_pasang",
            "catatan", "status_panel", "KOMUNITAS_id_komunitas"
        };
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql = """
            SELECT kode_panel, kapasitas_watt, tanggal_pasang,
                   catatan, status_panel, KOMUNITAS_id_komunitas
            FROM panel_surya
            ORDER BY kode_panel
        """;

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[] {
                    rs.getInt("kode_panel"),
                    rs.getBigDecimal("kapasitas_watt"),
                    rs.getDate("tanggal_pasang"),
                    rs.getString("catatan"),
                    rs.getString("status_panel"),
                    rs.getInt("KOMUNITAS_id_komunitas")
                });
            }
        }
        return m;
    }

    /* ===============================
       VIEW: PETUGAS (FILTER KOMUNITAS)
       =============================== */
    public DefaultTableModel loadTableByKomunitasPetugas(String idUserAnggota) throws SQLException {
        String[] cols = {"kode_panel","kapasitas_watt","tanggal_pasang","catatan","status_panel"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql = """
            SELECT p.kode_panel, p.kapasitas_watt, p.tanggal_pasang, p.catatan, p.status_panel
            FROM panel_surya p
            JOIN anggota_komunitas ak
              ON ak.KOMUNITAS_id_komunitas = p.KOMUNITAS_id_komunitas
            WHERE ak.id_user = ?
            ORDER BY p.kode_panel
        """;

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserAnggota);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getInt("kode_panel"),
                        rs.getBigDecimal("kapasitas_watt"),
                        rs.getDate("tanggal_pasang"),
                        rs.getString("catatan"),
                        rs.getString("status_panel")
                    });
                }
            }
        }
        return m;
    }

    /* ======================
       CRUD: SUPERADMIN (FULL)
       ====================== */
    
    // ==== AUTO NUMBER untuk KODE PANEL ====
    public int nextKodePanel() throws java.sql.SQLException {
        final String sql = "SELECT COALESCE(MAX(kode_panel), 0) + 1 AS next_id FROM panel_surya";
        try (java.sql.Connection c = DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public int insertAdmin(int kodePanel,
                           java.math.BigDecimal kapasitasWatt,
                           String statusPanel,
                           java.sql.Date tanggalPasang,
                           String catatan,
                           int idKomunitas) throws SQLException {

        final String sql = """
            INSERT INTO panel_surya
                (kode_panel, kapasitas_watt, status_panel, tanggal_pasang, catatan, KOMUNITAS_id_komunitas)
            VALUES (?, ?, ?, ?, ?, ?)
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, kodePanel);
            ps.setBigDecimal(2, kapasitasWatt);
            ps.setString(3, statusPanel);
            ps.setDate(4, tanggalPasang);
            ps.setString(5, catatan);
            ps.setInt(6, idKomunitas);
            return ps.executeUpdate();
        }
    }

    public int updateAdmin(int kodePanel,
                           java.math.BigDecimal kapasitasWatt,
                           String statusPanel,
                           java.sql.Date tanggalPasang,
                           String catatan) throws SQLException {

        final String sql = """
            UPDATE panel_surya
            SET kapasitas_watt=?, status_panel=?, tanggal_pasang=?, catatan=?
            WHERE kode_panel=?
        """;
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setBigDecimal(1, kapasitasWatt);
            ps.setString(2, statusPanel);
            ps.setDate(3, tanggalPasang);
            ps.setString(4, catatan);
            ps.setInt(5, kodePanel);
            return ps.executeUpdate();
        }
    }

    public int deleteAdmin(int kodePanel) throws SQLException {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM panel_surya WHERE kode_panel=?")) {
            ps.setInt(1, kodePanel);
            return ps.executeUpdate();
        }
    }

    /* =========================================
       CRUD: PETUGAS (DIJAGA SESUAI KOMUNITAS)
       ========================================= */
    public int insertPanelByPetugas(int kodePanel,
                                    java.math.BigDecimal kapasitasWatt,
                                    String statusPanel,
                                    java.sql.Date tanggalPasang,
                                    String catatan,
                                    String idUserAnggota) throws SQLException {

        final String sql = """
            INSERT INTO panel_surya
                (kode_panel, kapasitas_watt, status_panel, tanggal_pasang, catatan, KOMUNITAS_id_komunitas)
            SELECT ?, ?, ?, ?, ?, ak.KOMUNITAS_id_komunitas
            FROM anggota_komunitas ak
            WHERE ak.id_user = ?
            LIMIT 1
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, kodePanel);
            ps.setBigDecimal(i++, kapasitasWatt);
            ps.setString(i++, statusPanel);
            ps.setDate(i++, tanggalPasang);
            ps.setString(i++, catatan);
            ps.setString(i,   idUserAnggota);
            return ps.executeUpdate(); // 1 = sukses, 0 = gagal (bukan komunitasnya)
        }
    }

    public int updatePanelByPetugas(int kodePanel,
                                    java.math.BigDecimal kapasitasWatt,
                                    String statusPanel,
                                    java.sql.Date tanggalPasang,
                                    String catatan,
                                    String idUserAnggota) throws SQLException {

        final String sql = """
            UPDATE panel_surya p
            JOIN (SELECT KOMUNITAS_id_komunitas FROM anggota_komunitas
                  WHERE id_user = ? LIMIT 1) ak
              ON ak.KOMUNITAS_id_komunitas = p.KOMUNITAS_id_komunitas
            SET p.kapasitas_watt = ?, p.status_panel = ?, p.tanggal_pasang = ?, p.catatan = ?
            WHERE p.kode_panel = ?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, idUserAnggota);
            ps.setBigDecimal(i++, kapasitasWatt);
            ps.setString(i++, statusPanel);
            ps.setDate(i++, tanggalPasang);
            ps.setString(i++, catatan);
            ps.setInt(i,   kodePanel);
            return ps.executeUpdate();
        }
    }

    public int deletePanelByPetugas(int kodePanel, String idUserAnggota) throws SQLException {
        final String sql = """
            DELETE p FROM panel_surya p
            JOIN (SELECT KOMUNITAS_id_komunitas FROM anggota_komunitas
                  WHERE id_user = ? LIMIT 1) ak
              ON ak.KOMUNITAS_id_komunitas = p.KOMUNITAS_id_komunitas
            WHERE p.kode_panel = ?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserAnggota);
            ps.setInt(2, kodePanel);
            return ps.executeUpdate();
        }
    }
}
