package dao;

import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class RumahDao {

    /* =======================
       VIEW: MODE WARGA
       ======================= */
    /** Data rumah milik 1 warga (id_user si warga). */
    public DefaultTableModel loadTableByUserId(String idUser) throws SQLException {
        String[] cols = {
            "id_rumah", "nomor_rumah", "nama_pemilik", "alamat_rumah",
            "no_telp", "status_koneksi", "tanggal_bergabung"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql =
            "SELECT r.id_rumah, r.nomor_rumah, r.nama_pemilik, r.alamat_rumah, " +
            "       r.no_telp, r.status_koneksi, r.tanggal_bergabung " +
            "FROM rumah r " +
            "WHERE r.USER_id_user = ? " +
            "ORDER BY r.id_rumah";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUser);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id_rumah"),
                        rs.getString("nomor_rumah"),
                        rs.getString("nama_pemilik"),
                        rs.getString("alamat_rumah"),
                        rs.getString("no_telp"),
                        rs.getString("status_koneksi"),
                        rs.getDate("tanggal_bergabung")
                    });
                }
            }
        }
        return model;
    }

    /* =======================
       VIEW: MODE ANGGOTA KOMUNITAS (TANPA AREA)
       ======================= */
    public DefaultTableModel loadTableByKomunitasPetugas(String idUserAnggota) throws SQLException {
        String[] cols = {
            "id_rumah", "nomor_rumah", "nama_pemilik", "alamat_rumah",
            "no_telp", "status_koneksi", "tanggal_bergabung"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql =
            "SELECT r.id_rumah, r.nomor_rumah, r.nama_pemilik, r.alamat_rumah, " +
            "       r.no_telp, r.status_koneksi, r.tanggal_bergabung " +
            "FROM rumah r " +
            "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "WHERE ak.id_user = ? " +
            "ORDER BY r.id_rumah";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserAnggota);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id_rumah"),
                        rs.getString("nomor_rumah"),
                        rs.getString("nama_pemilik"),
                        rs.getString("alamat_rumah"),
                        rs.getString("no_telp"),
                        rs.getString("status_koneksi"),
                        rs.getDate("tanggal_bergabung")
                    });
                }
            }
        }
        return model;
    }

    /* =======================
       VIEW: MODE ANGGOTA KOMUNITAS (DENGAN FALLBACK AREA→KOMUNITAS)
       ======================= */
    public DefaultTableModel loadTableByAnggotaKomunitasWithFallback(String idUserAnggota) throws SQLException {
        String[] cols = {
            "id_rumah", "nomor_rumah", "nama_pemilik", "alamat_rumah",
            "no_telp", "status_koneksi", "tanggal_bergabung"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String baseCols =
            "r.id_rumah, r.nomor_rumah, r.nama_pemilik, r.alamat_rumah, " +
            "r.no_telp, r.status_koneksi, r.tanggal_bergabung";

        final String sqlArea =
            "SELECT " + baseCols + " " +
            "FROM rumah r " +
            "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "WHERE ak.id_user = ? " +
            "  AND (ak.area_tanggung_jawab IS NULL " +
            "       OR ak.area_tanggung_jawab = '' " +
            "       OR r.alamat_rumah LIKE CONCAT('%', ak.area_tanggung_jawab, '%')) " +
            "ORDER BY r.id_rumah";

        final String sqlKom =
            "SELECT " + baseCols + " " +
            "FROM rumah r " +
            "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "WHERE ak.id_user = ? " +
            "ORDER BY r.id_rumah";

        try (Connection c = DB.getConnection()) {
            // diagnosa ringan
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery(
                    "SELECT DATABASE() db, " +
                    "(SELECT COUNT(*) FROM rumah) rumah, " +
                    "(SELECT COUNT(*) FROM anggota_komunitas) ang")) {
                if (rs.next()) {
                    System.out.println("[RUMAH][DIAG] db=" + rs.getString("db")
                            + " | rumah=" + rs.getInt("rumah")
                            + " | anggota_komunitas=" + rs.getInt("ang"));
                }
            }

            int rows = 0;
            try (PreparedStatement ps = c.prepareStatement(sqlArea)) {
                ps.setString(1, idUserAnggota);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        model.addRow(new Object[]{
                            rs.getInt(1), rs.getString(2), rs.getString(3),
                            rs.getString(4), rs.getString(5), rs.getString(6), rs.getDate(7)
                        });
                        rows++;
                    }
                }
            }
            System.out.println("[RUMAH] rows(area)=" + rows + " | idUser=" + idUserAnggota);

            if (rows == 0) {
                javax.swing.JOptionPane.showMessageDialog(
                        null,
                        "Tidak ada rumah yang cocok dengan area_tanggung_jawab.\n" +
                        "Menampilkan semua rumah dalam komunitas yang sama.");
                try (PreparedStatement ps = c.prepareStatement(sqlKom)) {
                    ps.setString(1, idUserAnggota);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            model.addRow(new Object[]{
                                rs.getInt(1), rs.getString(2), rs.getString(3),
                                rs.getString(4), rs.getString(5), rs.getString(6), rs.getDate(7)
                            });
                        }
                    }
                }
                System.out.println("[RUMAH] rows(fallback-komunitas)=" + model.getRowCount());
            }
        }
        return model;
    }

    /* =======================
       UPDATE: dibatasi komunitas petugas
       ======================= */
    /** Perbarui rumah hanya jika rumah berada di komunitas si petugas. */
    public int updateRumahByPetugas(
            int idRumah,
            String nomorRumah,
            String namaPemilik,
            String alamatRumah,
            String noTelp,
            String statusKoneksi,
            java.sql.Date tanggalBergabung,
            String idUserAnggota
    ) throws SQLException {

        final String sql =
            "UPDATE rumah r " +
            "JOIN (SELECT KOMUNITAS_id_komunitas FROM anggota_komunitas WHERE id_user = ? LIMIT 1) ak " +
            "  ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas " +
            "SET r.nomor_rumah = ?, r.nama_pemilik = ?, r.alamat_rumah = ?, r.no_telp = ?, " +
            "    r.status_koneksi = ?, r.tanggal_bergabung = ? " +
            "WHERE r.id_rumah = ?";

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, idUserAnggota);
            ps.setString(i++, nomorRumah);
            ps.setString(i++, namaPemilik);
            ps.setString(i++, alamatRumah);
            ps.setString(i++, noTelp);
            ps.setString(i++, statusKoneksi);
            ps.setDate(i++, tanggalBergabung);
            ps.setInt(i, idRumah);
            return ps.executeUpdate();
        }
    }

    /* =======================
       VIEW/CRUD: MODE SUPERADMIN (FULL ACCESS)
       ======================= */
    
    public int nextIdRumah() throws java.sql.SQLException {
    try (var c = DB.getConnection();
         var ps = c.prepareStatement("SELECT COALESCE(MAX(id_rumah),0)+1 FROM rumah");
         var rs = ps.executeQuery()) {
        rs.next();
        return rs.getInt(1);
    }
}


    /** Tampilkan semua rumah (plus FK untuk debugging/admin). */
    public DefaultTableModel loadTableForAdmin() throws SQLException {
        String[] cols = {
            "id_rumah","nomor_rumah","nama_pemilik","alamat_rumah","no_telp",
            "status_koneksi","tanggal_bergabung","KOMUNITAS_id_komunitas","USER_id_user"
        };
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r,int c){ return false; }
        };

        final String sql = """
            SELECT id_rumah, nomor_rumah, nama_pemilik, alamat_rumah,
                   no_telp, status_koneksi, tanggal_bergabung,
                   KOMUNITAS_id_komunitas, USER_id_user
            FROM rumah
            ORDER BY id_rumah
        """;

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getDate(7),
                    rs.getInt(8), rs.getString(9)
                });
            }
        }
        return m;
    }

    /** Insert rumah (superadmin mengisi FK id_komunitas & id_user). */
    public int insertAdmin(
            int idRumah,
            String nomorRumah,
            String namaPemilik,
            String alamatRumah,
            String noTelp,
            String statusKoneksi,
            java.sql.Date tanggalBergabung,
            int idKomunitas,
            String idUser
    ) throws SQLException {

        final String sql = """
            INSERT INTO rumah
            (id_rumah, nomor_rumah, nama_pemilik, alamat_rumah, no_telp,
             status_koneksi, tanggal_bergabung, KOMUNITAS_id_komunitas, USER_id_user)
            VALUES (?,?,?,?,?,?,?,?,?)
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i=1;
            ps.setInt(i++, idRumah);
            ps.setString(i++, nomorRumah);
            ps.setString(i++, namaPemilik);
            ps.setString(i++, alamatRumah);
            ps.setString(i++, noTelp);
            ps.setString(i++, statusKoneksi);
            ps.setDate(i++, tanggalBergabung);
            ps.setInt(i++, idKomunitas);
            ps.setString(i++, idUser);
            return ps.executeUpdate();
        }
    }

    /** Update kolom-kolom utama (FK tidak diubah). */
    public int updateAdmin(
            int idRumah,
            String nomorRumah,
            String namaPemilik,
            String alamatRumah,
            String noTelp,
            String statusKoneksi,
            java.sql.Date tanggalBergabung
    ) throws SQLException {

        final String sql = """
            UPDATE rumah
            SET nomor_rumah=?, nama_pemilik=?, alamat_rumah=?, no_telp=?,
                status_koneksi=?, tanggal_bergabung=?
            WHERE id_rumah=?
        """;

        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i=1;
            ps.setString(i++, nomorRumah);
            ps.setString(i++, namaPemilik);
            ps.setString(i++, alamatRumah);
            ps.setString(i++, noTelp);
            ps.setString(i++, statusKoneksi);
            ps.setDate(i++, tanggalBergabung);
            ps.setInt(i, idRumah);
            return ps.executeUpdate();
        }
    }

    /** Hapus rumah berdasarkan id. */
    public int deleteAdmin(int idRumah) throws SQLException {
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM rumah WHERE id_rumah=?")) {
            ps.setInt(1, idRumah);
            return ps.executeUpdate();
        }
    }
}
