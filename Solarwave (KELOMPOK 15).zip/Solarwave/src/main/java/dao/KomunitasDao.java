package dao;

import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class KomunitasDao {

    /* === LIST all untuk Super Admin === */
    public DefaultTableModel loadAll() throws SQLException {
        String[] cols = {
            "id_komunitas","nama_komunitas","lokasi",
            "kontak_pengurus","tgl_mulai_operasi","status_komunitas"
        };
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        final String sql =
            "SELECT id_komunitas, nama_komunitas, lokasi, " +
            "       kontak_pengurus, tgl_mulai_operasi, status_komunitas " +
            "FROM komunitas " +
            "ORDER BY id_komunitas";

        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt("id_komunitas"),
                    rs.getString("nama_komunitas"),
                    rs.getString("lokasi"),
                    rs.getString("kontak_pengurus"),
                    rs.getDate("tgl_mulai_operasi"),
                    rs.getString("status_komunitas")
                });
            }
        }
        return m;
    }

    /** ID berikutnya: MAX(id)+1. */
    public int nextId() throws SQLException {
        final String sql = "SELECT COALESCE(MAX(id_komunitas), 0) + 1 AS next_id FROM komunitas";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    /* === INSERT === */
    public int insert(int id, String nama, String lokasi, String kontak,
                      java.sql.Date tglMulai, String status) throws SQLException {
        final String sql =
            "INSERT INTO komunitas " +
            "(id_komunitas, nama_komunitas, lokasi, kontak_pengurus, tgl_mulai_operasi, status_komunitas) " +
            "VALUES (?,?,?,?,?,?)";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, id);
            ps.setString(i++, nama);
            ps.setString(i++, lokasi);
            ps.setString(i++, kontak);
            if (tglMulai == null) ps.setNull(i++, Types.DATE); else ps.setDate(i++, tglMulai);
            ps.setString(i, status);
            return ps.executeUpdate();
        }
    }

    /* === UPDATE === */
    public int update(int id, String nama, String lokasi, String kontak,
                      java.sql.Date tglMulai, String status) throws SQLException {
        final String sql =
            "UPDATE komunitas SET " +
            "  nama_komunitas=?, " +
            "  lokasi=?, " +
            "  kontak_pengurus=?, " +
            "  tgl_mulai_operasi=?, " +
            "  status_komunitas=? " +
            "WHERE id_komunitas=?";
        try (Connection c = DB.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, nama);
            ps.setString(i++, lokasi);
            ps.setString(i++, kontak);
            if (tglMulai == null) ps.setNull(i++, Types.DATE); else ps.setDate(i++, tglMulai);
            ps.setString(i++, status);
            ps.setInt(i, id);
            return ps.executeUpdate();
        }
    }

    /* === DELETE === */
    public int delete(int id) throws SQLException {
        final String sql = "DELETE FROM komunitas WHERE id_komunitas=?";
        try (Connection c = DB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }
}
