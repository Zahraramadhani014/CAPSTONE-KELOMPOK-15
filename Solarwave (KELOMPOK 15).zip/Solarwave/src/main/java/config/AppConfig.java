package config;

public final class AppConfig {
    public static final String REKENING_TUJUAN = "1234567890 (BCA a.n. Solarwave)";
    public static final String DANA_TUJUAN     = "0812-3456-7890 (DANA Solarwave)";
    public static final String OVO_TUJUAN      = "0813-9876-5432 (OVO Solarwave)";
    private AppConfig() {}
}