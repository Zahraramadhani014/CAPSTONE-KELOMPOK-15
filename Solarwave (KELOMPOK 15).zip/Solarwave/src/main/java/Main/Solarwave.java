package Main;

import View.Login;

public class Solarwave {

    public static void main(String[] args) {
        // Set tampilan GUI biar rapi (opsional)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Gagal set tampilan: " + e.getMessage());
        }

        // Jalankan halaman Login
        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}

