package Service;

public final class ServiceFactory {

    private static final AuthService AUTH = new DbAuthService();

    private static final WargaService WARGA = new WargaService();
    private static final TagihanService TAGIHAN = new TagihanService();
    private static final PembayaranService PEMBAYARAN = new PembayaranService();

    private ServiceFactory() {
    }

    public static AuthService auth() {
        return AUTH;
    }

    public static WargaService warga() {
        return WARGA;
    }

    public static TagihanService tagihan() {
        return TAGIHAN;
    }

    public static PembayaranService pembayaran() {
        return PEMBAYARAN;
    }
}

