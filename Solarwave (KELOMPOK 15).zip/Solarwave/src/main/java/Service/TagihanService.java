package Service;

import dao.TagihanDao;

public class TagihanService {
    private final TagihanDao dao = new TagihanDao();
    public java.math.BigDecimal getTotalById(int idTagihan) throws java.sql.SQLException {
        return dao.getTotalById(idTagihan);
    }
    public int setLunas(int idTagihan) throws java.sql.SQLException {
        return dao.updateStatusLunas(idTagihan);
    }
}
