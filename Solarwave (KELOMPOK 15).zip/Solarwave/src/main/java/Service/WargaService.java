package Service;
import dao.WargaDao;

public class WargaService {
    private final WargaDao wargaDao = new WargaDao();
    public String getNikByUserId(String idUser) throws java.sql.SQLException {
        return wargaDao.findNikByUserId(idUser);   
    
    }
}
   
