package Service;

import dao.DB;
import java.sql.*;

public class PembayaranService {
    public void bayar(String nik, int idTagihan, java.math.BigDecimal jumlah, String metode)
            throws SQLException {
        try (Connection c = DB.getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO pembayaran (tanggal_pembayaran,metode_pembayaran,jumlah_bayar," +
                    "status_pembayaran,TAGIHAN_BULANAN_id_tagihan,WARGA_nik) VALUES (NOW(),?,?, 'LUNAS', ?, ?)")) {
                ps.setString(1, metode);
                ps.setBigDecimal(2, jumlah);
                ps.setInt(3, idTagihan);
                ps.setString(4, nik);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE tagihan_bulanan SET status_tagihan='LUNAS', tanggal_lunas=NOW() WHERE id_tagihan=?")) {
                ps.setInt(1, idTagihan);
                if (ps.executeUpdate()==0) throw new SQLException("Gagal update status tagihan");
            }
            c.commit();
        }
    }
}

