package Service;

public interface AuthService {
    // kontrak autentikasi
    Model.AuthUser login(String username, String password) throws java.sql.SQLException;
}

