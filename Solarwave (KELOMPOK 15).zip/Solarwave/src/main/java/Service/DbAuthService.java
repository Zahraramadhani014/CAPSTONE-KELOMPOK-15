package Service;

import Model.AuthUser;

public class DbAuthService implements AuthService {
    private final dao.UserDao userDao = new dao.UserDao();

    @Override
    public AuthUser login(String username, String password) throws java.sql.SQLException {
        return userDao.login(username, password);
    }
}
