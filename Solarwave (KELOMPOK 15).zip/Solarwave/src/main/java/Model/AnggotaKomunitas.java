package Model;

import java.sql.Date;

public class AnggotaKomunitas extends User {
    private String noKartuAnggota;   // unique
    private String areaTanggungJawab;
    private Date tanggalBergabung;
    private int idKomunitas;

    public AnggotaKomunitas(String idUser, String nama, String alamat, String noTelepon,
                            String email, String username, String password,
                            String noKartuAnggota, String areaTanggungJawab,
                            Date tanggalBergabung, int idKomunitas) {
        super(idUser, nama, alamat, noTelepon, email, username, password, "ANGGOTA_KOMUNITAS");
        this.noKartuAnggota = noKartuAnggota;
        this.areaTanggungJawab = areaTanggungJawab;
        this.tanggalBergabung = tanggalBergabung;
        this.idKomunitas = idKomunitas;
    }

    public String getNoKartuAnggota() { return noKartuAnggota; }
    public void setNoKartuAnggota(String noKartuAnggota) { this.noKartuAnggota = noKartuAnggota; }

    public String getAreaTanggungJawab() { return areaTanggungJawab; }
    public void setAreaTanggungJawab(String areaTanggungJawab) { this.areaTanggungJawab = areaTanggungJawab; }

    public Date getTanggalBergabung() { return tanggalBergabung; }
    public void setTanggalBergabung(Date tanggalBergabung) { this.tanggalBergabung = tanggalBergabung; }

    public int getIdKomunitas() { return idKomunitas; }
    public void setIdKomunitas(int idKomunitas) { this.idKomunitas = idKomunitas; }
    
     @Override
    public String toString() {
        return "AnggotaKomunitas{idUser='" + getIdUser() + "', noKartuAnggota='" + noKartuAnggota
                + "', areaTanggungJawab='" + areaTanggungJawab + "', idKomunitas=" + idKomunitas + "}";
    }
    
    @Override
    public String getRoleName() {               
        return "ANGGOTA_KOMUNITAS";
    }
}


