package Model;

public class AuthUser {
    private String idUser;
    private String username;
    private String role;   
    private String nik;    

    // getters & setters
    public String getIdUser() { return idUser; }
    public void setIdUser(String idUser) { this.idUser = idUser; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getNik() { return nik; }
    public void setNik(String nik) { this.nik = nik; }

    public boolean isSuperAdmin() {
        return role != null && role.equalsIgnoreCase("SUPERADMIN");
    }
    public boolean isAnggotaKomunitas() {
        return role != null && role.equalsIgnoreCase("ANGGOTA_KOMUNITAS");
    }
    public boolean isWarga() {
        return role != null && role.equalsIgnoreCase("WARGA");
    }
}
