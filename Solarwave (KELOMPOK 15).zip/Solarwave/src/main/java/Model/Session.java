package Model;

public final class Session {
    public static String idUser;
    public static String username;
    public static String role;
    public static String nik; // WARGA wajib terisi, lainnya bisa null

    public static void clear() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    private Session() {}
}

