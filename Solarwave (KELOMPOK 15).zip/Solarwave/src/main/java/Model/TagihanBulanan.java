package Model;

import java.math.BigDecimal;

public class TagihanBulanan {
    private int idTagihan;
    private String periode;
    private BigDecimal totalKwh;
    private BigDecimal tarifPerKwh;
    private BigDecimal totalTagihan;
    private String statusTagihan;
    private int idRumah;

    public TagihanBulanan(int idTagihan, String periode, BigDecimal totalKwh, BigDecimal tarifPerKwh, BigDecimal totalTagihan, String statusTagihan, int idRumah) {
        this.idTagihan = idTagihan;
        this.periode = periode;
        this.totalKwh = totalKwh;
        this.tarifPerKwh = tarifPerKwh;
        this.totalTagihan = totalTagihan;
        this.statusTagihan = statusTagihan;
        this.idRumah = idRumah;
    }

    public int getIdTagihan() {
        return idTagihan;
    }

    public void setIdTagihan(int idTagihan) {
        this.idTagihan = idTagihan;
    }

    public String getPeriode() {
        return periode;
    }

    public void setPeriode(String periode) {
        this.periode = periode;
    }

    public BigDecimal getTotalKwh() {
        return totalKwh;
    }

    public void setTotalKwh(BigDecimal totalKwh) {
        this.totalKwh = totalKwh;
    }

    public BigDecimal getTarifPerKwh() {
        return tarifPerKwh;
    }

    public void setTarifPerKwh(BigDecimal tarifPerKwh) {
        this.tarifPerKwh = tarifPerKwh;
    }

    public BigDecimal getTotalTagihan() {
        return totalTagihan;
    }

    public void setTotalTagihan(BigDecimal totalTagihan) {
        this.totalTagihan = totalTagihan;
    }

    public String getStatusTagihan() {
        return statusTagihan;
    }

    public void setStatusTagihan(String statusTagihan) {
        this.statusTagihan = statusTagihan;
    }

    public int getIdRumah() {
        return idRumah;
    }

    public void setIdRumah(int idRumah) {
        this.idRumah = idRumah;
    }

    
}