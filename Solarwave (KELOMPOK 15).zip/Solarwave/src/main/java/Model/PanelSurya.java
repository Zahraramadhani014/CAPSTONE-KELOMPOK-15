package Model;

import java.util.Date;
import java.math.BigDecimal;

public class PanelSurya {
    private int kodePanel;    
    private BigDecimal kapasitasWatt;
    private String statusPanel;
    private Date tanggalPasang;
    private String catatan;
    private int idKomunitas;

    public PanelSurya(int kodePanel, BigDecimal kapasitasWatt, String statusPanel, Date tanggalPasang, String catatan, int idKomunitas) {
        this.kodePanel = kodePanel;
        this.kapasitasWatt = kapasitasWatt;
        this.statusPanel = statusPanel;
        this.tanggalPasang = tanggalPasang;
        this.catatan = catatan;
        this.idKomunitas = idKomunitas;
    }

    public int getKodePanel() {
        return kodePanel;
    }

    public void setKodePanel(int kodePanel) {
        this.kodePanel = kodePanel;
    }

    public BigDecimal getKapasitasWatt() {
        return kapasitasWatt;
    }

    public void setKapasitasWatt(BigDecimal kapasitasWatt) {
        this.kapasitasWatt = kapasitasWatt;
    }

    public String getStatusPanel() {
        return statusPanel;
    }

    public void setStatusPanel(String statusPanel) {
        this.statusPanel = statusPanel;
    }

    public Date getTanggalPasang() {
        return tanggalPasang;
    }

    public void setTanggalPasang(Date tanggalPasang) {
        this.tanggalPasang = tanggalPasang;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }

    public int getIdKomunitas() {
        return idKomunitas;
    }

    public void setIdKomunitas(int idKomunitas) {
        this.idKomunitas = idKomunitas;
    }
    
    

}