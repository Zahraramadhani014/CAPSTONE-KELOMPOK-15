package Model;

import java.util.Date;

public class Komunitas {
    private int idKomunitas;
    private String namaKomunitas;
    private String lokasi;
    private String kontakPengurus;
    private Date tanggalMulaiOperasi;
    private String statusKomunitas; // AKTIF / NONAKTIF

    public Komunitas() {}

    public Komunitas(int idKomunitas, String namaKomunitas, String lokasi, String kontakPengurus,
                     Date tanggalMulaiOperasi, String statusKomunitas) {
        this.idKomunitas = idKomunitas;
        this.namaKomunitas = namaKomunitas;
        this.lokasi = lokasi;
        this.kontakPengurus = kontakPengurus;
        this.tanggalMulaiOperasi = tanggalMulaiOperasi;
        this.statusKomunitas = statusKomunitas;
    }

    public int getIdKomunitas() { return idKomunitas; }
    public void setIdKomunitas(int idKomunitas) { this.idKomunitas = idKomunitas; }

    public String getNamaKomunitas() { return namaKomunitas; }
    public void setNamaKomunitas(String namaKomunitas) { this.namaKomunitas = namaKomunitas; }

    public String getLokasi() { return lokasi; }
    public void setLokasi(String lokasi) { this.lokasi = lokasi; }

    public String getKontakPengurus() { return kontakPengurus; }
    public void setKontakPengurus(String kontakPengurus) { this.kontakPengurus = kontakPengurus; }

    public Date getTanggalMulaiOperasi() { return tanggalMulaiOperasi; }
    public void setTanggalMulaiOperasi(Date tanggalMulaiOperasi) { this.tanggalMulaiOperasi = tanggalMulaiOperasi; }

    public String getStatusKomunitas() { return statusKomunitas; }
    public void setStatusKomunitas(String statusKomunitas) { this.statusKomunitas = statusKomunitas; }
}