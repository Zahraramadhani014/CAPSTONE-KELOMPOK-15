package Model;

import java.math.BigDecimal;
import java.util.Date;

public class Pembayaran {
    private int idPembayaran;
    private Date tanggalPembayaran;
    private String metodePembayaran;
    private BigDecimal jumlahBayar;
    private String statusPembayaran;
    private int idTagihanBulanan;
    private String wargaNik;  

    public Pembayaran(int idPembayaran, Date tanggalPembayaran, String metodePembayaran, BigDecimal jumlahBayar, String statusPembayaran, int idTagihanBulanan, String wargaNik) {
        this.idPembayaran = idPembayaran;
        this.tanggalPembayaran = tanggalPembayaran;
        this.metodePembayaran = metodePembayaran;
        this.jumlahBayar = jumlahBayar;
        this.statusPembayaran = statusPembayaran;
        this.idTagihanBulanan = idTagihanBulanan;
        this.wargaNik = wargaNik;
    }

    public int getIdPembayaran() {
        return idPembayaran;
    }

    public void setIdPembayaran(int idPembayaran) {
        this.idPembayaran = idPembayaran;
    }

    public Date getTanggalPembayaran() {
        return tanggalPembayaran;
    }

    public void setTanggalPembayaran(Date tanggalPembayaran) {
        this.tanggalPembayaran = tanggalPembayaran;
    }

    public String getMetodePembayaran() {
        return metodePembayaran;
    }

    public void setMetodePembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }

    public BigDecimal getJumlahBayar() {
        return jumlahBayar;
    }

    public void setJumlahBayar(BigDecimal jumlahBayar) {
        this.jumlahBayar = jumlahBayar;
    }

    public String getStatusPembayaran() {
        return statusPembayaran;
    }

    public void setStatusPembayaran(String statusPembayaran) {
        this.statusPembayaran = statusPembayaran;
    }

    public int getIdTagihanBulanan() {
        return idTagihanBulanan;
    }

    public void setIdTagihanBulanan(int idTagihanBulanan) {
        this.idTagihanBulanan = idTagihanBulanan;
    }

    public String getWargaNik() {
        return wargaNik;
    }

    public void setWargaNik(String wargaNik) {
        this.wargaNik = wargaNik;
    }

    
}