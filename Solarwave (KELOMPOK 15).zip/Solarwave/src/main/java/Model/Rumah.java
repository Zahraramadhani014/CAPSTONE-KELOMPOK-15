package Model;

import java.util.Date;

public class Rumah {
    private int idRumah;
    private String nomorRumah;
    private String namaPemilik;
    private String alamatRumah;
    private String noTelp;
    private String statusKoneksi;
    private Date tanggalBergabung;
    private int idKomunitas;
    private String idUser;

    public Rumah() {}

    public Rumah(int idRumah, String nomorRumah, String namaPemilik, String alamatRumah, String noTelp,
                 String statusKoneksi, Date tanggalBergabung, int idKomunitas, String idUser) {
        this.idRumah = idRumah;
        this.nomorRumah = nomorRumah;
        this.namaPemilik = namaPemilik;
        this.alamatRumah = alamatRumah;
        this.noTelp = noTelp;
        this.statusKoneksi = statusKoneksi;
        this.tanggalBergabung = tanggalBergabung;
        this.idKomunitas = idKomunitas;
        this.idUser = idUser;
    }

    public int getIdRumah() { return idRumah; }
    public void setIdRumah(int idRumah) { this.idRumah = idRumah; }

    public String getNomorRumah() { return nomorRumah; }
    public void setNomorRumah(String nomorRumah) { this.nomorRumah = nomorRumah; }

    public String getNamaPemilik() { return namaPemilik; }
    public void setNamaPemilik(String namaPemilik) { this.namaPemilik = namaPemilik; }

    public String getAlamatRumah() { return alamatRumah; }
    public void setAlamatRumah(String alamatRumah) { this.alamatRumah = alamatRumah; }

    public String getNoTelp() { return noTelp; }
    public void setNoTelp(String noTelp) { this.noTelp = noTelp; }

    public String getStatusKoneksi() { return statusKoneksi; }
    public void setStatusKoneksi(String statusKoneksi) { this.statusKoneksi = statusKoneksi; }

    public Date getTanggalBergabung() { return tanggalBergabung; }
    public void setTanggalBergabung(Date tanggalBergabung) { this.tanggalBergabung = tanggalBergabung; }

    public int getIdKomunitas() { return idKomunitas; }
    public void setIdKomunitas(int idKomunitas) { this.idKomunitas = idKomunitas; }

    public String getIdUser() { return idUser; }
    public void setIdUser(String idUser) { this.idUser = idUser; }
}