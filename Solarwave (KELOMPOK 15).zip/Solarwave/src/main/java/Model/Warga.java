package Model;

import java.sql.Date;

public class Warga extends User {
    private String nik;
    private String noKk;
    private Date tanggalBergabung;

    public Warga(String idUser, String nama, String alamat, String noTelepon,
                 String email, String username, String password,
                 String nik, String noKk, Date tanggalBergabung) {
        super(idUser, nama, alamat, noTelepon, email, username, password, "WARGA");
        this.nik = nik;
        this.noKk = noKk;
        this.tanggalBergabung = tanggalBergabung;
    }

    public String getNik() { return nik; }
    public void setNik(String nik) { this.nik = nik; }

    public String getNoKk() { return noKk; }
    public void setNoKk(String noKk) { this.noKk = noKk; }

    public Date getTanggalBergabung() { return tanggalBergabung; }
    public void setTanggalBergabung(Date tanggalBergabung) { this.tanggalBergabung = tanggalBergabung; }
    
    
    @Override
    public String toString() {
        return "Warga{idUser='" + getIdUser() + "', nik='" + nik
                + "', noKk='" + noKk + "', tanggalBergabung=" + tanggalBergabung + "}";
    }
    
   @Override
    public String getRoleName() {               
        return "WARGA";
    }
}

