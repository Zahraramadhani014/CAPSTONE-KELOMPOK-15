package Model;

import java.util.Date;
import java.math.BigDecimal;


public class DistribusiEnergi {
    private int idDistribusi;
    private Date tanggalDistribusi;
    private BigDecimal jumlahKwh;
    private BigDecimal biayaperKwh; 
    private String catatan;
    private int idRumah;

    public DistribusiEnergi(int idDistribusi, Date tanggalDistribusi, BigDecimal jumlahKwh, BigDecimal biayaperKwh, String catatan, int idRumah) {
        this.idDistribusi = idDistribusi;
        this.tanggalDistribusi = tanggalDistribusi;
        this.jumlahKwh = jumlahKwh;
        this.biayaperKwh = biayaperKwh;
        this.catatan = catatan;
        this.idRumah = idRumah;
    }


    public int getIdDistribusi() {
        return idDistribusi;
    }

    public void setIdDistribusi(int idDistribusi) {
        this.idDistribusi = idDistribusi;
    }

    public Date getTanggalDistribusi() {
        return tanggalDistribusi;
    }

    public void setTanggalDistribusi(Date tanggalDistribusi) {
        this.tanggalDistribusi = tanggalDistribusi;
    }

    public BigDecimal getJumlahKwh() {
        return jumlahKwh;
    }

    public void setJumlahKwh(BigDecimal jumlahKwh) {
        this.jumlahKwh = jumlahKwh;
    }

    public BigDecimal getBiayaperKwh() {
        return biayaperKwh;
    }

    public void setBiayaperKwh(BigDecimal biayaperKwh) {
        this.biayaperKwh = biayaperKwh;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }
    

    public int getIdRumah() {
        return idRumah;
    }

    public void setIdRumah(int idRumah) {
        this.idRumah = idRumah;
    }

    
}
