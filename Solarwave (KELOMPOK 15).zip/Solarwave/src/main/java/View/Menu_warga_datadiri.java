package View;

public class Menu_warga_datadiri extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_warga_datadiri.class.getName());

    /**
     * Creates new form Menu_Warga_DataRumah
     */
    // simpan model agar bisa dipakai ulang
    private javax.swing.table.DefaultTableModel wargaModel;
    private VerticalRecordTableModel vModel;
    
     // ==== KONSTANTA VALIDASI (sesuai skema DB) ====
    private static final int MAX_NAMA     = 50;   // user.nama
    private static final int MAX_ALAMAT   = 100;  // user.alamat
    private static final int MAX_TELP     = 20;   // user.no_telepon (char(20))
    private static final int MAX_EMAIL    = 50;   // user.email
    private static final int MAX_USERNAME = 20;   // user.username
    private static final int LEN_PASSWORD = 7;    // user.password (char(7))
    private static final int LEN_NIK      = 16;   // warga.nik (char(16))
    private static final int LEN_NOKK     = 16;   // warga.no_kk (char(16))

    private static final java.awt.Color ERR_BG = new java.awt.Color(255, 235, 238);
    private static final java.util.regex.Pattern P_NAMA
            = java.util.regex.Pattern.compile("^[A-Za-zÀ-ÖØ-öø-ÿ' .\\-]{3," + MAX_NAMA + "}$");
    private static final java.util.regex.Pattern P_TELP
            = java.util.regex.Pattern.compile("^\\d{10," + MAX_TELP + "}$");
    private static final java.util.regex.Pattern P_EMAIL
            = java.util.regex.Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final java.util.regex.Pattern P_USERNAME
            = java.util.regex.Pattern.compile("^[A-Za-z0-9_]{3," + MAX_USERNAME + "}$");

    
    /// ===== util: field read-only dengan popup saat diklik =====
    private void guardReadOnly(javax.swing.JTextField tf) {
        tf.setEditable(false);
        tf.setFocusable(false);
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                javax.swing.JOptionPane.showMessageDialog(Menu_warga_datadiri.this,
                        "Data ini tidak boleh diubah.");
                e.consume();
            }
        });
        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
    }

     // ===== reset warna error
    private void resetFieldStyles() {
        java.awt.Color def = javax.swing.UIManager.getColor("TextField.background");
        nama.setBackground(def);
        username.setBackground(def);
        password.setBackground(def);
        nik.setBackground(def);
        nokk.setBackground(def);
        alamat.setBackground(def);
        notelp.setBackground(def);
        email.setBackground(def);
    }

    // ===== validasi form sesuai skema DB
    private java.util.List<String> validateUserForm() {
        resetFieldStyles();
        java.util.List<String> errs = new java.util.ArrayList<>();

        String vNama   = nama.getText().trim();
        String vNik    = nik.getText().trim();
        String vNoKk   = nokk.getText().trim();
        String vAlamat = alamat.getText().trim();
        String vTelp   = notelp.getText().trim();
        String vEmail  = email.getText().trim();
        String vUser   = username.getText().trim();
        String vPass   = password.getText().trim();

        if (vNama.isEmpty() || !P_NAMA.matcher(vNama).matches()) {
            errs.add("Nama 3–" + MAX_NAMA + " karakter (huruf, spasi, titik, apostrof, minus).");
            nama.setBackground(ERR_BG);
        }
        if (vNik.length() != LEN_NIK || !vNik.matches("\\d{" + LEN_NIK + "}")) {
            errs.add("NIK harus " + LEN_NIK + " digit angka.");
            nik.setBackground(ERR_BG);
        }
        if (vNoKk.length() != LEN_NOKK || !vNoKk.matches("\\d{" + LEN_NOKK + "}")) {
            errs.add("No.KK harus " + LEN_NOKK + " digit angka.");
            nokk.setBackground(ERR_BG);
        }
        if (vAlamat.isEmpty() || vAlamat.length() > MAX_ALAMAT) {
            errs.add("Alamat wajib (maks " + MAX_ALAMAT + " karakter).");
            alamat.setBackground(ERR_BG);
        }
        if (!P_TELP.matcher(vTelp).matches()) {
            errs.add("No.Telp 10–" + MAX_TELP + " digit angka.");
            notelp.setBackground(ERR_BG);
        }
        if (vEmail.isEmpty() || vEmail.length() > MAX_EMAIL || !P_EMAIL.matcher(vEmail).matches()) {
            errs.add("Email tidak valid (maks " + MAX_EMAIL + " karakter).");
            email.setBackground(ERR_BG);
        }
        if (!P_USERNAME.matcher(vUser).matches()) {
            errs.add("Username 3–" + MAX_USERNAME + " (huruf/angka/underscore).");
            username.setBackground(ERR_BG);
        }
        if (vPass.length() != LEN_PASSWORD) {
            errs.add("Password harus tepat " + LEN_PASSWORD + " karakter.");
            password.setBackground(ERR_BG);
        }

        // berjaga-jaga: kolom yang memang tak boleh diubah
        if (iduser.isEditable() || iduser.isFocusable()) {
            errs.add("Id User tidak boleh diubah.");
        }
        if (bergabung.isEditable() || bergabung.isFocusable()) {
            errs.add("Tanggal bergabung tidak boleh diubah.");
        }
        return errs;
    }

    public Menu_warga_datadiri() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);
        loadTabel();

        var url = getClass().getResource("/View/assets/TAGIHAN_BULANAN_WARGA_3.png");
        jLabel1.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel1, getContentPane().getComponentCount() - 1);

        // kunci field yang tidak boleh diubah
        guardReadOnly(iduser);
        guardReadOnly(bergabung);

        muatulang = new javax.swing.JButton();
        muatulang.setBorder(null);
        muatulang.setContentAreaFilled(false);
        muatulang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muatulangActionPerformed(evt);
            }
        });
        getContentPane().add(muatulang);
        muatulang.setBounds(380, 440, 110, 30); // posisimu sendiri

    }

    private void loadTabel() {
        try {
            String idUser = Model.Session.idUser;
            if (idUser == null || idUser.isBlank()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Session kosong. Silakan login ulang.");
                return;
            }

            dao.WargaDao dao = new dao.WargaDao();
            // Ekspektasi kolom: id_user,nama,nik,no_kk,alamat,no_telp,email,username,password,tanggal_bergabung
            wargaModel = dao.loadTableByUserId(idUser);

            vModel = new VerticalRecordTableModel(wargaModel);
            jTable1.setModel(vModel);
            jTable1.getTableHeader().setReorderingAllowed(false);
            jTable1.setRowHeight(24);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(120);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(300);

            if (wargaModel.getRowCount() > 0) {
                vModel.setRowIndex(0);
                fillTextFieldsFromModel(0);
            }
        } catch (java.sql.SQLException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Gagal memuat data diri: " + ex.getMessage(),
                    "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    // sinkronkan tabel -> form
    private void fillTextFieldsFromModel(int row) {
        if (wargaModel == null || wargaModel.getRowCount() == 0) {
            return;
        }

        iduser.setText(String.valueOf(wargaModel.getValueAt(row, 0)));   // id_user
        nama.setText(String.valueOf(wargaModel.getValueAt(row, 1)));     // nama
        nik.setText(String.valueOf(wargaModel.getValueAt(row, 2)));      // nik
        nokk.setText(String.valueOf(wargaModel.getValueAt(row, 3)));     // no_kk
        alamat.setText(String.valueOf(wargaModel.getValueAt(row, 4)));   // alamat
        notelp.setText(String.valueOf(wargaModel.getValueAt(row, 5)));   // no_telp
        email.setText(String.valueOf(wargaModel.getValueAt(row, 6)));    // email
        username.setText(String.valueOf(wargaModel.getValueAt(row, 7))); // username
        password.setText(String.valueOf(wargaModel.getValueAt(row, 8))); // password
        Object tgl = wargaModel.getValueAt(row, 9);                      // tanggal_bergabung
        bergabung.setText(tgl == null ? "" : tgl.toString());
    }

    // muat ulang data lama
    private void reloadFromExistingModel() {
        if (wargaModel != null && wargaModel.getRowCount() > 0 && vModel != null) {
            vModel.setRowIndex(0);
            fillTextFieldsFromModel(0);
            resetFieldStyles();
        }
    }

    // ===== model tabel vertikal (Field | Value) =====
    private static final class VerticalRecordTableModel extends javax.swing.table.AbstractTableModel {

        private final javax.swing.table.TableModel source;
        private int rowIndex = -1;

        VerticalRecordTableModel(javax.swing.table.TableModel source) {
            this.source = source;
        }

        public void setRowIndex(int row) {
            this.rowIndex = row;
            fireTableDataChanged();
        }

        @Override
        public int getRowCount() {
            return source.getColumnCount();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public String getColumnName(int c) {
            return (c == 0) ? "Field" : "Value";
        }

        @Override
        public Object getValueAt(int r, int c) {
            if (c == 0) {
                return source.getColumnName(r);
            }
            if (rowIndex < 0) {
                return "";
            }
            return source.getValueAt(rowIndex, r);
        }

        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Kembali = new javax.swing.JButton();
        perbarui = new javax.swing.JButton();
        muatulang = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        iduser = new javax.swing.JTextField();
        nama = new javax.swing.JTextField();
        password = new javax.swing.JTextField();
        nokk = new javax.swing.JTextField();
        notelp = new javax.swing.JTextField();
        alamat = new javax.swing.JTextField();
        bergabung = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        nik = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(800, 500));
        getContentPane().setLayout(null);

        Kembali.setBorder(null);
        Kembali.setContentAreaFilled(false);
        Kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KembaliActionPerformed(evt);
            }
        });
        getContentPane().add(Kembali);
        Kembali.setBounds(130, 460, 110, 40);

        perbarui.setBorder(null);
        perbarui.setContentAreaFilled(false);
        perbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                perbaruiActionPerformed(evt);
            }
        });
        getContentPane().add(perbarui);
        perbarui.setBounds(540, 460, 110, 30);

        muatulang.setBorder(null);
        muatulang.setContentAreaFilled(false);
        muatulang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muatulangActionPerformed(evt);
            }
        });
        getContentPane().add(muatulang);
        muatulang.setBounds(340, 460, 110, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id_User", "Nama", "NIK", "No.KK", "Alamat", "No.Telp", "Email", "Tgl.Bergabung", "Username", "Password"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(380, 240, 290, 210);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Password");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(470, 170, 100, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Id User");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(220, 70, 50, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Nama");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(220, 120, 50, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("NIK");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(230, 170, 40, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("No.KK");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(220, 220, 100, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Alamat");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(220, 270, 60, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("No.Telp");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(220, 320, 100, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Email");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(230, 370, 40, 20);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Tgl.Bergabung");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(460, 70, 100, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setText("Username");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(470, 120, 100, 20);

        iduser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iduserActionPerformed(evt);
            }
        });
        getContentPane().add(iduser);
        iduser.setBounds(140, 90, 220, 30);

        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });
        getContentPane().add(nama);
        nama.setBounds(140, 140, 220, 30);

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        getContentPane().add(password);
        password.setBounds(410, 190, 220, 30);
        getContentPane().add(nokk);
        nokk.setBounds(140, 240, 220, 30);

        notelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notelpActionPerformed(evt);
            }
        });
        getContentPane().add(notelp);
        notelp.setBounds(140, 340, 220, 30);
        getContentPane().add(alamat);
        alamat.setBounds(140, 290, 220, 30);
        getContentPane().add(bergabung);
        bergabung.setBounds(410, 90, 220, 30);
        getContentPane().add(username);
        username.setBounds(410, 140, 220, 30);

        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email);
        email.setBounds(140, 390, 220, 30);

        nik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nikActionPerformed(evt);
            }
        });
        getContentPane().add(nik);
        nik.setBounds(140, 190, 220, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\TAGIHAN_BULANAN_WARGA_3.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(-4, -4, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KembaliActionPerformed
        Menu_warga warga = new Menu_warga();
        warga.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KembaliActionPerformed

    private void perbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perbaruiActionPerformed
      
    try {
        if (iduser.getText().isBlank()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Id User kosong.");
            return;
        }
        final String id = iduser.getText().trim();

        // 1) VALIDASI
        java.util.List<String> errs = validateUserForm();
        if (!errs.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(
                this,
                "Periksa kembali data berikut:\n- " + String.join("\n- ", errs),
                "Validasi gagal",
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // 2) KONFIRMASI
        int ok = javax.swing.JOptionPane.showConfirmDialog(
            this, "Simpan perubahan data akun Anda?",
            "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
        if (ok != javax.swing.JOptionPane.YES_OPTION) return;

        // 3) AMBIL NILAI BERSIH
        String vNama   = nama.getText().trim();
        String vNik    = nik.getText().trim();
        String vNoKk   = nokk.getText().trim();
        String vAlamat = alamat.getText().trim();
        String vTelp   = notelp.getText().trim();
        String vEmail  = email.getText().trim();
        String vUser   = username.getText().trim();
        String vPass   = password.getText().trim();

        // 4) UPDATE TRANSAKSIONAL
        try (java.sql.Connection c = dao.DB.getConnection()) {
            boolean old = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                // Cek username unik (kecuali dirinya)
                try (java.sql.PreparedStatement ps = c.prepareStatement(
                        "SELECT 1 FROM `user` WHERE username=? AND id_user<>? LIMIT 1")) {
                    ps.setString(1, vUser);
                    ps.setString(2, id);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) throw new java.sql.SQLException("Username sudah dipakai pengguna lain.");
                    }
                }
                // Cek NIK unik (kecuali dirinya)
                try (java.sql.PreparedStatement ps = c.prepareStatement(
                        "SELECT 1 FROM warga WHERE nik=? AND id_user<>? LIMIT 1")) {
                    ps.setString(1, vNik);
                    ps.setString(2, id);
                    try (java.sql.ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) throw new java.sql.SQLException("NIK sudah dipakai pengguna lain.");
                    }
                }

                // a) UPDATE user
                try (java.sql.PreparedStatement ps = c.prepareStatement(
                        "UPDATE `user` SET nama=?, alamat=?, no_telepon=?, email=?, username=?, password=? " +
                        "WHERE id_user=?")) {
                    int i = 1;
                    ps.setString(i++, vNama);
                    ps.setString(i++, vAlamat);
                    ps.setString(i++, vTelp);
                    ps.setString(i++, vEmail);
                    ps.setString(i++, vUser);
                    ps.setString(i++, vPass);
                    ps.setString(i,   id);
                    ps.executeUpdate();
                }

                // b) UPDATE warga
                try (java.sql.PreparedStatement ps = c.prepareStatement(
                        "UPDATE warga SET nik=?, no_kk=? WHERE id_user=?")) {
                    ps.setString(1, vNik);
                    ps.setString(2, vNoKk);
                    ps.setString(3, id);
                    ps.executeUpdate();
                }

                c.commit();
                c.setAutoCommit(old);

                javax.swing.JOptionPane.showMessageDialog(this, "Perubahan tersimpan.");
                loadTabel(); // refresh tampilan & tabel vertikal
            } catch (java.sql.SQLException ex) {
                c.rollback();

                // Pesan yang lebih ramah untuk pelanggaran unik/constraint
                String msg = ex.getMessage();
                if (msg != null && msg.toLowerCase().contains("duplicate")) {
                    if (msg.toLowerCase().contains("username")) {
                        msg = "Username sudah dipakai pengguna lain.";
                    } else if (msg.toLowerCase().contains("nik")) {
                        msg = "NIK sudah dipakai pengguna lain.";
                    }
                }
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal menyimpan:\n" + msg,
                        "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (Exception ex) {
        java.util.logging.Logger.getLogger(getClass().getName())
                .log(java.util.logging.Level.SEVERE, null, ex);
        javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
    }


    }//GEN-LAST:event_perbaruiActionPerformed

    private void muatulangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muatulangActionPerformed
        int ok = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan dan muat ulang data?",
                "Muat Ulang", javax.swing.JOptionPane.YES_NO_OPTION);
        if (ok != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        loadTabel();                 // ambil ulang dari DB
        javax.swing.JOptionPane.showMessageDialog(this, "Data dikembalikan seperti semula.");

    }//GEN-LAST:event_muatulangActionPerformed

    private void notelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_notelpActionPerformed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void iduserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iduserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iduserActionPerformed

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void nikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nikActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nikActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_warga_datadiri().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Kembali;
    private javax.swing.JTextField alamat;
    private javax.swing.JTextField bergabung;
    private javax.swing.JTextField email;
    private javax.swing.JTextField iduser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton muatulang;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nik;
    private javax.swing.JTextField nokk;
    private javax.swing.JTextField notelp;
    private javax.swing.JTextField password;
    private javax.swing.JButton perbarui;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
