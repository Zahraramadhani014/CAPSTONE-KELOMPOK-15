package View;

import dao.AnggotaKomunitasDao;
import java.sql.SQLException;

public class Menu_superadmin_anggota extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_anggota.class.getName());
    private final AnggotaKomunitasDao anggotaDao = new AnggotaKomunitasDao();

    // === STATE & VALIDATOR ===
    private boolean editingExisting = false;
    
    // ===== GUARD untuk cegah double fire tombol =====
    private boolean busyAdd = false;
    private boolean busyUpdate = false;


    // guard: readonly TAPI hanya munculkan pesan saat sedang edit data lama
    private void guardReadOnlyWhenEditing(javax.swing.JTextField tf, String label) {
        tf.setEditable(false);
        tf.setFocusable(true);
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));

        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_superadmin_anggota.this, label + " tidak boleh diubah.");
                    e.consume();
                }
            }
        });
        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
        tf.putClientProperty("ro-guard", Boolean.TRUE);
    }

    // ====== POLA & HELPER VALIDASI ======
    private static final java.util.regex.Pattern P_IDUSER = java.util.regex.Pattern.compile("^USR\\d{3}$");  // USR001
    private static final java.util.regex.Pattern P_NOANGG = java.util.regex.Pattern.compile("^KA\\d{3}$");   // KA001
    private static final java.util.regex.Pattern P_TELP = java.util.regex.Pattern.compile("^[0-9+\\-\\s]{8,20}$");
    private static final java.util.regex.Pattern P_EMAIL = java.util.regex.Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final java.util.regex.Pattern P_USERNAME = java.util.regex.Pattern.compile("^[a-z0-9._-]{3,20}$"); // huruf kecil + angka
    // Batas sesuai skema DB
    private static final int MAX_NAMA = 50;
    private static final int MAX_AREA = 50;
    private static final int MAX_ALAMAT = 100; // opsional, biar konsisten

// Hanya huruf (A–Z a–z), spasi, titik, koma, apostrof, dan tanda hubung. Panjang 2–50
    private static final java.util.regex.Pattern P_NAMA
            = java.util.regex.Pattern.compile("^[A-Za-z\\s.'-]{2," + MAX_NAMA + "}$");

// Area: huruf/angka/spasi dan karakter dasar -_/,&. Panjang 3–50
    private static final java.util.regex.Pattern P_AREA
            = java.util.regex.Pattern.compile("^[A-Za-z0-9\\s\\-_/,&.]{3," + MAX_AREA + "}$");

// password di DB char(7) → harus 7 karakter
    private static final int PASSWORD_LEN = 7;

    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }

// Validasi untuk TAMBAH (ID & Tgl bergabung wajib (AUTO))
    private java.util.List<String> validateForInsert() {
        var errs = new java.util.ArrayList<String>();

        String sId = id.getText().trim();
        String sTgl = tangga.getText().trim();
        String sNama = nama.getText().trim();
        String sNo = no.getText().trim();
        String sAlamat = alamat.getText().trim();
        String sTelp = notelp.getText().trim();
        String sEmail = email.getText().trim();
        String sArea = area.getText().trim();
        String sUser = username.getText().trim();
        String sPass = password.getText().trim();

        // ID & TGL: harus (AUTO)
        if (!"(AUTO)".equalsIgnoreCase(sId)) {
            errs.add("ID User diisi otomatis. Biarkan '(AUTO)'.");
        }
        if (!"(AUTO)".equalsIgnoreCase(sTgl)) {
            errs.add("Tgl. Bergabung diisi otomatis. Biarkan '(AUTO)'.");
        }

        if (sNama.isBlank()) {
            errs.add("Nama wajib diisi.");
        } else {
            if (sNama.length() > MAX_NAMA) {
                errs.add("Nama maksimal " + MAX_NAMA + " karakter.");
            }
            if (!P_NAMA.matcher(sNama).matches()) {
                errs.add("Nama hanya huruf/spasi/tanda umum (2–" + MAX_NAMA + ").");
            }
        }
        if (!P_NOANGG.matcher(sNo).matches()) {
            errs.add("No. Anggota wajib format KAxxx (mis. KA001).");
        }
        if (sAlamat.isBlank()) {
            errs.add("Alamat wajib diisi.");
        } else if (sAlamat.length() > MAX_ALAMAT) {
            errs.add("Alamat maksimal " + MAX_ALAMAT + " karakter.");
        }
        if (!P_TELP.matcher(sTelp).matches()) {
            errs.add("No. Telp 8–20 karakter (angka/spasi/+/-).");
        }
        if (!P_EMAIL.matcher(sEmail).matches()) {
            errs.add("Email tidak valid.");
        }
        if (sArea.isBlank()) {
            errs.add("Area Tanggung Jawab wajib diisi.");
        } else {
            if (sArea.length() > MAX_AREA) {
                errs.add("Area Tanggung Jawab maksimal " + MAX_AREA + " karakter.");
            }
            if (!P_AREA.matcher(sArea).matches()) {
                errs.add("Area Tanggung Jawab hanya huruf/angka & -_/,&. (3–" + MAX_AREA + ").");
            }
        }
        if (!P_USERNAME.matcher(sUser).matches()) {
            errs.add("Username 3–20 (huruf kecil, angka, . _ -).");
        }
        if (sPass.length() != PASSWORD_LEN) {
            errs.add("Password harus tepat " + PASSWORD_LEN + " karakter.");
        }

        return errs;
    }

// Validasi untuk PERBARUI (ID wajib format USRxxx & tidak boleh diubah)
    private java.util.List<String> validateForUpdate() {
        var errs = new java.util.ArrayList<String>();

        String sId = id.getText().trim();
        String sNama = nama.getText().trim();
        String sNo = no.getText().trim();
        String sAlamat = alamat.getText().trim();
        String sTelp = notelp.getText().trim();
        String sEmail = email.getText().trim();
        String sArea = area.getText().trim();
        String sUser = username.getText().trim();
        String sPass = password.getText().trim(); // boleh kosong = tidak ganti

        if (!P_IDUSER.matcher(sId).matches()) {
            errs.add("ID User wajib format USRxxx (mis. USR001).");
        }
        if (sNama.isBlank()) {
            errs.add("Nama wajib diisi.");
        } else {
            if (sNama.length() > MAX_NAMA) {
                errs.add("Nama maksimal " + MAX_NAMA + " karakter.");
            }
            if (!P_NAMA.matcher(sNama).matches()) {
                errs.add("Nama hanya huruf/spasi/tanda umum (2–" + MAX_NAMA + ").");
            }
        }
        if (!P_NOANGG.matcher(sNo).matches()) {
            errs.add("No. Anggota wajib format KAxxx (mis. KA001).");
        }
        if (sAlamat.isBlank()) {
            errs.add("Alamat wajib diisi.");
        } else if (sAlamat.length() > MAX_ALAMAT) {
            errs.add("Alamat maksimal " + MAX_ALAMAT + " karakter.");
        }
        if (!P_TELP.matcher(sTelp).matches()) {
            errs.add("No. Telp 8–20 karakter (angka/spasi/+/-).");
        }
        if (!P_EMAIL.matcher(sEmail).matches()) {
            errs.add("Email tidak valid.");
        }
        if (sArea.isBlank()) {
            errs.add("Area Tanggung Jawab wajib diisi.");
        } else {
            if (sArea.length() > MAX_AREA) {
                errs.add("Area Tanggung Jawab maksimal " + MAX_AREA + " karakter.");
            }
            if (!P_AREA.matcher(sArea).matches()) {
                errs.add("Area Tanggung Jawab hanya huruf/angka & -_/,&. (3–" + MAX_AREA + ").");
            }
        }
        if (!P_USERNAME.matcher(sUser).matches()) {
            errs.add("Username 3–20 (huruf kecil, angka, . _ -).");
        }
        if (!sPass.isBlank() && sPass.length() != PASSWORD_LEN) {
            errs.add("Password (jika diisi) harus tepat " + PASSWORD_LEN + " karakter.");
        }

        return errs;
    }

    /**
     * Creates new form Menu_superadmin
     */
    public Menu_superadmin_anggota() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null); // center window
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                reloadTable();
                jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
                clearFormForInsert(); // << tambah ini
            }
        });

        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                fillFieldsFromSelectedRow();
            }
        });

        // kunci, tapi pesan hanya muncul saat editingExisting = true
        guardReadOnlyWhenEditing(id, "ID User");
        guardReadOnlyWhenEditing(tangga, "Tanggal bergabung");
    }

    private void reloadTable() {
        try {
            jTable1.setModel(anggotaDao.loadTableModelForAdmin());
        } catch (SQLException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load data: " + ex.getMessage());
        }
    }

    // === Mode TAMBAH ===
    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();

        id.setText("(AUTO)");
        tangga.setText("(AUTO)");
        nama.setText("");
        no.setText("");
        alamat.setText("");
        notelp.setText("");
        email.setText("");
        area.setText("");
        username.setText("");
        password.setText("");

        id.setEditable(false);
        tangga.setEditable(false);
    }

    // === Ambil data dari tabel ke field (mode EDIT) ===
    private void fillFieldsFromSelectedRow() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        editingExisting = true;

        id.setText(String.valueOf(jTable1.getValueAt(r, 0)));
        nama.setText(String.valueOf(jTable1.getValueAt(r, 1)));
        no.setText(String.valueOf(jTable1.getValueAt(r, 2)));
        alamat.setText(String.valueOf(jTable1.getValueAt(r, 3)));
        notelp.setText(String.valueOf(jTable1.getValueAt(r, 4)));
        email.setText(String.valueOf(jTable1.getValueAt(r, 5)));
        area.setText(String.valueOf(jTable1.getValueAt(r, 6)));
        tangga.setText(String.valueOf(jTable1.getValueAt(r, 7))); // asli dari DB
        username.setText(String.valueOf(jTable1.getValueAt(r, 8)));
        password.setText(String.valueOf(jTable1.getValueAt(r, 9)));
    }

    // Helper "required"
    private String req(javax.swing.JTextField tf, String label) {
        String v = tf.getText().trim();
        if (v.isBlank()) {
            throw new IllegalArgumentException(label + " tidak boleh kosong.");
        }
        return v;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        KELUAR = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        nama = new javax.swing.JTextField();
        no = new javax.swing.JTextField();
        alamat = new javax.swing.JTextField();
        notelp = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        area = new javax.swing.JTextField();
        tangga = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        password = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("Anggota Komunitas");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(440, 10, 260, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("ID User");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 120, 70, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("No. Anggota");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 180, 110, 20);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 430, 90, 23);

        jButton2.setText("Hapus");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(230, 430, 90, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(120, 430, 90, 23);

        jButton4.setText("Muat Ulang");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(170, 470, 100, 23);

        KELUAR.setText("Kembali");
        KELUAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KELUARActionPerformed(evt);
            }
        });
        getContentPane().add(KELUAR);
        KELUAR.setBounds(50, 470, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id_user", "Nama", "No_Anggota", "Alamat", "No_Telp", "Email", "Area_Tanggung_Jawab", "Tgl_Bergabung", "Username", "Password"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 39, 452, 440);

        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });
        getContentPane().add(nama);
        nama.setBounds(150, 150, 170, 30);

        no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noActionPerformed(evt);
            }
        });
        getContentPane().add(no);
        no.setBounds(150, 180, 170, 30);

        alamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alamatActionPerformed(evt);
            }
        });
        getContentPane().add(alamat);
        alamat.setBounds(150, 210, 170, 30);

        notelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notelpActionPerformed(evt);
            }
        });
        getContentPane().add(notelp);
        notelp.setBounds(150, 240, 170, 30);

        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email);
        email.setBounds(150, 270, 170, 30);

        area.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                areaActionPerformed(evt);
            }
        });
        getContentPane().add(area);
        area.setBounds(150, 300, 170, 30);

        tangga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tanggaActionPerformed(evt);
            }
        });
        getContentPane().add(tangga);
        tangga.setBounds(150, 330, 170, 30);

        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });
        getContentPane().add(username);
        username.setBounds(150, 360, 170, 30);

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        getContentPane().add(password);
        password.setBounds(150, 390, 170, 30);

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(150, 120, 170, 30);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Alamat");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(10, 210, 110, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("No. Telp");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(10, 240, 110, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Email");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 270, 110, 20);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Area Tanggung Jawab");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(10, 300, 140, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Tgl. Bergabung");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(10, 330, 110, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setText("Username");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(10, 360, 110, 20);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel14.setText("Password");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(10, 390, 110, 20);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel15.setText("Nama");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(10, 150, 110, 20);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (busyUpdate) return;              // debounce perbarui
    busyUpdate = true;
    jButton3.setEnabled(false);
    try {
        if (!editingExisting) {
            javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dari tabel dulu.");
            return;
        }

        var errs = validateForUpdate();
        if (!errs.isEmpty()) { 
            showErrors(errs); 
            return; 
        }

        String idUser   = id.getText().trim();
        String namaV    = nama.getText().trim();
        String noKartu  = no.getText().trim();
        String alamatV  = alamat.getText().trim();
        String noTelpV  = notelp.getText().trim();
        String emailV   = email.getText().trim();
        String areaV    = area.getText().trim();
        String userV    = username.getText().trim();
        String passV    = password.getText().trim(); // boleh kosong

        int ok = anggotaDao.updateAnggota(
                idUser, namaV, alamatV, noTelpV, emailV,
                userV, passV.isBlank() ? null : passV,
                noKartu, areaV, /*tgl*/ null // jangan ubah tanggal
        );

        javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Perbarui OK" : "Tidak ada yang diubah");
        reloadTable();
    } catch (IllegalArgumentException iae) {
        javax.swing.JOptionPane.showMessageDialog(this, iae.getMessage());
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
    } finally {
        busyUpdate = false;
        jButton3.setEnabled(true);
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void KELUARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KELUARActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KELUARActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            String idUser = req(id, "ID User");
            int yn = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Yakin hapus user: " + idUser + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION);
            if (yn != javax.swing.JOptionPane.YES_OPTION) return;

            int ok = anggotaDao.deleteByIdUser(idUser);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Hapus OK" : "Gagal hapus");
            reloadTable();
            clearFormForInsert();
        } catch (IllegalArgumentException iae) {
            javax.swing.JOptionPane.showMessageDialog(this, iae.getMessage());
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    
    }//GEN-LAST:event_jButton2ActionPerformed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_noActionPerformed

    private void alamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alamatActionPerformed

    private void notelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_notelpActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void areaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_areaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_areaActionPerformed

    private void tanggaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tanggaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggaActionPerformed

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         if (busyAdd) return;                 // debounce tambah
    busyAdd = true;
    jButton1.setEnabled(false);
    try {
        var errs = validateForInsert();
        if (!errs.isEmpty()) { 
            showErrors(errs); 
            return; 
        }

        // generate id user otomatis
        String idUser  = anggotaDao.nextUserId();
        String namaV   = nama.getText().trim();
        String noKartu = no.getText().trim();
        String alamatV = alamat.getText().trim();
        String noTelpV = notelp.getText().trim();
        String emailV  = email.getText().trim();
        String areaV   = area.getText().trim();
        String userV   = username.getText().trim();
        String passV   = password.getText().trim();

        String sIdKom = javax.swing.JOptionPane.showInputDialog(
                this, "Masukkan ID Komunitas (angka):", "ID Komunitas",
                javax.swing.JOptionPane.QUESTION_MESSAGE);
        if (sIdKom == null) return;
        int idKomunitas = Integer.parseInt(sIdKom.trim());

        int ok = anggotaDao.insertAnggota(
                idUser, namaV, alamatV, noTelpV, emailV,
                userV, passV, noKartu, areaV, /*tgl*/ null, // null → CURRENT_DATE di SQL
                idKomunitas
        );

        javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah");
        reloadTable();
        clearFormForInsert();
    } catch (NumberFormatException nfe) {
        javax.swing.JOptionPane.showMessageDialog(this, "ID Komunitas harus angka.");
    } catch (IllegalArgumentException iae) {
        javax.swing.JOptionPane.showMessageDialog(this, iae.getMessage());
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
    } finally {
        busyAdd = false;
        jButton1.setEnabled(true);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        int yn = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan & muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) return;

        reloadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");

    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_anggota().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KELUAR;
    private javax.swing.JTextField alamat;
    private javax.swing.JTextField area;
    private javax.swing.JTextField email;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField no;
    private javax.swing.JTextField notelp;
    private javax.swing.JTextField password;
    private javax.swing.JTextField tangga;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
