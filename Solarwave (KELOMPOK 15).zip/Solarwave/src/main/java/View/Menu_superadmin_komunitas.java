package View;

public class Menu_superadmin_komunitas extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_komunitas.class.getName());
    private final dao.KomunitasDao komunitasDao = new dao.KomunitasDao();

    // ====== STATE ======
    private boolean editingExisting = false; // true saat form menampilkan data dari tabel
    private java.awt.event.MouseListener idMouseGuard;
    private java.awt.event.KeyListener idKeyGuard;

    // ====== VALIDATOR ======
    private static final java.util.regex.Pattern P_TELP
            = java.util.regex.Pattern.compile("^\\d{8,13}$");

    private static final int MAX_NAMA = 50;
    private static final int MAX_LOKASI = 100;

    // Nama: huruf/spasi/tanda umum (.'-)
    private static final java.util.regex.Pattern P_NAMA
            = java.util.regex.Pattern.compile("^[A-Za-z\\s.'-]{2," + MAX_NAMA + "}$");

    // Lokasi: huruf/angka/spasi + karakter dasar .,'-/()  (3–100)
    private static final java.util.regex.Pattern P_LOKASI
            = java.util.regex.Pattern.compile("^[A-Za-z0-9\\s.,'\\-()/]{3," + MAX_LOKASI + "}$");

    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Periksa data berikut:\n- " + String.join("\n- ", errs),
                "Validasi gagal",
                javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }

    private java.util.List<String> validateForInsert() {
    var e = new java.util.ArrayList<String>();

    // ID harus AUTO saat tambah
    if (!"(AUTO)".equalsIgnoreCase(jTextField1.getText().trim()))
        e.add("Id Komunitas diisi otomatis. Biarkan '(AUTO)'.");

    // Nama
    String nama = jTextField2.getText().trim();
    if (nama.isBlank()) e.add("Nama Komunitas wajib diisi.");
    else {
        if (nama.length() > MAX_NAMA) e.add("Nama maksimal " + MAX_NAMA + " karakter.");
        if (!P_NAMA.matcher(nama).matches()) e.add("Nama hanya huruf/spasi/tanda umum (.'-) (2–" + MAX_NAMA + ").");
    }

    // Lokasi
    String lokasi = jTextField3.getText().trim();
    if (lokasi.isBlank()) e.add("Lokasi wajib diisi.");
    else {
        if (lokasi.length() > MAX_LOKASI) e.add("Lokasi maksimal " + MAX_LOKASI + " karakter.");
        if (!P_LOKASI.matcher(lokasi).matches()) e.add("Lokasi hanya huruf/angka & .,'-/() (3–" + MAX_LOKASI + ").");
    }

    // Kontak
    String kontak = jTextField4.getText().trim();
    if (!P_TELP.matcher(kontak).matches())
        e.add("Kontak Pengurus harus angka 8–13 digit.");

    // Tanggal
    String tgl = jTextField5.getText().trim();
    if (tgl.isBlank()) e.add("Tgl Mulai Operasi wajib diisi (yyyy-MM-dd).");
    else {
        try { java.sql.Date.valueOf(tgl); }
        catch (Exception ex) { e.add("Format tanggal harus yyyy-MM-dd."); }
    }

    // Status
    String st = normalizeStatus(String.valueOf(jComboBox1.getSelectedItem()));
    if (!st.equals("AKTIF") && !st.equals("TIDAK AKTIF"))
        e.add("Status tidak valid (pilih AKTIF / TIDAK AKTIF).");

    return e;
}


    private java.util.List<String> validateForUpdate() {
    var e = new java.util.ArrayList<String>();

    // Id harus terisi dari tabel (bukan AUTO)
    String idTxt = jTextField1.getText().trim();
    if (idTxt.isBlank() || "(AUTO)".equalsIgnoreCase(idTxt))
        e.add("Pilih baris dari tabel terlebih dahulu.");

    // Pakai aturan yang sama dengan insert untuk field lainnya
    // (tanpa cek AUTO)
    String nama = jTextField2.getText().trim();
    if (nama.isBlank()) e.add("Nama Komunitas wajib diisi.");
    else {
        if (nama.length() > MAX_NAMA) e.add("Nama maksimal " + MAX_NAMA + " karakter.");
        if (!P_NAMA.matcher(nama).matches()) e.add("Nama hanya huruf/spasi/tanda umum (.'-) (2–" + MAX_NAMA + ").");
    }

    String lokasi = jTextField3.getText().trim();
    if (lokasi.isBlank()) e.add("Lokasi wajib diisi.");
    else {
        if (lokasi.length() > MAX_LOKASI) e.add("Lokasi maksimal " + MAX_LOKASI + " karakter.");
        if (!P_LOKASI.matcher(lokasi).matches()) e.add("Lokasi hanya huruf/angka & .,'-/() (3–" + MAX_LOKASI + ").");
    }

    String kontak = jTextField4.getText().trim();
    if (!P_TELP.matcher(kontak).matches())
        e.add("Kontak Pengurus harus angka 8–13 digit.");

    String tgl = jTextField5.getText().trim();
    if (tgl.isBlank()) e.add("Tgl Mulai Operasi wajib diisi (yyyy-MM-dd).");
    else {
        try { java.sql.Date.valueOf(tgl); }
        catch (Exception ex) { e.add("Format tanggal harus yyyy-MM-dd."); }
    }

    String st = normalizeStatus(String.valueOf(jComboBox1.getSelectedItem()));
    if (!st.equals("AKTIF") && !st.equals("TIDAK AKTIF"))
        e.add("Status tidak valid (pilih AKTIF / TIDAK AKTIF).");

    return e;
}


    // ====== GUARD: ID read-only, popup hanya saat editingExisting = true ======
    private void applyIdGuard() {
        removeIdGuard();
        jTextField1.setEditable(false);
        jTextField1.setFocusable(true);
        jTextField1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));

        idMouseGuard = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_superadmin_komunitas.this,
                            "ID Komunitas tidak boleh diubah.");
                    e.consume();
                }
            }
        };
        idKeyGuard = new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                if (editingExisting) {
                    e.consume();
                }
            }
        };
        jTextField1.addMouseListener(idMouseGuard);
        jTextField1.addKeyListener(idKeyGuard);
    }

    private void removeIdGuard() {
        if (idMouseGuard != null) {
            jTextField1.removeMouseListener(idMouseGuard);
            idMouseGuard = null;
        }
        if (idKeyGuard != null) {
            jTextField1.removeKeyListener(idKeyGuard);
            idKeyGuard = null;
        }
    }

    // ====== HELPERS ======
    private java.sql.Date parseDateOrNull(String s) {
        s = s == null ? "" : s.trim();
        return s.isBlank() ? null : java.sql.Date.valueOf(s); // yyyy-MM-dd
    }
    
    // Samakan ejaan status
    private String normalizeStatus(String st) {
        if (st == null) {
            return "AKTIF";
        }
        st = st.trim().toUpperCase();
        if (st.equals("GA AKTIF")) {
            st = "TIDAK AKTIF";
        }
        if (!st.equals("AKTIF") && !st.equals("TIDAK AKTIF")) {
            st = "AKTIF";
        }
        return st;
    }


    private void clearFormForInsert() {
        editingExisting = false;
        removeIdGuard();

        jTable1.clearSelection();
        jTextField1.setText("(AUTO)");   // ID otomatis
        jTextField2.setText("");         // nama
        jTextField3.setText("");         // lokasi
        jTextField4.setText("");         // kontak
        jTextField5.setText("");         // tanggal (boleh diisi manual)
        if (jComboBox1.getItemCount() == 0) {
            jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"AKTIF", "GA AKTIF"}));
        } else {
            jComboBox1.setSelectedIndex(0);
        }
        // id tetap tidak bisa diketik, tapi tanpa popup saat mode insert
        jTextField1.setEditable(false);
    }

    private void loadTable() {
        try {
            jTable1.setModel(komunitasDao.loadAll());
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void fillFieldsFromSelectedRow() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        editingExisting = true;
        applyIdGuard();

        // urutan kolom: id, nama, lokasi, kontak, tgl_mulai, status
        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0))); // Id
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, 1))); // Nama
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2))); // Lokasi
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3))); // Kontak
        Object tgl = jTable1.getValueAt(r, 4);
        jTextField5.setText(tgl == null ? "" : tgl.toString());        // yyyy-MM-dd
        Object st = jTable1.getValueAt(r, 5);
        if (st != null) {
            jComboBox1.setSelectedItem(st.toString());
        }
    }

    public Menu_superadmin_komunitas() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null); // center window
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);
        // muat data pertama kali
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                loadTable();
                clearFormForInsert();
            }
        });

        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                fillFieldsFromSelectedRow();
            }
        });

        // siapkan guard (tanpa popup saat insert)
        applyIdGuard();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        KEMBALI = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("Komunitas");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(480, 10, 140, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Komunitas");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 120, 100, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Nama Komunitas");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(39, 159, 110, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Lokasi");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 200, 50, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Kontak Pengurus");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 240, 120, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Tgl Mulai Operasi");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 290, 120, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Status Komunitas");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 330, 120, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(180, 117, 130, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(180, 159, 130, 30);

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(180, 201, 130, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(180, 243, 130, 30);
        getContentPane().add(jTextField5);
        jTextField5.setBounds(180, 286, 130, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "TIDAK AKTIF" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(180, 328, 130, 30);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 390, 90, 23);

        jButton2.setText("Hapus");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(240, 390, 80, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(130, 390, 90, 23);

        jButton4.setText("Muat Ulang");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(190, 440, 100, 23);

        KEMBALI.setText("Kembali");
        KEMBALI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KEMBALIActionPerformed(evt);
            }
        });
        getContentPane().add(KEMBALI);
        KEMBALI.setBounds(40, 440, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id_Komunitas", "Nama_Komunitas", "Lokasi", "Kontak_Pengurus", "Tgl_ Mulai_Operasi", "Status_Komunitas"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 41, 452, 440);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        var errs = validateForUpdate();
        if (!errs.isEmpty()) {
            showErrors(errs);
            return;
        }

        try {
            int id = Integer.parseInt(jTextField1.getText().trim());
            String nama = jTextField2.getText().trim();
            String lokasi = jTextField3.getText().trim();
            String kontak = jTextField4.getText().trim();
            java.sql.Date tgl = parseDateOrNull(jTextField5.getText());
            String status = normalizeStatus(String.valueOf(jComboBox1.getSelectedItem()));


            int okc = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Perbarui komunitas ID " + id + " ?",
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (okc != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int ok = komunitasDao.update(id, nama, lokasi, kontak, tgl, status);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Perbarui OK" : "Tidak ada yang diubah");
            loadTable();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void KEMBALIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KEMBALIActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KEMBALIActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            if (jTextField1.getText().isBlank() || "(AUTO)".equalsIgnoreCase(jTextField1.getText().trim())) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris di tabel dulu.");
                return;
            }
            int id = Integer.parseInt(jTextField1.getText().trim());
            int yn = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Yakin hapus komunitas ID: " + id + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION);
            if (yn != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int ok = komunitasDao.delete(id);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Hapus OK" : "Gagal hapus (ID tidak ada?)");
            loadTable();
            clearFormForInsert();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        var errs = validateForInsert();
        if (!errs.isEmpty()) {
            showErrors(errs);
            return;
        }

        try {
            int nextId = komunitasDao.nextId(); // <-- ID otomatis
            String nama = jTextField2.getText().trim();
            String lokasi = jTextField3.getText().trim();
            String kontak = jTextField4.getText().trim();
            java.sql.Date tgl = parseDateOrNull(jTextField5.getText());
            String status = normalizeStatus(String.valueOf(jComboBox1.getSelectedItem()));


            int ok = komunitasDao.insert(nextId, nama, lokasi, kontak, tgl, status);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah");
            loadTable();
            clearFormForInsert();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }


    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int yn = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan & muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        loadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_komunitas().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KEMBALI;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
