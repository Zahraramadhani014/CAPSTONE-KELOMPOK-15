package View;

public class Menu_superadmin_tagihanbulanan extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_tagihanbulanan.class.getName());
    private final dao.TagihanDao tagihanDao = new dao.TagihanDao();

    // ===== STATE =====
    private boolean editingExisting = false;
    private boolean busyAdd = false;
    private boolean busyUpdate = false;
    private boolean busyDelete = false;

    public Menu_superadmin_tagihanbulanan() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null); // center window
        setResizable(false);
        
        attachAutoTotalPreview();
        
        jTextField5.setEditable(false);
        jTextField5.setFocusable(false);


        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);

        // status harus sesuai ENUM di DB
        jComboBox1.removeAllItems();
        jComboBox1.addItem("LUNAS");
        jComboBox1.addItem("BELUM LUNAS");

        // kunci & guard klik ID saat edit
        guardReadOnlyId(jTextField1, "ID Tagihan");

        // load awal
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                reloadTable();
                clearFormForInsert();
            }
        });

        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTable1.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFieldsFromRow();
            }
        });
    }
    
    private void attachAutoTotalPreview() {
        javax.swing.event.DocumentListener dl = new javax.swing.event.DocumentListener() {
            private void recalc() {
                try {
                    var tot = computeTotal(jTextField3.getText(), jTextField4.getText());
                    jTextField5.setText(tot.toPlainString());
                } catch (Exception e) {
                    jTextField5.setText(""); // kosongkan bila input belum valid
                }
            }

            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                recalc();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                recalc();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                recalc();
            }
        };
        jTextField3.getDocument().addDocumentListener(dl); // KWH
        jTextField4.getDocument().addDocumentListener(dl); // Tarif
    }
    
    private java.math.BigDecimal computeTotal(String kwhTxt, String tarifTxt) {
    var kwh   = parseDecimalStrict(kwhTxt, 10, 3, "Total KWH", true);
    var tarif = parseDecimalStrict(tarifTxt, 10, 2, "Tarif per KWH", true);
    return clampToTotal(kwh.multiply(tarif)); // hasil 2 desimal, muat DECIMAL(12,2)
}


  
    /* ==================== Helpers: Validasi & Parser ==================== */
    private void guardReadOnlyId(javax.swing.JTextField tf, String label) {
        tf.setEditable(false);
        tf.setFocusable(true);
        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_superadmin_tagihanbulanan.this,
                            label + " tidak bisa diubah pada mode edit.");
                    e.consume();
                }
            }
        });
        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
        tf.putClientProperty("ro-guard", Boolean.TRUE);
    }

    private void showSqlError(Exception ex, String ctx) {
        if (ex instanceof java.sql.SQLIntegrityConstraintViolationException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: pelanggaran relasi/unik (cek RUMAH_id_rumah, duplikat, atau data terkait).");
            return;
        }
        if (ex instanceof java.sql.SQLDataException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: format/ukuran data tidak cocok (cek angka & panjang teks).");
            return;
        }
        if (ex instanceof java.sql.SQLSyntaxErrorException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: sintaks SQL bermasalah.");
            return;
        }
        if (ex instanceof java.sql.SQLTransientConnectionException
                || ex instanceof java.sql.SQLNonTransientConnectionException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: koneksi database terputus.");
            return;
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Err (" + ctx + "): " + ex.getMessage());
    }

     /* ==================== Helpers: Parser & Validator Sesuai DB ==================== */

    // Normalisasi angka: spasi di-trim, koma → titik
    private String normNum(String s) {
        return (s == null) ? "" : s.trim().replace(',', '.');
    }

    // Validasi format yyyy-MM (char(7)) bulan 01..12
    private boolean isValidPeriode(String p) {
        return p != null && p.length()==7 && p.matches("^\\d{4}-(0[1-9]|1[0-2])$");
    }

    /**
     * Parse angka desimal dengan batas precision/scale persis seperti kolom DB.
     * Contoh: precision=10, scale=3 → maksimal 7 digit di depan titik dan 3 digit di belakang.
     * Akan throw IllegalArgumentException kalau tidak valid.
     */
    private java.math.BigDecimal parseDecimalStrict(String raw, int precision, int scale, String label, boolean mustBePositive) {
        String s = normNum(raw);
        if (s.isEmpty()) throw new IllegalArgumentException(label + " wajib diisi.");
        if (!s.matches("^[+-]?\\d+(\\.\\d+)?$")) throw new IllegalArgumentException(label + " harus angka.");

        // pecah bagian integer & fractional untuk cek panjang
        String[] parts = s.startsWith("+") || s.startsWith("-") ? s.substring(1).split("\\.", -1) : s.split("\\.", -1);
        String intPart = parts[0].replaceFirst("^0+(?!$)", ""); // buang leading zero (biar hitung digit realistis)
        String fracPart = (parts.length > 1) ? parts[1] : "";

        int maxInt = precision - scale;
        if (intPart.length() > maxInt) {
            throw new IllegalArgumentException(label + " terlalu besar (maks " + maxInt + " digit sebelum titik).");
        }
        if (fracPart.length() > scale) {
            throw new IllegalArgumentException(label + " maksimal " + scale + " digit desimal.");
        }

        java.math.BigDecimal bd = new java.math.BigDecimal(s);
        if (mustBePositive && bd.signum() <= 0) {
            throw new IllegalArgumentException(label + " harus > 0.");
        }

        // setScale sesuai kolom (tanpa loss): tambahkan nol kalau kurang; bulatkan HALF_UP kalau lebih (harusnya sudah ditolak di atas)
        if (bd.scale() != scale) {
            bd = bd.setScale(scale, java.math.RoundingMode.HALF_UP);
        }
        return bd;
    }

    // pastikan hasil perkalian muat di kolom DECIMAL(12,2)
    private java.math.BigDecimal clampToTotal(java.math.BigDecimal bd) {
        // precision=12, scale=2 → max 10 digit integer
        java.math.BigDecimal v = bd.setScale(2, java.math.RoundingMode.HALF_UP);
        String s = v.abs().toPlainString();
        String[] parts = s.split("\\.", -1);
        int intLen = parts[0].replaceFirst("^0+(?!$)", "").length();
        if (intLen > 10) {
            throw new IllegalArgumentException("Total Tagihan terlalu besar untuk kolom DECIMAL(12,2).");
        }
        return v;
    }

    // REPLACE seluruh method ini
private java.util.List<String> validateForInsert() {
    java.util.ArrayList<String> errs = new java.util.ArrayList<>();

    // periode CHAR(7) YYYY-MM (01..12)
    String periode = jTextField2.getText().trim();
    if (periode.isBlank() || !isValidPeriode(periode)) {
        errs.add("Periode harus format YYYY-MM (01..12).");
    }

    // ambil raw text (boleh kosong kalau total diisi)
    String rawKwh   = jTextField3.getText();
    String rawTarif = jTextField4.getText();
    String rawTotal = jTextField5.getText();

    String nKwh = normNum(rawKwh);
    String nTar = normNum(rawTarif);
    String nTot = normNum(rawTotal);

    if (!nTot.isBlank()) {
        // USER MENGISI TOTAL → validasi ketat total (12,2)
        try {
            java.math.BigDecimal tot = parseDecimalStrict(nTot, 12, 2, "Total Tagihan", true);
            clampToTotal(tot); // jaga-jaga kalau kebesaran kolom
        } catch (IllegalArgumentException e) {
            errs.add(e.getMessage());
        }
    } else {
        // TOTAL DIKOSONGKAN → WAJIB isi KWH & TARIF (karena total dihitung otomatis)
        if (nKwh.isBlank())  errs.add("Total KWH wajib diisi.");
        if (nTar.isBlank())  errs.add("Tarif per KWH wajib diisi.");

        // validasi format kalau terisi
        if (!nKwh.isBlank()) {
            try { parseDecimalStrict(nKwh, 10, 3, "Total KWH", true); }
            catch (IllegalArgumentException e) { errs.add(e.getMessage()); }
        }
        if (!nTar.isBlank()) {
            try { parseDecimalStrict(nTar, 10, 2, "Tarif per KWH", true); }
            catch (IllegalArgumentException e) { errs.add(e.getMessage()); }
        }
    }

    // status ENUM
    String st = String.valueOf(jComboBox1.getSelectedItem());
    if (!"LUNAS".equals(st) && !"BELUM LUNAS".equals(st)) {
        errs.add("Status harus LUNAS / BELUM LUNAS.");
    }

    return errs;
}


    private java.util.List<String> validateForUpdate() {
        java.util.ArrayList<String> errs = new java.util.ArrayList<>();

        // cek dulu ID agar pesannya muncul paling atas
        String sid = jTextField1.getText().trim();
        if (sid.isBlank() || "(AUTO)".equalsIgnoreCase(sid)) {
            errs.add("Pilih baris dari tabel terlebih dahulu.");
        }

        // lalu tambahkan validasi yang sama seperti insert
        errs.addAll(validateForInsert());
        return errs;
}


    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }

    private java.math.BigDecimal hitungTotalSafely(String totalTxt, String kwhTxt, String tarifTxt) {
        // jika user isi total, pakai yang sudah divalidasi
        String t = normNum(totalTxt);
        if (!t.isBlank()) {
            java.math.BigDecimal tot = parseDecimalStrict(t, 12, 2, "Total Tagihan", true);
            return clampToTotal(tot);
        }
        // else hitung dari kwh * tarif, lalu clamp
        java.math.BigDecimal kwh = parseDecimalStrict(kwhTxt, 10, 3, "Total KWH", true);
        java.math.BigDecimal tarif = parseDecimalStrict(tarifTxt, 10, 2, "Tarif per KWH", true);
        return clampToTotal(kwh.multiply(tarif));
    }

    private Integer askInt(String title, String prompt) {
        String s = javax.swing.JOptionPane.showInputDialog(this, prompt, title, javax.swing.JOptionPane.QUESTION_MESSAGE);
        if (s == null) return null;
        s = s.trim();
        if (s.isEmpty()) { javax.swing.JOptionPane.showMessageDialog(this, "Tidak boleh kosong."); return null; }
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { javax.swing.JOptionPane.showMessageDialog(this, "Harus angka."); return null; }
    }

    /* ==================== Helpers: Tabel & Form ==================== */

    private void reloadTable() {
        try {
            jTable1.setModel(tagihanDao.loadTableForAdmin());
            jTable1.clearSelection();
        } catch (Exception ex) {
            showSqlError(ex, "Muat data");
        }
    }

    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();
        jTextField1.setText("(AUTO)");
        jTextField2.setText(""); // periode
        jTextField3.setText(""); // kwh
        jTextField4.setText(""); // tarif
        jTextField5.setText(""); // total
        if (jComboBox1.getItemCount() > 0) jComboBox1.setSelectedItem("BELUM LUNAS");
    }

    private void fillFieldsFromRow() {
        int r = jTable1.getSelectedRow();
        if (r < 0) return;

        editingExisting = true;
        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0)));
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, 1)));
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2)));
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3)));
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, 4)));
        Object st = jTable1.getValueAt(r, 5);
        if (st != null) jComboBox1.setSelectedItem(st.toString());
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        KEMBALI = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("Tagihan Bulanan");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(440, 10, 210, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Tagihan");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 130, 80, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Periode");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 170, 70, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Total KWH");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 210, 90, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Tarif Per KWH");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 250, 90, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Total Tagihan");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 290, 90, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Status Tagihan");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 330, 100, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(180, 130, 130, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(180, 170, 130, 30);

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(180, 210, 130, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(180, 250, 130, 30);
        getContentPane().add(jTextField5);
        jTextField5.setBounds(180, 290, 130, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LUNAS", "BELUM LUNAS" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(180, 330, 130, 30);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 390, 100, 23);

        jButton2.setText("Hapus");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(230, 390, 90, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(120, 390, 100, 23);

        jButton4.setText("Muat Ulang");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(170, 430, 100, 23);

        KEMBALI.setText("Kembali");
        KEMBALI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KEMBALIActionPerformed(evt);
            }
        });
        getContentPane().add(KEMBALI);
        KEMBALI.setBounds(60, 430, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id_Tagihan", "Periode", "Total_KWH", "Tarif_Per_KWH", "Total_Tagihan", "Status_Tagihan"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 41, 452, 440);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (busyUpdate) return; busyUpdate = true; jButton3.setEnabled(false);
        try {
            var errs = validateForUpdate();
            if (!errs.isEmpty()) { showErrors(errs); return; }
            if (!editingExisting || jTable1.getSelectedRow() < 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris di tabel dulu.");
                return;
            }

            int id = Integer.parseInt(jTextField1.getText().trim());
            String periode = jTextField2.getText().trim();

            java.math.BigDecimal kwh   = parseDecimalStrict(jTextField3.getText(), 10, 3, "Total KWH", true);
            java.math.BigDecimal tarif = parseDecimalStrict(jTextField4.getText(), 10, 2, "Tarif per KWH", true);
            java.math.BigDecimal total = computeTotal(jTextField3.getText(), jTextField4.getText());
            String status = String.valueOf(jComboBox1.getSelectedItem());

            int okc = javax.swing.JOptionPane.showConfirmDialog(this,
                    "Perbarui tagihan #" + id + " ?", "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (okc != javax.swing.JOptionPane.YES_OPTION) return;

            int ok = tagihanDao.updateAdmin(id, periode, kwh, tarif, total, status);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Perbarui OK" : "Tidak ada yang diubah");
            reloadTable();
        } catch (IllegalArgumentException v) {
            // dari validator
            javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            showSqlError(ex, "Perbarui");
        } finally {
            busyUpdate = false; jButton3.setEnabled(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void KEMBALIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KEMBALIActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_KEMBALIActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (busyDelete) return; busyDelete = true; jButton2.setEnabled(false);
        try {
            String sId = jTextField1.getText().trim();
            if (sId.isBlank() || "(auto)".equalsIgnoreCase(sId)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris dari tabel terlebih dahulu.");
                return;
            }
            int id = Integer.parseInt(sId);
            int ok = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Hapus tagihan id " + id + "?", "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION,
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            if (ok != javax.swing.JOptionPane.YES_OPTION) return;

            try (java.sql.Connection c = dao.DB.getConnection();
                 java.sql.PreparedStatement ps = c.prepareStatement(
                         "DELETE FROM tagihan_bulanan WHERE id_tagihan=?")) {
                ps.setInt(1, id);
                int del = ps.executeUpdate();
                javax.swing.JOptionPane.showMessageDialog(this, del > 0 ? "Hapus OK" : "Data tidak ditemukan");
            }
            reloadTable();
            clearFormForInsert();
        } catch (Exception ex) {
            showSqlError(ex, "Hapus");
        } finally {
            busyDelete = false; jButton2.setEnabled(true);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (busyAdd) return; busyAdd = true; jButton1.setEnabled(false);
        try {
            var errs = validateForInsert();
            if (!errs.isEmpty()) { showErrors(errs); return; }

            int nextId = tagihanDao.nextId(); // ID otomatis
            String periode = jTextField2.getText().trim();

            java.math.BigDecimal kwh   = parseDecimalStrict(jTextField3.getText(), 10, 3, "Total KWH", true);
            java.math.BigDecimal tarif = parseDecimalStrict(jTextField4.getText(), 10, 2, "Tarif per KWH", true);
            java.math.BigDecimal total = computeTotal(jTextField3.getText(), jTextField4.getText());
            String status = String.valueOf(jComboBox1.getSelectedItem());

            Integer idRumah = askInt("ID Rumah", "Masukkan RUMAH_id_rumah (angka):");
            if (idRumah == null) return;

            int ok = tagihanDao.insertAdmin(nextId, periode, kwh, tarif, total, status, idRumah);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah");
            reloadTable();
            clearFormForInsert();
        } catch (IllegalArgumentException v) {
            javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            showSqlError(ex, "Tambah");
        } finally {
            busyAdd = false; jButton1.setEnabled(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int yn = javax.swing.JOptionPane.showConfirmDialog(this,
                "Batalkan perubahan dan muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) return;
        reloadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_tagihanbulanan().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KEMBALI;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
