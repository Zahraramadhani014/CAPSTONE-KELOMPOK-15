package View;

public class Menu_superadmin_panelsurya extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_panelsurya.class.getName());
    private final dao.PanelSuryaDao panelDao = new dao.PanelSuryaDao();

    /* ===================== STATE & GUARD ===================== */
    private boolean editingExisting = false;
    private boolean busyAdd = false, busyUpdate = false, busyDelete = false;

    // pasang guard: field tetap non-edit, tapi pesan hanya keluar saat sedang edit data lama
    private void guardReadOnlyWhenEditing(javax.swing.JTextField tf, String label) {
        tf.setEditable(false);
        tf.setFocusable(true);
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));
        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_superadmin_panelsurya.this,
                            label + " tidak boleh diubah.");
                    e.consume();
                }
            }
        });
        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
        tf.putClientProperty("ro-guard", Boolean.TRUE);
    }

    /* ===================== VALIDATOR & HELPER ===================== */

    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }

    // normalisasi angka: trim & ganti koma jadi titik
    private String normNum(String s) {
        return (s == null) ? "" : s.trim().replace(',', '.');
    }

    // DATE wajib yyyy-MM-dd
    private java.sql.Date parseDateRequired(String s) {
        String v = (s == null) ? "" : s.trim();
        if (v.isEmpty()) throw new IllegalArgumentException("Tanggal Pasang wajib diisi (yyyy-MM-dd).");
        try { return java.sql.Date.valueOf(v); }
        catch (Exception ex) { throw new IllegalArgumentException("Tanggal Pasang harus format yyyy-MM-dd."); }
    }

    // DECIMAL(precision, scale) ketat
    private java.math.BigDecimal parseDecimalStrict(String raw, int precision, int scale, String label) {
        String s = normNum(raw);
        if (s.isEmpty()) throw new IllegalArgumentException(label + " wajib diisi.");
        if (!s.matches("^[+-]?\\d+(\\.\\d+)?$")) throw new IllegalArgumentException(label + " harus angka.");
        String t = s.startsWith("+") || s.startsWith("-") ? s.substring(1) : s;
        String[] parts = t.split("\\.", -1);
        String intPart = parts[0].replaceFirst("^0+(?!$)", "");
        String fracPart = (parts.length > 1) ? parts[1] : "";
        int maxInt = precision - scale;
        if (intPart.length() > maxInt) throw new IllegalArgumentException(
                label + " terlalu besar (maks " + maxInt + " digit sebelum titik).");
        if (fracPart.length() > scale) throw new IllegalArgumentException(
                label + " maksimal " + scale + " digit desimal.");

        java.math.BigDecimal v = new java.math.BigDecimal(s);
        if (v.signum() <= 0) throw new IllegalArgumentException(label + " harus > 0.");
        return v.setScale(scale, java.math.RoundingMode.HALF_UP);
    }

    private void showSqlError(Exception ex, String ctx) {
        if (ex instanceof java.sql.SQLIntegrityConstraintViolationException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: pelanggaran relasi/unik (cek KOMUNITAS_id_komunitas, duplikat, atau data terkait).");
            return;
        }
        if (ex instanceof java.sql.SQLDataException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: format/ukuran data tidak cocok dengan tipe kolom.");
            return;
        }
        if (ex instanceof java.sql.SQLSyntaxErrorException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: sintaks SQL bermasalah.");
            return;
        }
        if (ex instanceof java.sql.SQLTransientConnectionException
                || ex instanceof java.sql.SQLNonTransientConnectionException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: koneksi database terputus.");
            return;
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Err (" + ctx + "): " + ex.getMessage());
    }

    private Integer askInt(String title, String prompt) {
        String s = javax.swing.JOptionPane.showInputDialog(this, prompt, title, javax.swing.JOptionPane.QUESTION_MESSAGE);
        if (s == null) return null;
        s = s.trim();
        if (s.isEmpty()) { javax.swing.JOptionPane.showMessageDialog(this, "Tidak boleh kosong."); return null; }
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { javax.swing.JOptionPane.showMessageDialog(this, "Harus angka."); return null; }
    }

    private java.util.List<String> validateForInsert() {
        var errs = new java.util.ArrayList<String>();

        if (!"(AUTO)".equalsIgnoreCase(jTextField1.getText().trim())) {
            errs.add("Kode Panel diisi otomatis. Biarkan '(AUTO)'.");
        }
        // kapasitas_watt DECIMAL(8,2)
        try { parseDecimalStrict(jTextField2.getText(), 8, 2, "Kapasitas Watt"); }
        catch (IllegalArgumentException e) { errs.add(e.getMessage()); }

        // tanggal_pasang DATE
        try { parseDateRequired(jTextField3.getText()); }
        catch (IllegalArgumentException e) { errs.add(e.getMessage()); }

        // status ENUM
        String status = String.valueOf(jComboBox1.getSelectedItem());
        if (!status.equals("AKTIF") && !status.equals("PERBAIKAN") && !status.equals("RUSAK")) {
            errs.add("Status Panel harus: AKTIF / PERBAIKAN / RUSAK.");
        }

        // catatan VARCHAR(100)
        String cat = jTextField4.getText().trim();
        if (cat.isEmpty()) {
            errs.add("Catatan wajib diisi.");
        } else if (cat.length() > 100) {
            errs.add("Catatan maksimal 100 karakter.");
}

        return errs;
    }

    private java.util.List<String> validateForUpdate() {
    var errs = new java.util.ArrayList<String>();

    // kapasitas_watt DECIMAL(8,2)
    try { parseDecimalStrict(jTextField2.getText(), 8, 2, "Kapasitas Watt"); }
    catch (IllegalArgumentException e) { errs.add(e.getMessage()); }

    // tanggal_pasang DATE
    try { parseDateRequired(jTextField3.getText()); }
    catch (IllegalArgumentException e) { errs.add(e.getMessage()); }

    // status ENUM
    String status = String.valueOf(jComboBox1.getSelectedItem());
    if (!status.equals("AKTIF") && !status.equals("PERBAIKAN") && !status.equals("RUSAK")) {
        errs.add("Status Panel harus: AKTIF / PERBAIKAN / RUSAK.");
    }

    // catatan VARCHAR(100) (WAJIB)
    String cat = jTextField4.getText().trim();
    if (cat.isEmpty()) {
        errs.add("Catatan wajib diisi.");
    } else if (cat.length() > 100) {
        errs.add("Catatan maksimal 100 karakter.");
    }

    return errs;
}


    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();
        jTextField1.setText("(AUTO)");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        if (jComboBox1.getItemCount() > 0) jComboBox1.setSelectedIndex(0);
    }

    public Menu_superadmin_panelsurya() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null); // center window
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);

        // isi pilihan status
        jComboBox1.removeAllItems();
        jComboBox1.addItem("AKTIF");
        jComboBox1.addItem("PERBAIKAN");
        jComboBox1.addItem("RUSAK");

        // guard untuk Kode Panel
        guardReadOnlyWhenEditing(jTextField1, "Kode Panel");

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                reloadTable();
                jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
                clearFormForInsert();
            }
        });

        // klik tabel -> isi field (mode edit)
        jTable1.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFieldsFromRow();
            }
        });
    }

    private void reloadTable() {
        try {
            jTable1.setModel(panelDao.loadTableForAdmin());
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void fillFieldsFromRow() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        editingExisting = true;

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0)));     // kode_panel
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, 1)));     // kapasitas_watt
        Object tgl = jTable1.getValueAt(r, 2);                              // tanggal_pasang
        jTextField3.setText(tgl == null ? "" : tgl.toString());
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3)));     // catatan
        Object st = jTable1.getValueAt(r, 4);
        if (st != null) {
            jComboBox1.setSelectedItem(st.toString());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        kembali = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("Panel Surya");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(480, 10, 150, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Kode Panel");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 140, 140, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Kapasitas Watt");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 180, 140, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Tanggal Pasang");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 220, 140, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Catatan");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 270, 140, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Status Panel");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 320, 140, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(180, 130, 130, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(180, 170, 130, 30);

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(180, 210, 130, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(180, 260, 130, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "PERBAIKAN", "RUSAK" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(180, 310, 130, 30);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 390, 90, 23);

        jButton2.setText("Hapus");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(230, 390, 90, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(120, 390, 90, 23);

        jButton4.setText("Muat Ulang");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(180, 440, 100, 23);

        kembali.setText("Kembali");
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali);
        kembali.setBounds(50, 440, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode_Panel", "Kapasitas_Watt", "Tanggal_Pasang", "Catatan", "Status_Panel"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 41, 452, 440);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (busyUpdate) return; busyUpdate = true; jButton3.setEnabled(false);
    try {
        // --- GUARD: harus pilih baris dulu ---
        String sId = jTextField1.getText().trim();
        if (sId.isBlank() || "(AUTO)".equalsIgnoreCase(sId) || jTable1.getSelectedRow() < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dari tabel terlebih dahulu.");
            return;
        }

        // --- Validasi isi form tanpa “pilih tabel” ---
        var errs = validateForUpdate();
        if (!errs.isEmpty()) { showErrors(errs); return; }

        int kode = Integer.parseInt(sId);
        java.math.BigDecimal kapasitas = parseDecimalStrict(jTextField2.getText(), 8, 2, "Kapasitas Watt");
        java.sql.Date tgl = parseDateRequired(jTextField3.getText());
        String catatan = jTextField4.getText().trim();
        String status = jComboBox1.getSelectedItem().toString();

        int okc = javax.swing.JOptionPane.showConfirmDialog(
                this, "Perbarui panel #" + kode + " ?", "Konfirmasi",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (okc != javax.swing.JOptionPane.YES_OPTION) return;

        int ch = panelDao.updateAdmin(kode, kapasitas, status, tgl, catatan);
        javax.swing.JOptionPane.showMessageDialog(this, ch > 0 ? "Perbarui OK" : "Data tidak ditemukan");
        reloadTable();
    } catch (IllegalArgumentException v) {
        javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
    } catch (Exception ex) {
        showSqlError(ex, "Perbarui");
    } finally {
        busyUpdate = false; jButton3.setEnabled(true);
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (busyDelete) return; busyDelete = true; jButton2.setEnabled(false);
        try {
            String sId = jTextField1.getText().trim();
            if (sId.isBlank() || "(AUTO)".equalsIgnoreCase(sId)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris dari tabel dulu.");
                return;
            }
            int kode = Integer.parseInt(sId);
            int ok = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Hapus panel #" + kode + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION, javax.swing.JOptionPane.WARNING_MESSAGE);
            if (ok != javax.swing.JOptionPane.YES_OPTION) return;

            int del = panelDao.deleteAdmin(kode);
            javax.swing.JOptionPane.showMessageDialog(this, del > 0 ? "Hapus OK" : "Data tidak ditemukan");
            reloadTable();
            clearFormForInsert();
        } catch (Exception ex) {
            showSqlError(ex, "Hapus");
        } finally {
            busyDelete = false; jButton2.setEnabled(true);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (busyAdd) return; busyAdd = true; jButton1.setEnabled(false);
        try {
            var errs = validateForInsert();
            if (!errs.isEmpty()) { showErrors(errs); return; }

            int nextKode = panelDao.nextKodePanel(); // KODE OTOMATIS
            java.math.BigDecimal kapasitas = parseDecimalStrict(jTextField2.getText(), 8, 2, "Kapasitas Watt");
            java.sql.Date tgl = parseDateRequired(jTextField3.getText());
            String catatan = jTextField4.getText().trim();
            String status = jComboBox1.getSelectedItem().toString();

            Integer idKom = askInt("ID Komunitas", "Masukkan KOMUNITAS_id_komunitas (angka):");
            if (idKom == null) return;

            int ok = panelDao.insertAdmin(nextKode, kapasitas, status, tgl, catatan, idKom);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah");
            reloadTable();
            clearFormForInsert();
        } catch (IllegalArgumentException v) {
            javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            showSqlError(ex, "Tambah");
        } finally {
            busyAdd = false; jButton1.setEnabled(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int yn = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan & muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) return;
        reloadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_panelsurya().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton kembali;
    // End of variables declaration//GEN-END:variables
}
