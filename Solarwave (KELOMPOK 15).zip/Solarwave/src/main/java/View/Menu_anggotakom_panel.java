package View;

public class Menu_anggotakom_panel extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger
            = java.util.logging.Logger.getLogger(Menu_anggotakom_panel.class.getName());
    private final dao.PanelSuryaDao panelDao = new dao.PanelSuryaDao();

    // ====== STATE ======
    private boolean busyAdd = false;
    private boolean busyUpdate = false;
    private boolean busyDelete = false;

    // ====== VALIDASI ======
    private static final java.util.regex.Pattern P_DECIMAL2
            = java.util.regex.Pattern.compile("^\\d{1,8}(\\.\\d{1,2})?$"); // max 8 digit + 2 desimal
    private static final java.util.Set<String> STATUS_OK
            = new java.util.HashSet<>(java.util.Arrays.asList("AKTIF", "PERBAIKAN", "RUSAK"));

    // ====== VALIDATOR HELPERS ======
    private java.sql.Date parseDateRequired(String s, String label) {
        String v = (s == null) ? "" : s.trim();
        if (v.isEmpty()) {
            throw new IllegalArgumentException(label + " wajib diisi (yyyy-MM-dd).");
        }
        try {
            return java.sql.Date.valueOf(v);
        } catch (Exception e) {
            throw new IllegalArgumentException(label + " harus format yyyy-MM-dd.");
        }
    }

    private java.math.BigDecimal parseDecimal2(String s, String label) {
        if (s == null || !P_DECIMAL2.matcher(s.trim()).matches()) {
            throw new IllegalArgumentException(label + " harus angka >= 0 (maks 2 desimal).");
        }
        try {
            java.math.BigDecimal v = new java.math.BigDecimal(s.trim());
            if (v.compareTo(java.math.BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(label + " tidak boleh negatif.");
            }
            // Jika ingin paksa 2 desimal: v = v.setScale(2, java.math.RoundingMode.HALF_UP);
            return v;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(label + " tidak valid.");
        }
    }

    // ====== VALIDASI ======
    private java.util.List<String> validateForm(String watt, String status, String tgl, String catatan, boolean requireCatatan) {
        java.util.List<String> errs = new java.util.ArrayList<>();

        if (watt == null || !P_DECIMAL2.matcher(watt.trim()).matches()) {
            errs.add("Kapasitas Watt harus angka >= 0 (maks 2 desimal).");
        }
        if (status == null || !STATUS_OK.contains(status)) {
            errs.add("Status Panel harus: AKTIF / PERBAIKAN / RUSAK.");
        }
        try {
            if (tgl != null && !tgl.isBlank()) {
                java.sql.Date.valueOf(tgl.trim()); // yyyy-MM-dd
            } else {
                errs.add("Tanggal Pasang wajib diisi (format yyyy-MM-dd).");
            }
        } catch (Exception e) {
            errs.add("Tanggal Pasang harus format yyyy-MM-dd (contoh 2024-03-01).");
        }

        // --- aturan catatan ---
        if (requireCatatan && (catatan == null || catatan.trim().isEmpty())) {
            errs.add("Catatan wajib diisi.");
        }
        if (catatan != null && catatan.length() > 100) {
            errs.add("Catatan maksimal 100 karakter.");
        }

        return errs;
    }

    // ====== ERROR HANDLING UTIL ======
    private void showSqlError(Exception ex, String context) {
        if (ex instanceof java.sql.SQLIntegrityConstraintViolationException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    context + " gagal: pelanggaran relasi/unik (cek hak komunitas, duplikat, atau data terkait).");
            return;
        }
        if (ex instanceof java.sql.SQLDataException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    context + " gagal: format/ukuran data tidak cocok dengan kolom (cek angka desimal & panjang teks).");
            return;
        }
        if (ex instanceof java.sql.SQLSyntaxErrorException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    context + " gagal: ada masalah sintaks SQL.");
            return;
        }
        if (ex instanceof java.sql.SQLTransientConnectionException
                || ex instanceof java.sql.SQLNonTransientConnectionException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    context + " gagal: koneksi database terputus.");
            return;
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Err (" + context + "): " + ex.getMessage());
    }

    private void lockIdFieldWithWarning() {
        jTextField1.setEditable(false);
        jTextField1.setFocusable(false);
        jTextField1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));

        java.awt.event.MouseAdapter listener = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                String v = jTextField1.getText().trim();
                if ("(AUTO)".equalsIgnoreCase(v)) {
                    // saat mode tambah (ID otomatis)
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_panel.this,
                            "Kode panel dibuat otomatis saat menambah data.",
                            "Informasi",
                            javax.swing.JOptionPane.INFORMATION_MESSAGE
                    );
                } else if (!v.isEmpty()) {
                    // saat sedang memilih data lama (ID ada angkanya)
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_panel.this,
                            "Kode panel tidak boleh diubah.",
                            "Informasi",
                            javax.swing.JOptionPane.INFORMATION_MESSAGE
                    );
                }
                e.consume();
            }
        };
        jTextField1.addMouseListener(listener);

        // tahan input keyboard (jaga-jaga)
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
    }

    // === taruh di dalam class Menu_anggotakom_panel (di bawah field/dao aja) ===
    private int col(String name) {
        javax.swing.table.TableColumnModel cm = jTable1.getColumnModel();
        for (int i = 0; i < cm.getColumnCount(); i++) {
            if (name.equalsIgnoreCase(cm.getColumn(i).getHeaderValue().toString())) {
                return i;
            }
        }
        // fallback ke indeks tetap kalau header berubah casing/alias
        String n = name.toLowerCase();
        for (int i = 0; i < cm.getColumnCount(); i++) {
            String h = cm.getColumn(i).getHeaderValue().toString().toLowerCase();
            if (h.startsWith(n)) {
                return i;
            }
        }
        return -1;
    }

    // Ambil next kode_panel = MAX(kode_panel)+1
    private int nextKodeFromDb() throws java.sql.SQLException {
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.Statement st = c.createStatement(); java.sql.ResultSet rs = st.executeQuery("SELECT IFNULL(MAX(kode_panel),0)+1 FROM panel_surya")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public Menu_anggotakom_panel() {
        initComponents();

        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_ANGGOTA_KOMUNITAS_1.png");
        jLabel10.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")));
        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel10, getContentPane().getComponentCount() - 1);

        // kode panel selalu read-only (auto saat tambah, fix saat update)
        jTextField1.setEditable(false);
        jTextField1.setText("(AUTO)");
        lockIdFieldWithWarning();

        // panggil loader ketika window sudah tampil
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                formWindowOpened(e);
            }
        });

        // klik baris → isi field
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                jTable1MouseClicked(e);
            }
        });

        // biar kolom tidak gepeng
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
    }

    // load tabel
    private void formWindowOpened(java.awt.event.WindowEvent evt) {
        refreshTable();
    }

    private void refreshTable() {
        try {
            String idUserAnggota = Model.Session.idUser;
            jTable1.setModel(panelDao.loadTableByKomunitasPetugas(idUserAnggota));
        } catch (java.sql.SQLException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void clearForm() {
        jTable1.clearSelection();
        jTextField1.setText("(AUTO)");        // kode auto untuk operasi tambah
        jTextField2.setText("");              // watt
        jComboBox1.setSelectedIndex(0);       // status
        jTextField4.setText("");              // tanggal
        jTextField5.setText("");              // catatan
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        int cKode = col("kode_panel");
        int cWatt = col("kapasitas_watt");
        int cStatus = col("status_panel");
        int cTgl = col("tanggal_pasang");
        int cCat = col("catatan");

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, cKode)));
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, cWatt)));
        jComboBox1.setSelectedItem(String.valueOf(jTable1.getValueAt(r, cStatus)));
        Object t = jTable1.getValueAt(r, cTgl);
        jTextField4.setText(t == null ? "" : t.toString());
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, cCat)));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        perbarui = new javax.swing.JButton();
        kembali = new javax.swing.JButton();
        muat = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        tambah = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        perbarui.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        perbarui.setText("Perbarui");
        perbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                perbaruiActionPerformed(evt);
            }
        });
        getContentPane().add(perbarui);
        perbarui.setBounds(70, 380, 120, 30);

        kembali.setBorder(null);
        kembali.setContentAreaFilled(false);
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali);
        kembali.setBounds(10, 460, 110, 30);

        muat.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        muat.setText("Muat Ulang");
        muat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muatActionPerformed(evt);
            }
        });
        getContentPane().add(muat);
        muat.setBounds(240, 420, 120, 30);

        hapus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        hapus.setText("Hapus");
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus);
        hapus.setBounds(240, 380, 120, 30);

        tambah.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tambah.setText("Tambah");
        tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahActionPerformed(evt);
            }
        });
        getContentPane().add(tambah);
        tambah.setBounds(70, 420, 120, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode_Panel", "Kapasitas_Watt", "Status_Panel", "Tanggal_Pasang", "Catatan"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(400, 20, 380, 460);

        jLabel3.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel3.setText("PANEL SURYA");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(90, 120, 170, 30);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Kode panel");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(50, 180, 140, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Kapasitas Watt");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(50, 220, 140, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Status Panel");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(50, 260, 140, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Tanggal Pasang");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(50, 300, 140, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Catatan");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(50, 340, 140, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(190, 170, 150, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(190, 210, 150, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(190, 290, 150, 30);
        getContentPane().add(jTextField5);
        jTextField5.setBounds(190, 330, 150, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "PERBAIKAN", "RUSAK" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(190, 250, 150, 30);

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_ANGGOTA_KOMUNITAS_1.png")); // NOI18N
        getContentPane().add(jLabel10);
        jLabel10.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        Menu_anggota_komunitas anggotaKomunitas = new Menu_anggota_komunitas();
        anggotaKomunitas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void perbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perbaruiActionPerformed
        if (busyUpdate) {
            return;
        }
        busyUpdate = true;
        perbarui.setEnabled(false);
        try {
            if (jTable1.getSelectedRow() < 0 || "(AUTO)".equals(jTextField1.getText().trim())) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Pilih baris pada tabel terlebih dahulu");
                return;
            }

            int kode = Integer.parseInt(jTextField1.getText().trim());
            String sWatt = jTextField2.getText();
            String status = String.valueOf(jComboBox1.getSelectedItem());
            String sTgl = jTextField4.getText();
            String catatan = jTextField5.getText();

            // sekarang: wajib isi catatan saat Perbarui
            var errs = validateForm(sWatt, status, sTgl, catatan, /*requireCatatan=*/ true);

            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Periksa data:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            java.math.BigDecimal watt = parseDecimal2(sWatt, "Kapasitas Watt");
            java.sql.Date tgl = parseDateRequired(sTgl, "Tanggal Pasang");

            int ok = panelDao.updatePanelByPetugas(kode, watt, status, tgl, catatan, Model.Session.idUser);
            javax.swing.JOptionPane.showMessageDialog(this,
                    ok > 0 ? "Perbarui OK" : "Tidak ada yang diubah / bukan komunitasmu");
            refreshTable();
        } catch (Exception ex) {
            showSqlError(ex, "Perbarui");
        } finally {
            busyUpdate = false;
            perbarui.setEnabled(true);
        }
    }//GEN-LAST:event_perbaruiActionPerformed

    private void muatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muatActionPerformed
        int kon = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan dan muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (kon != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        refreshTable();
        clearForm();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");

    }//GEN-LAST:event_muatActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        if (busyDelete) {
            return;
        }
        busyDelete = true;
        hapus.setEnabled(false);
        try {
            String sKode = jTextField1.getText().trim();
            if (sKode.isEmpty() || "(AUTO)".equalsIgnoreCase(sKode)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris / kode panel tidak valid.");
                return;
            }
            int kode = Integer.parseInt(sKode);

            int konfirm = javax.swing.JOptionPane.showConfirmDialog(
                    this,
                    "Yakin mau menghapus panel dengan KODE: " + kode + " ?\nAksi ini tidak bisa dibatalkan.",
                    "Konfirmasi Hapus",
                    javax.swing.JOptionPane.YES_NO_OPTION,
                    javax.swing.JOptionPane.WARNING_MESSAGE
            );
            if (konfirm != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int ok = panelDao.deletePanelByPetugas(kode, Model.Session.idUser);
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    ok > 0 ? "Hapus berhasil." : "Gagal hapus (bukan komunitas Anda / data tidak ada).");

            refreshTable();
            clearForm();
        } catch (Exception ex) {
            showSqlError(ex, "Hapus");
        } finally {
            busyDelete = false;
            hapus.setEnabled(true);
        }
    }//GEN-LAST:event_hapusActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahActionPerformed
        if (busyAdd) {
            return;
        }
        busyAdd = true;
        tambah.setEnabled(false);
        try {
            String sWatt = jTextField2.getText();
            String status = String.valueOf(jComboBox1.getSelectedItem());
            String sTgl = jTextField4.getText();
            String catatan = jTextField5.getText();

            var errs = validateForm(sWatt, status, sTgl, catatan, /*requireCatatan=*/ true);
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Periksa data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            int nextId = nextKodeFromDb();
            java.math.BigDecimal watt = parseDecimal2(sWatt, "Kapasitas Watt");
            java.sql.Date tgl = parseDateRequired(sTgl, "Tanggal Pasang");

            int ok = panelDao.insertPanelByPetugas(nextId, watt, status, tgl, catatan, Model.Session.idUser);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Tambah OK. Kode panel: " + nextId);
                refreshTable();
                clearForm();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal tambah (bukan komunitas Anda?)",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            showSqlError(ex, "Tambah");
        } finally {
            busyAdd = false;
            tambah.setEnabled(true);
        }
    }//GEN-LAST:event_tambahActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_anggotakom_panel().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton hapus;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JButton kembali;
    private javax.swing.JButton muat;
    private javax.swing.JButton perbarui;
    private javax.swing.JButton tambah;
    // End of variables declaration//GEN-END:variables
}
