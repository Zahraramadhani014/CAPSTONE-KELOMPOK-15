package View;

public class Menu_anggotakom_tagihan_warga extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_anggotakom_tagihan_warga.class.getName());
    private final dao.TagihanDao tagihanDao = new dao.TagihanDao();

    // --- helper pilih rumah milik komunitas petugas ---
    static final class RumahItem {

        final int id;
        final String label;

        RumahItem(int id, String label) {
            this.id = id;
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private int pickRumahIdForCurrentPetugas() {
        final String sql
                = "SELECT r.id_rumah, CONCAT(r.nomor_rumah,' - ',r.nama_pemilik,' (',r.alamat_rumah,')') AS label "
                + "FROM rumah r "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "WHERE ak.id_user = ? "
                + "ORDER BY r.nomor_rumah";

        java.util.List<RumahItem> items = new java.util.ArrayList<>();
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, Model.Session.idUser);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new RumahItem(rs.getInt(1), rs.getString(2)));
                }
            }
        } catch (java.sql.SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load rumah: " + e.getMessage());
            return -1;
        }

        if (items.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Tidak ada rumah dalam komunitas Anda.");
            return -1;
        }

        javax.swing.JComboBox<RumahItem> combo
                = new javax.swing.JComboBox<>(items.toArray(new RumahItem[0]));
        int opt = javax.swing.JOptionPane.showConfirmDialog(
                this, combo, "Pilih Rumah", javax.swing.JOptionPane.OK_CANCEL_OPTION);

        if (opt == javax.swing.JOptionPane.OK_OPTION && combo.getSelectedItem() != null) {
            return ((RumahItem) combo.getSelectedItem()).id;
        }
        return -1;
    }

    // ====== VALIDASI ======
    private static final java.util.regex.Pattern P_PERIODE
            = java.util.regex.Pattern.compile("^\\d{4}-(0[1-9]|1[0-2])$"); // YYYY-MM
    private static final java.util.regex.Pattern P_DEC2
            = java.util.regex.Pattern.compile("^\\d{1,10}(\\.\\d{1,2})?$");
    private static final java.util.regex.Pattern P_DEC3
            = java.util.regex.Pattern.compile("^\\d{1,10}(\\.\\d{1,3})?$");

    private java.math.BigDecimal scale2(String s) {
        return new java.math.BigDecimal(s.trim()).setScale(2, java.math.RoundingMode.HALF_UP);
    }

    private java.math.BigDecimal scale3(String s) {
        return new java.math.BigDecimal(s.trim()).setScale(3, java.math.RoundingMode.HALF_UP);
    }

    private boolean editingExisting = false; // true kalau user sedang edit data lama (dipilih dari tabel)

    private java.util.List<String> validateFormForInsertOrUpdate(boolean forInsert) {
        var errs = new java.util.ArrayList<String>();

        String sid = jTextField1.getText().trim();
        String periode = jTextField2.getText().trim();
        String sKwh = jTextField3.getText().trim();
        String sTarif = jTextField4.getText().trim();
        String sTotal = jTextField5.getText().trim();
        String status = normStatus(String.valueOf(jComboBox1.getSelectedItem()));

        if (forInsert) {
            // Saat tambah, ID boleh "(AUTO)" atau angka
            if (!"(AUTO)".equalsIgnoreCase(sid) && !sid.chars().allMatch(Character::isDigit)) {
                errs.add("Id Tagihan harus angka atau '(AUTO)'.");
            }
        } else {
            if (sid.isEmpty() || !sid.chars().allMatch(Character::isDigit)) {
                errs.add("Id Tagihan tidak valid.");
            }
        }

        if (!P_PERIODE.matcher(periode).matches()) {
            errs.add("Periode wajib format YYYY-MM (contoh 2024-03).");
        }
        if (!P_DEC3.matcher(sKwh).matches()) {
            errs.add("Total KWH harus angka >= 0 (maks 3 desimal).");
        }
        if (!P_DEC2.matcher(sTarif).matches()) {
            errs.add("Tarif per KWH harus angka >= 0 (maks 2 desimal).");
        }
        if (!sTotal.isBlank() && !P_DEC2.matcher(sTotal).matches()) {
            errs.add("Total Tagihan (jika diisi) harus angka >= 0 (maks 2 desimal).");
        }
        if (!status.equals("LUNAS") && !status.equals("BELUM LUNAS")) {
            errs.add("Status hanya boleh LUNAS atau BELUM LUNAS.");
        }
        return errs;
    }

    private void prefillNextId() {
        try {
            int next = tagihanDao.nextId();
            jTextField1.setText(String.valueOf(next));
        } catch (Exception ex) {
            jTextField1.setText("(AUTO)");
        }
        // dikunci supaya user tidak ubah
        jTextField1.setEditable(false);
        jTextField1.setFocusable(false);
        removeIdGuardIfAny(); // pastikan tidak ada guard lama
    }

    // Normalisasi teks status agar rapi (hapus spasi & kapital)
    private static String normStatus(String s) {
        if (s == null) {
            return "";
        }
        s = s.trim().toUpperCase();
        if (s.equals("LUNAS")) {
            return "LUNAS";
        }
        if (s.equals("BELUM LUNAS")) {
            return "BELUM LUNAS";
        }
        return s;
    }

    // ====== UTIL UI ======
    private void refreshTable() {
        try {
            jTable1.setModel(tagihanDao.loadTableByKomunitasPetugas(Model.Session.idUser));
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
            jTable1.clearSelection();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void clearFormForInsert() {
        editingExisting = false;

        jTextField1.setText("(AUTO)");          // tampilkan AUTO
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jComboBox1.setSelectedItem("BELUM LUNAS");

        // Kunci ID + pasang warning saat diklik
        applyIdGuard("Id dibuat otomatis saat menambah data.");

        recomputeTotal();
    }

    private void fillFormFromRow(int r) {
        editingExisting = true;

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0))); // id_tagihan
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, 1))); // periode
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2))); // total_kwh
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3))); // tarif_per_kwh
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, 4))); // total_tagihan
        jComboBox1.setSelectedItem(String.valueOf(jTable1.getValueAt(r, 5))); // status

        // kunci ID saat mengedit data lama
        applyIdGuard("Id Tagihan tidak boleh diubah");

        recomputeTotal();
    }

    // pasang guard di field ID agar muncul peringatan saat diklik/ketik
    private java.awt.event.MouseListener idMouseGuard;
    private java.awt.event.KeyListener idKeyGuard;

    private void applyIdGuard(String reason) {
        jTextField1.setEditable(false);
        jTextField1.setFocusable(false);
        jTextField1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));

        removeIdGuardIfAny();
        idMouseGuard = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                javax.swing.JOptionPane.showMessageDialog(Menu_anggotakom_tagihan_warga.this, reason);
                e.consume();
            }
        };
        idKeyGuard = new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        };
        jTextField1.addMouseListener(idMouseGuard);
        jTextField1.addKeyListener(idKeyGuard);
    }

    private void removeIdGuardIfAny() {
        if (idMouseGuard != null) {
            jTextField1.removeMouseListener(idMouseGuard);
            idMouseGuard = null;
        }
        if (idKeyGuard != null) {
            jTextField1.removeKeyListener(idKeyGuard);
            idKeyGuard = null;
        }
    }

    /**
     * Creates new form Menu_anggotakom_warga
     */
    public Menu_anggotakom_tagihan_warga() {
        initComponents();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(
                new String[]{"LUNAS", "BELUM LUNAS"}
        ));

        wireAutoTotal();
        recomputeTotal();

        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_ANGGOTA_KOMUNITAS_1.png");
        jLabel11.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel11, getContentPane().getComponentCount() - 1);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                refreshTable();
                clearFormForInsert();
            }
        });

        // klik tabel -> isi form + kunci ID
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int r = jTable1.getSelectedRow();
                if (r >= 0) {
                    fillFormFromRow(r);
                }
            }
        });

        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);

    }

    // --- helper angka ---
    private java.math.BigDecimal parseDecOrNull(String s) {
        if (s == null) {
            return null;
        }
        s = s.trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            return new java.math.BigDecimal(s);
        } catch (NumberFormatException e) {
            return null; // biar gak error saat user masih ngetik
        }
    }

// hitung total = kwh * tarif (2 desimal). Kosongkan kalau belum valid.
    private void recomputeTotal() {
        var kwh = parseDecOrNull(jTextField3.getText()); // Total KWH
        var tarif = parseDecOrNull(jTextField4.getText()); // Tarif per KWH
        if (kwh != null && tarif != null) {
            var total = kwh.multiply(tarif).setScale(2, java.math.RoundingMode.HALF_UP);
            jTextField5.setText(total.toPlainString());
        } else {
            jTextField5.setText(""); // belum lengkap → kosongkan
        }
    }

// pasang listener supaya total otomatis dihitung saat ketik/edit
    private void wireAutoTotal() {
        javax.swing.event.DocumentListener dl = new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                recomputeTotal();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                recomputeTotal();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                recomputeTotal();
            }
        };
        jTextField3.getDocument().addDocumentListener(dl);
        jTextField4.getDocument().addDocumentListener(dl);

        // rapikan format angka saat pindah fokus (opsional)
        java.awt.event.FocusAdapter fa = new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                recomputeTotal();
            }
        };
        jTextField3.addFocusListener(fa);
        jTextField4.addFocusListener(fa);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Hapus");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(220, 380, 110, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id_Tagihan", "Periode", "Total_KWH", "Tarif_Per_KWH", "Total_Tagihan", "Status_Tagihan"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(370, 20, 400, 460);

        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(10, 460, 110, 30);

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(50, 420, 110, 30);

        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setText("Tambah");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(50, 380, 110, 30);

        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton5.setText("Muat Ulang");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(220, 420, 110, 30);

        jLabel3.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel3.setText("TAGIHAN WARGA");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(60, 130, 220, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Tagihan");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 180, 110, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Periode");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 210, 110, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Total KWH");
        jLabel6.setToolTipText("");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 240, 110, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Tarif Per KWH");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 270, 110, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Total Tagihan");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(40, 300, 110, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status Tagihan");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(40, 330, 110, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(150, 170, 170, 30);

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField2);
        jTextField2.setBounds(150, 200, 170, 30);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(150, 230, 170, 30);

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField4);
        jTextField4.setBounds(150, 260, 170, 30);

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5);
        jTextField5.setBounds(150, 290, 170, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LUNAS ", "BELUM LUNAS" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(150, 320, 170, 30);

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_ANGGOTA_KOMUNITAS_1.png")); // NOI18N
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Menu_anggota_komunitas anggotaKomunitas = new Menu_anggota_komunitas();
        anggotaKomunitas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            String sid = jTextField1.getText().trim();
            if (sid.isEmpty() || !sid.chars().allMatch(Character::isDigit)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Isi/ pilih Id Tagihan yang valid dulu.");
                return;
            }
            int id = Integer.parseInt(sid);

            int kon = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Yakin hapus tagihan ID " + id + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION);
            if (kon != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int ok = tagihanDao.deleteByPetugas(id, Model.Session.idUser);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Hapus OK.");
                refreshTable();
                clearFormForInsert();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal hapus (data tidak ditemukan / bukan komunitasmu).",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            if (!editingExisting) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dari tabel terlebih dahulu.");
                return;
            }

            var errs = validateFormForInsertOrUpdate(false);
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(
                        this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            int id = Integer.parseInt(jTextField1.getText().trim());
            String periode = jTextField2.getText().trim();
            var kwh = new java.math.BigDecimal(jTextField3.getText().trim());
            var tarif = new java.math.BigDecimal(jTextField4.getText().trim());
            var total = jTextField5.getText().isBlank() ? null
                    : new java.math.BigDecimal(jTextField5.getText().trim());
            String status = normStatus(String.valueOf(jComboBox1.getSelectedItem()));

            int ok = tagihanDao.updateByPetugas(id, periode, kwh, tarif, total, status, Model.Session.idUser);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Perbarui OK.");
                refreshTable();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Tidak ada yang diubah / data bukan komunitasmu.",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            var errs = validateFormForInsertOrUpdate(true);
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(
                        this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            // === pilih rumah lewat dialog (bukan dari tabel) ===
            int idRumah = pickRumahIdForCurrentPetugas();
            if (idRumah <= 0) {
                return; // batal
            }
            // === ID OTOMATIS ===
            String sid = jTextField1.getText().trim();
            int id = "(AUTO)".equalsIgnoreCase(sid) || sid.isBlank()
                    ? tagihanDao.nextId()
                    : Integer.parseInt(sid);

            String periode = jTextField2.getText().trim();
            var kwh   = scale3(jTextField3.getText());
            var tarif = scale2(jTextField4.getText());
            var total = jTextField5.getText().isBlank() ? null
                    : new java.math.BigDecimal(jTextField5.getText().trim());
            String status = normStatus(String.valueOf(jComboBox1.getSelectedItem()));

            int ok = tagihanDao.insertByPetugas(id, periode, kwh, tarif, total, status, idRumah, Model.Session.idUser);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Tambah OK. ID: " + id);
                refreshTable();
                clearFormForInsert();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal tambah (bukan komunitasmu / Id sudah ada).",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int kon = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Batalkan perubahan dan muat ulang data?",
                "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);

        if (kon != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        refreshTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_anggotakom_tagihan_warga().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
