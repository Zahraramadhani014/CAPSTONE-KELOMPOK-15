package View;

public class Menu_warga_datarumah extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_warga_datarumah.class.getName());

    /**
     * Creates new form Menu_Warga_DataRumah
     */
    // simpan model agar bisa dipakai ulang
    private javax.swing.table.DefaultTableModel rumahModel;
    private VerticalRecordTableModel vModel;
    private String currentStatus;

// pop-up untuk field yang tidak boleh diubah
    // Tampilkan pesan HANYA saat diklik (tidak saat form terbuka)
    private void guardReadOnly(javax.swing.JTextField tf) {
        tf.setEditable(false);                                   // tidak bisa diedit
        tf.setFocusable(false);                                  // tidak mengambil fokus otomatis
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));

        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                javax.swing.JOptionPane.showMessageDialog(
                        Menu_warga_datarumah.this,
                        "Data ini tidak boleh diubah."
                );
                e.consume();
            }
        });

        // jaga-jaga kalau ada input keyboard masuk
        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
    }

    // ===== helper: combo read-only dengan pop-up saat dicoba diubah =====
    private void guardComboReadOnly(javax.swing.JComboBox<String> cb) {
        cb.setFocusable(false);
        cb.addMouseWheelListener(e -> e.consume()); // blok scroll wheel
        cb.addActionListener(e -> {
            Object sel = cb.getSelectedItem();
            if (currentStatus != null && sel != null && !currentStatus.equals(sel.toString())) {
                javax.swing.JOptionPane.showMessageDialog(
                        Menu_warga_datarumah.this,
                        "Data ini tidak boleh diubah.");
                cb.setSelectedItem(currentStatus); // kembalikan
            }
        });
        cb.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                javax.swing.JOptionPane.showMessageDialog(
                        Menu_warga_datarumah.this,
                        "Data ini tidak boleh diubah.");
                e.consume();
            }
        });
    }

    // ==== VALIDASI & STYLING INPUT ====
    private static final java.awt.Color ERR_BG = new java.awt.Color(255, 235, 238); // pink lembut
    private static final java.util.regex.Pattern P_NOMOR = java.util.regex.Pattern.compile("^[A-Za-z0-9\\-_/ ]{1,20}$");
    private static final java.util.regex.Pattern P_NAMA = java.util.regex.Pattern.compile("^[A-Za-zÀ-ÖØ-öø-ÿ' .\\-]{3,100}$");
    private static final java.util.regex.Pattern P_TELP = java.util.regex.Pattern.compile("^\\d{10,12}$"); // 10-12 digit

    private void resetFieldStyles() {
        nomor.setBackground(java.awt.Color.white);
        nama.setBackground(java.awt.Color.white);
        alamat.setBackground(java.awt.Color.white);
        telpon.setBackground(java.awt.Color.white);
    }

    private java.util.List<String> validateForm() {
        resetFieldStyles();
        java.util.List<String> errs = new java.util.ArrayList<>();

        String vNomor = nomor.getText().trim();
        String vNama = nama.getText().trim();
        String vAlamat = alamat.getText().trim();
        String vTelp = telpon.getText().trim();

        if (vNomor.isEmpty() || !P_NOMOR.matcher(vNomor).matches()) {
            errs.add("Nomor Rumah wajib 1–20 karakter (huruf/angka, spasi, -, _, /).");
            nomor.setBackground(ERR_BG);
        }
        if (vNama.isEmpty() || !P_NAMA.matcher(vNama).matches()) {
            errs.add("Nama Pemilik 3–100 karakter, hanya huruf, spasi, titik, apostrof atau tanda minus.");
            nama.setBackground(ERR_BG);
        }
        if (vAlamat.isEmpty() || vAlamat.length() < 5 || vAlamat.length() > 200) {
            errs.add("Alamat Rumah 5–200 karakter.");
            alamat.setBackground(ERR_BG);
        }
        if (vTelp.isEmpty() || !P_TELP.matcher(vTelp).matches()) {
            errs.add("No. Telp harus 10–12 digit angka.");
            telpon.setBackground(ERR_BG);
        }

        // status & tanggal tidak boleh diubah (hanya berjaga-jaga)
        Object sel = status.getSelectedItem();
        if (currentStatus != null && sel != null && !currentStatus.equals(sel.toString())) {
            errs.add("Status Koneksi tidak boleh diubah.");
        }
        if (tanggal.isEditable() || tanggal.isFocusable()) {
            errs.add("Tanggal bergabung tidak boleh diubah.");
        }

        return errs;
    }

    public Menu_warga_datarumah() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);
        loadTabel();

        var url = getClass().getResource("/View/assets/TAGIHAN_BULANAN_WARGA_2.png");
        jLabel1.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel1, getContentPane().getComponentCount() - 1);

        // kunci field yang tidak boleh diubah
        guardReadOnly(id);
        guardReadOnly(tanggal);
        guardComboReadOnly(status); // status_koneksi via combo

        muatulang = new javax.swing.JButton();
        muatulang.setBorder(null);
        muatulang.setContentAreaFilled(false);
        muatulang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muatulangActionPerformed(evt);
            }
        });
        getContentPane().add(muatulang);
        muatulang.setBounds(380, 440, 110, 30); // posisimu sendiri

    }

    private void loadTabel() {
        try {
            dao.RumahDao dao = new dao.RumahDao();

            String idUser = Model.Session.idUser;
            if (idUser == null || idUser.isBlank()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Session kosong. Silakan login ulang.");
                return;
            }

            // model horisontal asli dari DAO
            rumahModel = dao.loadTableByUserId(idUser);

            // bungkus jadi vertikal (Field | Value)
            vModel = new VerticalRecordTableModel(rumahModel);
            jTable1.setModel(vModel);

            // tampilkan record pertama
            if (rumahModel.getRowCount() > 0) {
                vModel.setRowIndex(0);
                fillTextFieldsFromModel(0);
            }

            jTable1.getTableHeader().setReorderingAllowed(false);
            jTable1.setRowHeight(24);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(120);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(300);

        } catch (java.sql.SQLException ex) {
            java.util.logging.Logger.getLogger(getClass().getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Gagal memuat data rumah: " + ex.getMessage(),
                    "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    // ===== sinkronkan ke textfield/combo =====
    private void fillTextFieldsFromModel(int row) {
        if (rumahModel == null || rumahModel.getRowCount() == 0) {
            return;
        }

        id.setText(String.valueOf(rumahModel.getValueAt(row, 0)));     // id_rumah
        nomor.setText(String.valueOf(rumahModel.getValueAt(row, 1)));  // nomor_rumah
        nama.setText(String.valueOf(rumahModel.getValueAt(row, 2)));   // nama_pemilik
        alamat.setText(String.valueOf(rumahModel.getValueAt(row, 3))); // alamat_rumah
        telpon.setText(String.valueOf(rumahModel.getValueAt(row, 4))); // no_telp

        currentStatus = String.valueOf(rumahModel.getValueAt(row, 5)); // status_koneksi
        status.setSelectedItem(currentStatus);

        Object tgl = rumahModel.getValueAt(row, 6);                    // tanggal_bergabung
        tanggal.setText(tgl == null ? "" : tgl.toString());
    }

    // Kembalikan tampilan form ke data terakhir dari DB/model
    private void reloadFromExistingModel() {
        if (rumahModel != null && rumahModel.getRowCount() > 0 && vModel != null) {
            vModel.setRowIndex(0);          // tampilkan baris pertama
            fillTextFieldsFromModel(0);     // isi text field lagi
            resetFieldStyles();             // (opsional) bersihkan warna error jika ada

            // pastikan combo status balik ke nilai asli
            if (currentStatus != null) {
                status.setSelectedItem(currentStatus);
            }
        }
    }

//// Opsional: kalau belum ada, tambahkan biar pemanggilan tidak merah.
//// Kalau kamu tidak butuh, boleh hapus pemanggilan resetFieldStyles() di atas.
//    private void resetFieldStyles() {
//        // contoh: kembalikan background ke default
//        java.awt.Color def = javax.swing.UIManager.getColor("TextField.background");
//        nomor.setBackground(def);
//        nama.setBackground(def);
//        alamat.setBackground(def);
//        telpon.setBackground(def);
//    }

    // ===== model tabel vertikal (Field | Value) =====
    private static final class VerticalRecordTableModel extends javax.swing.table.AbstractTableModel {

        private final javax.swing.table.TableModel source;
        private int rowIndex = -1;

        VerticalRecordTableModel(javax.swing.table.TableModel source) {
            this.source = source;
        }

        public void setRowIndex(int row) {
            this.rowIndex = row;
            fireTableDataChanged();
        }

        @Override
        public int getRowCount() {
            return source.getColumnCount();
        }

        @Override
        public int getColumnCount() {
            return 2;
        }

        @Override
        public String getColumnName(int c) {
            return (c == 0) ? "Field" : "Value";
        }

        @Override
        public Object getValueAt(int r, int c) {
            if (c == 0) {
                return source.getColumnName(r);
            }
            if (rowIndex < 0) {
                return "";
            }
            return source.getValueAt(rowIndex, r);
        }

        @Override
        public boolean isCellEditable(int r, int c) {
            return false;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        perbarui = new javax.swing.JButton();
        muatulang = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        nomor = new javax.swing.JTextField();
        nama = new javax.swing.JTextField();
        alamat = new javax.swing.JTextField();
        tanggal = new javax.swing.JTextField();
        telpon = new javax.swing.JTextField();
        status = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 500));
        setResizable(false);
        setSize(new java.awt.Dimension(800, 500));
        getContentPane().setLayout(null);

        jButton1.setBorder(null);
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(130, 440, 110, 40);

        perbarui.setBorder(null);
        perbarui.setContentAreaFilled(false);
        perbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                perbaruiActionPerformed(evt);
            }
        });
        getContentPane().add(perbarui);
        perbarui.setBounds(540, 450, 110, 30);

        muatulang.setBorder(null);
        muatulang.setContentAreaFilled(false);
        muatulang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                muatulangActionPerformed(evt);
            }
        });
        getContentPane().add(muatulang);
        muatulang.setBounds(340, 450, 110, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "id_rumah", "nomor_rumah", "nama_pemilik", "alamat_rumah", "no_telp", "status_koneksi", "tanggal_bergabung"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(370, 210, 290, 220);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Tgl.Bergabung");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(460, 120, 100, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Id Rumah");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(210, 120, 70, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Nomor Rumah");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(200, 170, 100, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Nama Pemilik");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(200, 220, 100, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Alamat Rumah");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(200, 270, 100, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("No.Telp");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(220, 320, 60, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Status Koneksi");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(200, 370, 100, 20);
        getContentPane().add(id);
        id.setBounds(140, 140, 220, 30);
        getContentPane().add(nomor);
        nomor.setBounds(140, 190, 220, 30);
        getContentPane().add(nama);
        nama.setBounds(140, 240, 220, 30);
        getContentPane().add(alamat);
        alamat.setBounds(140, 290, 220, 30);
        getContentPane().add(tanggal);
        tanggal.setBounds(410, 140, 220, 30);
        getContentPane().add(telpon);
        telpon.setBounds(140, 340, 220, 30);

        status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "GA AKTIF", "PUTUS" }));
        getContentPane().add(status);
        status.setBounds(140, 390, 220, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\TAGIHAN_BULANAN_WARGA_2.png")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(-4, -4, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Menu_warga warga = new Menu_warga();
        warga.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void perbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_perbaruiActionPerformed
        try {
            if (id.getText().isBlank()) {
                javax.swing.JOptionPane.showMessageDialog(this, "ID Rumah tidak boleh kosong.");
                return;
            }
            int idRumah = Integer.parseInt(id.getText().trim());

            // VALIDASI
            java.util.List<String> errs = validateForm();
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Periksa kembali data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String nomorRumah = nomor.getText().trim();
            String namaPemilik = nama.getText().trim();
            String alamatRumah = alamat.getText().trim();
            String noTelp = telpon.getText().trim();

            // KONFIRMASI
            int ok = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Simpan perubahan data rumah?",
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (ok != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            // UPDATE — guard kepemilikan oleh user yang login
            try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(
                    "UPDATE rumah SET nomor_rumah=?, nama_pemilik=?, alamat_rumah=?, no_telp=? "
                    + "WHERE id_rumah=? AND USER_id_user=?")) {

                int i = 1;
                ps.setString(i++, nomorRumah);
                ps.setString(i++, namaPemilik);
                ps.setString(i++, alamatRumah);
                ps.setString(i++, noTelp);
                ps.setInt(i++, idRumah);
                ps.setString(i, Model.Session.idUser);

                int changed = ps.executeUpdate();
                if (changed > 0) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Perubahan tersimpan.");
                    loadTabel(); // refresh tampilan & text field
                } else {
                    javax.swing.JOptionPane.showMessageDialog(
                            this,
                            "Gagal memperbarui. Pastikan data ini milik akun Anda.",
                            "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE
                    );
                }
            }
        } catch (NumberFormatException ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "ID Rumah harus angka yang valid.");
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(getClass().getName())
                    .log(java.util.logging.Level.SEVERE, null, ex);
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_perbaruiActionPerformed

    private void muatulangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_muatulangActionPerformed
        int ok = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Batalkan perubahan dan muat ulang data?",
                "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION
        );
        if (ok != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        // Cara A: ambil ulang dari DB (paling aman)
        loadTabel();

        // Cara B (tanpa query DB): cukup tampilkan ulang dari model yang ada
        // reloadFromExistingModel();
        javax.swing.JOptionPane.showMessageDialog(this, "Data sudah dikembalikan seperti semula.");

    }//GEN-LAST:event_muatulangActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_warga_datarumah().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alamat;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton muatulang;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nomor;
    private javax.swing.JButton perbarui;
    private javax.swing.JComboBox<String> status;
    private javax.swing.JTextField tanggal;
    private javax.swing.JTextField telpon;
    // End of variables declaration//GEN-END:variables
}
