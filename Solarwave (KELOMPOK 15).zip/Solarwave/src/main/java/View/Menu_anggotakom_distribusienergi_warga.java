package View;

public class Menu_anggotakom_distribusienergi_warga extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_anggotakom_distribusienergi_warga.class.getName());
    private final dao.DistribusiEnergiDao distribusiDao = new dao.DistribusiEnergiDao();

    private int pickRumahIdForCurrentPetugas() {
        final String sql
                = "SELECT r.id_rumah, CONCAT(r.nomor_rumah,' - ',r.nama_pemilik,' (',r.alamat_rumah,')') AS label "
                + "FROM rumah r "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "WHERE ak.id_user = ? "
                + "ORDER BY r.nomor_rumah";

        java.util.List<RumahItem> items = new java.util.ArrayList<>();
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, Model.Session.idUser);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new RumahItem(rs.getInt(1), rs.getString(2)));
                }
            }
        } catch (java.sql.SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load daftar rumah: " + e.getMessage());
            return -1;
        }

        if (items.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Tidak ada rumah di komunitas Anda.");
            return -1;
        }

        javax.swing.JComboBox<RumahItem> combo
                = new javax.swing.JComboBox<>(items.toArray(new RumahItem[0]));
        combo.setSelectedIndex(0);

        int opt = javax.swing.JOptionPane.showConfirmDialog(
                this, combo, "Pilih Rumah", javax.swing.JOptionPane.OK_CANCEL_OPTION);

        if (opt == javax.swing.JOptionPane.OK_OPTION) {
            RumahItem picked = (RumahItem) combo.getSelectedItem();
            return picked == null ? -1 : picked.id;
        }
        return -1;
    }

    // ===== Lock & warning untuk kolom ID =====
    private void lockIdFieldWithWarning() {
        // tidak bisa diketik/di-paste
        jTextField1.setEditable(false);
        jTextField1.setTransferHandler(null); // blok paste
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });

        // saat diklik, tampilkan info
        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                String teks = jTextField1.getText();
                String msg = "(AUTO)".equalsIgnoreCase(teks)
                        ? "ID Distribusi dibuat otomatis saat menambah data."
                        : "ID Distribusi tidak boleh diubah.";
                javax.swing.JOptionPane.showMessageDialog(
                        Menu_anggotakom_distribusienergi_warga.this,
                        msg, "Informasi", javax.swing.JOptionPane.INFORMATION_MESSAGE
                );
                e.consume();
            }
        });

        // kursor biasa (bukan caret teks) biar terasa non-editable
        jTextField1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
    }

    // --- Helper item untuk combo ---
    static final class RumahItem {

        final int id;
        final String label;

        RumahItem(int id, String label) {
            this.id = id;
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        } // yang tampil di combo
    }

    private static final java.util.regex.Pattern P_DESIMAL
            = java.util.regex.Pattern.compile("^\\d{1,8}(\\.\\d{1,2})?$"); // max 8 digit + 2 desimal
    private static final int MAX_CATATAN = 100;

    private java.util.List<String> validateForm(
        String tglStr, String kwhStr, String biayaStr, String catatanStr,
        boolean requireCatatan   // <-- tambahkan flag
) {
    java.util.List<String> errs = new java.util.ArrayList<>();

    // tanggal
    try {
        if (tglStr == null || tglStr.isBlank()) throw new IllegalArgumentException();
        java.sql.Date.valueOf(tglStr.trim()); // yyyy-MM-dd
    } catch (Exception e) {
        errs.add("Tanggal harus format yyyy-MM-dd (contoh 2024-03-01).");
    }

    // angka
    if (kwhStr == null || !P_DESIMAL.matcher(kwhStr.trim()).matches()) {
        errs.add("Pemakaian KWH harus angka >=0 (maks 2 desimal).");
    }
    if (biayaStr == null || !P_DESIMAL.matcher(biayaStr.trim()).matches()) {
        errs.add("Biaya per KWH harus angka >=0 (maks 2 desimal).");
    }

    // catatan
    if (requireCatatan && (catatanStr == null || catatanStr.trim().isEmpty())) {
        errs.add("Catatan wajib diisi.");
    }
    if (catatanStr != null && catatanStr.trim().length() > MAX_CATATAN) {
        errs.add("Catatan maksimal " + MAX_CATATAN + " karakter.");
    }

    return errs;
}


    private int nextIdFromDb() throws java.sql.SQLException {
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.Statement st = c.createStatement(); java.sql.ResultSet rs = st.executeQuery("SELECT IFNULL(MAX(id_distribusi),0)+1 FROM distribusi_energi")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private boolean isRumahInKomunitasPetugas(int idRumah, String idUserPetugas) throws java.sql.SQLException {
        final String sql
                = "SELECT 1 "
                + "FROM rumah r "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "WHERE ak.id_user=? AND r.id_rumah=? "
                + "LIMIT 1";
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, idUserPetugas);
            ps.setInt(2, idRumah);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private Integer rumahIdOfDistribusi(int idDistribusi) throws java.sql.SQLException {
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(
                "SELECT RUMAH_id_rumah FROM distribusi_energi WHERE id_distribusi=?")) {
            ps.setInt(1, idDistribusi);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : null;
            }
        }
    }

    // ====== INSERT & UPDATE (dengan guard komunitas) ======
    private int insertDistribusiAuto(int idRumah, java.sql.Date tgl, java.math.BigDecimal kwh,
            java.math.BigDecimal biaya, String catatan) throws java.sql.SQLException {
        if (!isRumahInKomunitasPetugas(idRumah, Model.Session.idUser)) {
            return 0;
        }
        final String sql = "INSERT INTO distribusi_energi "
                + "(id_distribusi, tanggal_distribusi, pemakaian_kwh, biaya_per_kwh, catatan, RUMAH_id_rumah) "
                + "VALUES (?,?,?,?,?,?)";
        int nextId = nextIdFromDb();
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setInt(i++, nextId);
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i, idRumah);
            return ps.executeUpdate();
        }
    }

    private int updateDistribusiByPetugas(int idDistribusi, java.sql.Date tgl, java.math.BigDecimal kwh,
            java.math.BigDecimal biaya, String catatan) throws java.sql.SQLException {
        Integer idRumah = rumahIdOfDistribusi(idDistribusi);
        if (idRumah == null) {
            return 0;
        }
        if (!isRumahInKomunitasPetugas(idRumah, Model.Session.idUser)) {
            return 0;
        }

        final String sql = "UPDATE distribusi_energi "
                + "SET tanggal_distribusi=?, pemakaian_kwh=?, biaya_per_kwh=?, catatan=? "
                + "WHERE id_distribusi=?";
        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setDate(i++, tgl);
            ps.setBigDecimal(i++, kwh);
            ps.setBigDecimal(i++, biaya);
            ps.setString(i++, catatan);
            ps.setInt(i, idDistribusi);
            return ps.executeUpdate();
        }
    }

    /**
     * Creates new form Menu_anggotakom_warga
     */
    public Menu_anggotakom_distribusienergi_warga() {
        initComponents();

        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_ANGGOTA_KOMUNITAS_1.png");
        jLabel4.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel4, getContentPane().getComponentCount() - 1);

        // pilih single row & pasang listener klik
        jTable1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                onTableClick();
            }
        });

        // di constructor, setelah initComponents():
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                onOpened();
            }
        });
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTextField1.setEditable(false);
        jTextField1.setText("(AUTO)");
        lockIdFieldWithWarning();
    }

    private int colT(String name) {
        javax.swing.table.TableColumnModel cm = jTable1.getColumnModel();
        for (int i = 0; i < cm.getColumnCount(); i++) {
            if (name.equalsIgnoreCase(cm.getColumn(i).getHeaderValue().toString())) {
                return i;
            }
        }
        String n = name.toLowerCase();
        for (int i = 0; i < cm.getColumnCount(); i++) {
            String h = cm.getColumn(i).getHeaderValue().toString().toLowerCase();
            if (h.startsWith(n)) {
                return i;
            }
        }
        return -1;
    }

    private void onTableClick() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        int cId = colT("id_distribusi");
        int cTgl = colT("tanggal_distribusi");
        int cKwh = colT("pemakaian_kwh");
        int cBiaya = colT("biaya_per_kwh");
        int cCat = colT("catatan");

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, cId)));
        Object t = jTable1.getValueAt(r, cTgl);
        jTextField2.setText(t == null ? "" : t.toString());
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, cKwh)));
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, cBiaya)));
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, cCat)));
    }

    private void onOpened() {
        refreshTable();
    }

    private void refreshTable() {
        try {
            jTable1.setModel(distribusiDao.loadTableByKomunitasPetugas(Model.Session.idUser));
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void clearForm() {
        jTextField1.setText("(AUTO)");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
    }

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }
        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0)));
        Object t = jTable1.getValueAt(r, 1);
        jTextField2.setText(t == null ? "" : t.toString());
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2)));
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3)));
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, 4)));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Perbarui");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(50, 370, 110, 30);

        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(20, 460, 90, 30);

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setText("Hapus");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(220, 410, 110, 30);

        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setText("Tambah");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(220, 370, 110, 30);

        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton5.setText("Muat Ulang");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(50, 410, 110, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id_Distribusi", "Tanggal_Distribusi", "Pemakaian_KWH", "Biaya_Per_KWH", "Catatan"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(370, 20, 410, 460);

        jLabel3.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel3.setText("DISTRIBUSI ENERGI");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(50, 120, 250, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Distribusi");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 170, 130, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Tanggal Distribusi");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 210, 130, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Pemakaian KWH");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(20, 250, 130, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Biaya Per KWH");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(20, 290, 130, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Catatan");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(20, 330, 130, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(150, 160, 160, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(150, 200, 160, 30);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(150, 240, 160, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(150, 280, 160, 30);
        getContentPane().add(jTextField5);
        jTextField5.setBounds(150, 320, 160, 30);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_ANGGOTA_KOMUNITAS_1.png")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Menu_anggota_komunitas anggotaKomunitas = new Menu_anggota_komunitas();
        anggotaKomunitas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try {
            if (jTextField1.getText().isBlank() || "(AUTO)".equals(jTextField1.getText().trim())) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris dari tabel yang ingin diperbarui.");
                return;
            }
            int id = Integer.parseInt(jTextField1.getText().trim());

            String sTgl = jTextField2.getText();
            String sKwh = jTextField3.getText();
            String sBiaya = jTextField4.getText();
            String sCatat = jTextField5.getText();

            java.util.List<String> errs = validateForm(sTgl, sKwh, sBiaya, sCatat, true);
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Periksa data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            java.sql.Date tgl = java.sql.Date.valueOf(sTgl.trim());
            java.math.BigDecimal kwh = new java.math.BigDecimal(sKwh.trim());
            java.math.BigDecimal biaya = new java.math.BigDecimal(sBiaya.trim());
            String catatan = sCatat.trim();

            int ok = updateDistribusiByPetugas(id, tgl, kwh, biaya, catatan);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Perubahan tersimpan.");
                refreshTable();
                clearForm();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal memperbarui. Pastikan data milik komunitas Anda.",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }


    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            if (jTextField1.getText().isBlank() || "(AUTO)".equals(jTextField1.getText().trim())) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris dari tabel terlebih dahulu.");
                return;
            }
            int id = Integer.parseInt(jTextField1.getText().trim());

            int kon = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Yakin hapus data ini?", "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (kon != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int ok = distribusiDao.deleteByPetugas(id, Model.Session.idUser);
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Hapus OK" : "Gagal hapus / bukan komunitasmu");
            refreshTable();
            clearForm();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            String sTgl = jTextField2.getText();
            String sKwh = jTextField3.getText();
            String sBiaya = jTextField4.getText();
            String sCatat = jTextField5.getText();

            java.util.List<String> errs = validateForm(sTgl, sKwh, sBiaya, sCatat, true); // wajib catatan
            if (!errs.isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Periksa data berikut:\n- " + String.join("\n- ", errs),
                        "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            int idRumah = pickRumahIdForCurrentPetugas();
            if (idRumah <= 0) {
                return;
            }

            java.sql.Date tgl = java.sql.Date.valueOf(sTgl.trim());
            java.math.BigDecimal kwh = new java.math.BigDecimal(sKwh.trim());
            java.math.BigDecimal biaya = new java.math.BigDecimal(sBiaya.trim());
            String catatan = sCatat.trim();

            int ok = insertDistribusiAuto(idRumah, tgl, kwh, biaya, catatan);
            if (ok > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Tambah OK (ID otomatis).");
                refreshTable();
                clearForm();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal tambah. Rumah bukan komunitas Anda.",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int ok = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Batalkan perubahan dan muat ulang data dari database?",
                "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION
        );
        if (ok != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        // reload tabel dari DB + bersihkan form
        refreshTable();          // sudah kamu buat di atas
        jTable1.clearSelection();
        clearForm();             // set id ke "(AUTO)" dan kosongkan field lain

        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");

    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_anggotakom_distribusienergi_warga().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
