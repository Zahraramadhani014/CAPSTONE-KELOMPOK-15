package View;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

public class Menu_anggotakom_rumah_warga extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger
            = java.util.logging.Logger.getLogger(Menu_anggotakom_rumah_warga.class.getName());

    // DAO
    private final dao.RumahDao rumahDao = new dao.RumahDao();

    // Field selalu read-only. Pesan hanya muncul kalau editingExisting = true.
    private void guardReadOnly(javax.swing.JTextField tf, String reason) {
        tf.setEditable(false);
        tf.setFocusable(true); // boleh dapat fokus/klik tanpa pesan saat form kosong
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));
        tf.setCaretColor(new java.awt.Color(0, 0, 0, 0));   // sembunyikan caret biar terasa read-only
        tf.setBackground(new java.awt.Color(245, 245, 245));

        // cegah double-attach listener
        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        java.awt.event.MouseAdapter ma = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) { // <<< pesan hanya saat data lama sedang diedit
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_rumah_warga.this,
                            reason + " (tidak bisa diubah)."
                    );
                    e.consume();
                }
            }
        };
        java.awt.event.KeyAdapter ka = new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            } // tetap blokir ketik
        };

        tf.addMouseListener(ma);
        tf.addKeyListener(ka);
        tf.putClientProperty("ro-guard", Boolean.TRUE);
    }

    private boolean editingExisting = false;
    private java.awt.event.MouseListener idMouseGuard;
    private java.awt.event.KeyListener idKeyGuard;

    private void installIdGuard() {
        if (idMouseGuard != null) {
            return; // sudah terpasang
        }
        idMouseGuard = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_rumah_warga.this,
                            "ID Rumah tidak bisa diubah."
                    );
                    e.consume();
                }
            }
        };
        idKeyGuard = new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                if (editingExisting) {
                    e.consume();
                }
            }
        };

        jTextField1.addMouseListener(idMouseGuard); // jTextField1 = ID Rumah
        jTextField1.addKeyListener(idKeyGuard);
    }

    private void removeGuard(javax.swing.JTextField tf) {
        Object ma = tf.getClientProperty("ro-guard-mouse");
        if (ma instanceof java.awt.event.MouseListener ml) {
            tf.removeMouseListener(ml);
        }
        Object ka = tf.getClientProperty("ro-guard-key");
        if (ka instanceof java.awt.event.KeyListener kl) {
            tf.removeKeyListener(kl);
        }
        tf.putClientProperty("ro-guard", null);
        tf.putClientProperty("ro-guard-mouse", null);
        tf.putClientProperty("ro-guard-key", null);
    }

    // ===== UTIL TABLE / FORM =====
    private void refreshTable() {
        try {
            jTable1.setModel(rumahDao.loadTableByKomunitasPetugas(Model.Session.idUser));
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
            jTable1.clearSelection();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private int updateStatusKoneksiByPetugas(int idRumah, String status, String idUserPetugas)
            throws java.sql.SQLException {

        final String sql
                = "UPDATE rumah r "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "SET r.status_koneksi = ? "
                + "WHERE r.id_rumah = ? AND ak.id_user = ?";

        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, status);        // nilai: "AKTIF" / "GA AKTIF" / "PUTUS"
            ps.setInt(2, idRumah);          // id_rumah yang dipilih
            ps.setString(3, idUserPetugas); // biasanya Model.Session.idUser

            return ps.executeUpdate();      // >0 jika sukses
        }
    }

    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();

        jTextField1.setText(""); // id_rumah
        jTextField2.setText(""); // no_rumah
        jTextField3.setText(""); // nama_pemilik
        jTextField4.setText(""); // alamat_rumah
        jTextField5.setText(""); // no_telp
        jComboBox1.setSelectedItem("AKTIF"); // default
        jTextField7.setText(""); // tanggal_bergabung
    }

    private void fillFormFromRow(int r) {
        editingExisting = true;

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0))); // id_rumah
        jTextField2.setText(String.valueOf(jTable1.getValueAt(r, 1))); // no_rumah
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2))); // nama_pemilik
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3))); // alamat_rumah
        jTextField5.setText(String.valueOf(jTable1.getValueAt(r, 4))); // no_telp
        jComboBox1.setSelectedItem(String.valueOf(jTable1.getValueAt(r, 5))); // status
        Object tgl = jTable1.getValueAt(r, 6);
        jTextField7.setText(tgl == null ? "" : tgl.toString());        // tanggal_bergabung
    }

    public Menu_anggotakom_rumah_warga() {
        initComponents();

        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_ANGGOTA_KOMUNITAS_1.png");
        jLabel4.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));
        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel4, getContentPane().getComponentCount() - 1);

        guardReadOnly(jTextField1, "ID Rumah");
        guardReadOnly(jTextField2, "Nomor Rumah");
        guardReadOnly(jTextField3, "Nama Pemilik");
        guardReadOnly(jTextField4, "Alamat Rumah");
        guardReadOnly(jTextField5, "No. Telepon");
        guardReadOnly(jTextField7, "Tanggal Bergabung");

        jComboBox1.setModel(
                new javax.swing.DefaultComboBoxModel<>(
                        new String[]{"AKTIF", "GA AKTIF", "PUTUS"}
                )
        );

        // load + siapkan form saat window dibuka
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                refreshTable();
                clearFormForInsert();
            }
        });

        // klik tabel → isi form & aktifkan guard ID
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int r = jTable1.getSelectedRow();
                if (r >= 0) {
                    fillFormFromRow(r);
                }
            }
        });

        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Perbarui");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(130, 460, 100, 30);

        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(20, 460, 90, 30);

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setText("Muat Ulang");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(240, 460, 110, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id_Rumah", "No_Rumah", "Nama_Pemilik", "Alamat_Rumah", "No_Telepon", "Status_Koneksi", "Tanggal_Bergabung"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(360, 40, 400, 440);

        jLabel3.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel3.setText("RUMAH WARGA");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(80, 130, 200, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Rumah");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 170, 140, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("No Rumah");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 210, 140, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Nama Pemilik");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(20, 250, 140, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Alamat Rumah");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(20, 290, 140, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("No Telp");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(20, 330, 140, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Status Koneksi");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(20, 370, 140, 20);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Tanggal Bergabung");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(20, 410, 130, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(160, 170, 160, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(160, 210, 160, 30);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(160, 250, 160, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(160, 290, 160, 30);

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5);
        jTextField5.setBounds(160, 330, 160, 30);
        getContentPane().add(jTextField7);
        jTextField7.setBounds(160, 410, 160, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AKTIF", "GA AKTIF", "PUTUS" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(160, 370, 160, 30);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_ANGGOTA_KOMUNITAS_1.png")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Menu_anggota_komunitas anggotaKomunitas = new Menu_anggota_komunitas();
        anggotaKomunitas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            String sid = jTextField1.getText().trim();
            if (sid.isBlank()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih baris dari tabel terlebih dahulu.");
                return;
            }
            if (!sid.chars().allMatch(Character::isDigit)) {
                javax.swing.JOptionPane.showMessageDialog(this, "ID Rumah tidak boleh diubah.");
                return;
            }
            int idRumah = Integer.parseInt(sid);
            String status = String.valueOf(jComboBox1.getSelectedItem());

            int okc = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Ubah status koneksi menjadi \"" + status + "\" ?",
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (okc != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int changed = updateStatusKoneksiByPetugas(idRumah, status, Model.Session.idUser);
            if (changed > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Status koneksi diperbarui.");
                refreshTable();
            } else {
                javax.swing.JOptionPane.showMessageDialog(
                        this, "Gagal memperbarui. Data bukan dalam komunitas Anda.",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int kon = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "Batalkan perubahan dan muat ulang data?",
                "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);

        if (kon != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        refreshTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");

    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_anggotakom_rumah_warga().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
