package View;

import javax.swing.text.AbstractDocument;
import javax.swing.text.DocumentFilter;

public class Menu_superadmin_warga extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_warga.class.getName());
    private final dao.WargaDao wargaDao = new dao.WargaDao();

    // ====== STATE ======
    private boolean editingExisting = false;
    private String selectedIdUser = null;

    // === Hard read-only utk TextField (pasang sekali saja) ===
    private void makeIdHardReadonly(javax.swing.JTextField tf) {
        tf.setEditable(false);
        tf.setFocusable(true);
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));

        // ---- GUARD: kalau sudah pernah dipasang, jangan dipasang lagi ----
        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });

        tf.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                String msg = editingExisting
                        ? "ID User tidak boleh diubah saat memperbarui data."
                        : "ID User dibuat otomatis. Biarkan '(AUTO)'.";
                javax.swing.JOptionPane.showMessageDialog(Menu_superadmin_warga.this, msg);
                e.consume();
            }
        });

        // tandai sudah dipasang
        tf.putClientProperty("ro-guard", Boolean.TRUE);
    }

// semula: makeJoinDateAutoReadonly
    private void makeJoinDateReadOnly(javax.swing.JTextField tf) {
        tf.setEditable(false);
        tf.setFocusable(true);
        if (Boolean.TRUE.equals(tf.getClientProperty("join-guard"))) {
            return;
        }

        tf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(java.awt.event.KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
        tf.putClientProperty("join-guard", Boolean.TRUE);
    }


    // ====== HELPERS ======
    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Data tidak sesuai:\n• " + String.join("\n• ", errs),
                "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
    }

    private static java.sql.Date toSqlDate(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        return java.sql.Date.valueOf(s.trim()); // wajib yyyy-MM-dd
    }

    private java.util.List<String> validateCommon() {
        var errs = new java.util.ArrayList<String>();

        // batasan sesuai schema USER/WARGA
        if (!id.getText().isBlank() && id.getText().trim().length() > 6) {
            errs.add("ID User maksimal 6 karakter.");
        }
        if (!nama.getText().isBlank() && nama.getText().trim().length() > 50) {
            errs.add("Nama maksimal 50 karakter.");
        }
        if (!alamat.getText().isBlank() && alamat.getText().trim().length() > 100) {
            errs.add("Alamat maksimal 100 karakter.");
        }
        if (!notelp.getText().isBlank() && notelp.getText().trim().length() > 20) {
            errs.add("No. Telp maksimal 12 karakter.");
        }
        if (!email.getText().isBlank() && email.getText().trim().length() > 50) {
            errs.add("Email maksimal 50 karakter.");
        }
        if (!username.getText().isBlank() && username.getText().trim().length() > 20) {
            errs.add("Username maksimal 20 karakter.");
        }
        if (!password.getText().isBlank() && password.getText().trim().length() > 7) {
            errs.add("Password maksimal 7 karakter.");
        }
        // --- NIK ---
        String nikText = nik.getText().trim();
        if (!nikText.isBlank() && !nikText.matches("\\d{16}")) {
            errs.add("NIK harus 16 digit angka.");
        }
        
        // --- No.KK ---
        String kkText = nokk.getText().trim();
        if (!kkText.isBlank() && !kkText.matches("\\d{16}")) {
            errs.add("No.KK harus 16 digit angka.");
        }

        if (!tglbergabung.getText().isBlank()
                && !"(AUTO)".equalsIgnoreCase(tglbergabung.getText().trim())) {
            try {
                java.sql.Date.valueOf(tglbergabung.getText().trim());
            } catch (IllegalArgumentException e) {
                errs.add("Format tanggal bergabung harus yyyy-MM-dd.");
            }
        }
        return errs;
    }

    private java.util.List<String> validateForInsert() {
        var errs = validateCommon();

        if (id.getText().isBlank()) {
            errs.add("ID User wajib diisi (atau isi '(AUTO)' untuk otomatis).");
        }
        if (nama.getText().isBlank()) {
            errs.add("Nama wajib.");
        }
        if (alamat.getText().isBlank()) {
            errs.add("Alamat wajib.");
        }
        if (nokk.getText().isBlank()) {
            errs.add("No.KK wajib.");
        }
        if (notelp.getText().isBlank()) {
            errs.add("No. Telp wajib.");
        }
        if (email.getText().isBlank()) {
            errs.add("Email wajib.");
        }

        if (nik.getText().isBlank()) {
            errs.add("NIK wajib.");
        }
        if (username.getText().isBlank()) {
            errs.add("Username wajib.");
        }
        if (password.getText().isBlank()) {
            errs.add("Password wajib.");
        }

        return errs;
    }

    private java.util.List<String> validateForUpdate() {
        var errs = validateCommon();
        if (selectedIdUser == null) {
            errs.add("Pilih baris pada tabel terlebih dahulu.");
        } else if (!selectedIdUser.equals(id.getText().trim())) {
            errs.add("ID User tidak boleh diubah saat memperbarui.");
        }
        return errs;
    }

    private void reloadTable() {
        try {
            jTable1.setModel(wargaDao.loadTableModelForAdmin());
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
            jTable1.clearSelection();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    private void clearFormForInsert() {
        editingExisting = false;
        selectedIdUser = null;
        jTable1.clearSelection();

        id.setText("(AUTO)");
        makeIdHardReadonly(id);

        nama.setText("");
        nik.setText("");
        nokk.setText("");
        alamat.setText("");
        notelp.setText("");
        email.setText("");
        username.setText("");
        password.setText("");

        // Tgl bergabung: tampilkan "(AUTO)" + tooltip khusus tambah
        tglbergabung.setText("(AUTO)");
        makeJoinDateReadOnly(tglbergabung); // pasang guard read-only (sekali saja)
        tglbergabung.setToolTipText("Diisi otomatis dengan tanggal hari ini saat tambah data.");
        tglbergabung.setBackground(new java.awt.Color(255, 255, 200)); // kuning lembut
    }



    private void fillFieldsFromTable() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        editingExisting = true;
        selectedIdUser = String.valueOf(jTable1.getValueAt(r, 0));

        id.setText(String.valueOf(jTable1.getValueAt(r, 0)));
        nama.setText(String.valueOf(jTable1.getValueAt(r, 1)));
        nik.setText(String.valueOf(jTable1.getValueAt(r, 2)));
        nokk.setText(String.valueOf(jTable1.getValueAt(r, 3)));
        alamat.setText(String.valueOf(jTable1.getValueAt(r, 4)));
        notelp.setText(String.valueOf(jTable1.getValueAt(r, 5)));
        email.setText(String.valueOf(jTable1.getValueAt(r, 6)));
        username.setText(String.valueOf(jTable1.getValueAt(r, 8)));
        password.setText(String.valueOf(jTable1.getValueAt(r, 9)));

        Object tgl = jTable1.getValueAt(r, 7);
        tglbergabung.setText(tgl == null ? "" : tgl.toString());

        makeIdHardReadonly(id);
        makeJoinDateReadOnly(tglbergabung); // read-only sudah ada, ini aman

        // Tooltip & warna khusus edit
        tglbergabung.setToolTipText("Tanggal bergabung tidak bisa diedit");
        tglbergabung.setBackground(javax.swing.UIManager.getColor("TextField.background"));
    }


    public Menu_superadmin_warga() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                reloadTable();
                jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
                clearFormForInsert();
            }
        });

        // Klik tabel → isi field
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                fillFieldsFromTable();
            }
        });

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        nama = new javax.swing.JTextField();
        nik = new javax.swing.JTextField();
        nokk = new javax.swing.JTextField();
        alamat = new javax.swing.JTextField();
        notelp = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        tglbergabung = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        password = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("Warga");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(530, 10, 80, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("ID User");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(40, 120, 50, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("NIK");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(40, 180, 60, 20);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(50, 430, 90, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(160, 430, 100, 23);

        jButton4.setText("Kembali");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(50, 460, 90, 23);

        jButton5.setText("Muat Ulang");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(160, 460, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID User", "Nama", "NIK", "No. KK", "Alamat", "No. Telp", "Email", "Tgl Bergabung", "Username", "Password"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 41, 452, 440);

        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });
        getContentPane().add(nama);
        nama.setBounds(150, 150, 150, 30);

        nik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nikActionPerformed(evt);
            }
        });
        getContentPane().add(nik);
        nik.setBounds(150, 180, 150, 30);

        nokk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nokkActionPerformed(evt);
            }
        });
        getContentPane().add(nokk);
        nokk.setBounds(150, 210, 150, 30);

        alamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                alamatActionPerformed(evt);
            }
        });
        getContentPane().add(alamat);
        alamat.setBounds(150, 240, 150, 30);

        notelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                notelpActionPerformed(evt);
            }
        });
        getContentPane().add(notelp);
        notelp.setBounds(150, 270, 150, 30);

        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email);
        email.setBounds(150, 300, 150, 30);

        tglbergabung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tglbergabungActionPerformed(evt);
            }
        });
        getContentPane().add(tglbergabung);
        tglbergabung.setBounds(150, 330, 150, 30);

        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });
        getContentPane().add(username);
        username.setBounds(150, 360, 150, 30);

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        getContentPane().add(password);
        password.setBounds(150, 390, 150, 30);

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(150, 120, 150, 30);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("No. KK");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(40, 210, 60, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Alamat");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 240, 60, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("No. Telp");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(40, 270, 70, 20);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Email");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(40, 300, 60, 20);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setText("Tgl Bergabung");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(40, 330, 100, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setText("Username");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(40, 360, 70, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setText("Password");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(40, 390, 70, 20);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel15.setText("Nama");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(40, 150, 60, 20);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        var errs = validateForUpdate();
        if (!errs.isEmpty()) {
            showErrors(errs);
            return;
        }

        try {
            String idUser = id.getText().trim();      // sama dengan selectedIdUser
            String nm = nama.getText().trim();
            String nNik = nik.getText().trim();
            String nKk = nokk.getText().trim();
            String almt = alamat.getText().trim();
            String telp = notelp.getText().trim();
            String mail = email.getText().trim();
            java.sql.Date tgl = toSqlDate(tglbergabung.getText());
            String usr = username.getText().trim();
            String pass = password.getText();       // boleh kosong = tidak ganti

            int okConf = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Perbarui user: " + idUser + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION);
            if (okConf != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int changed = wargaDao.updateWarga(
                    idUser, nm, almt, telp, mail,
                    usr, pass,
                    nNik, nKk, tgl
            );
            javax.swing.JOptionPane.showMessageDialog(this,
                    changed > 0 ? "Perbarui OK" : "Tidak ada yang diubah");
            reloadTable();
            clearFormForInsert();

        } catch (java.sql.SQLIntegrityConstraintViolationException dup) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "NIK/No.KK bentrok dengan data lain. Cek kembali inputmu.");
        } catch (IllegalArgumentException iae) {
            javax.swing.JOptionPane.showMessageDialog(this, "Format tanggal harus yyyy-MM-dd");
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void nikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nikActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nikActionPerformed

    private void nokkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nokkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nokkActionPerformed

    private void alamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_alamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_alamatActionPerformed

    private void notelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_notelpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_notelpActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void tglbergabungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tglbergabungActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tglbergabungActionPerformed

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        var errs = validateForInsert();
        if (!errs.isEmpty()) {
            showErrors(errs);
            return;
        }

        try {
            // AUTO id
            String idUser = id.getText().trim();
            if ("(AUTO)".equalsIgnoreCase(idUser)) {
                idUser = wargaDao.nextIdUser();
            }

            String nm = nama.getText().trim();
            String nNik = nik.getText().trim();
            String nKk = nokk.getText().trim();
            String almt = alamat.getText().trim();
            String telp = notelp.getText().trim();
            String mail = email.getText().trim();
            java.sql.Date tgl = java.sql.Date.valueOf(java.time.LocalDate.now());
            String usr = username.getText().trim();
            String pass = password.getText().trim();

            int ok = wargaDao.insertWarga(
                    idUser, nm, almt, telp, mail,
                    usr, pass,
                    nNik, nKk, tgl,
                    "WARGA"
            );
            javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah");
            reloadTable();
            clearFormForInsert();

        } catch (java.sql.SQLIntegrityConstraintViolationException dup) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "ID/NIK/No.KK bentrok (sudah ada). Cek kembali inputmu.");
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int yn = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan & muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        reloadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_warga().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alamat;
    private javax.swing.JTextField email;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nik;
    private javax.swing.JTextField nokk;
    private javax.swing.JTextField notelp;
    private javax.swing.JTextField password;
    private javax.swing.JTextField tglbergabung;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
