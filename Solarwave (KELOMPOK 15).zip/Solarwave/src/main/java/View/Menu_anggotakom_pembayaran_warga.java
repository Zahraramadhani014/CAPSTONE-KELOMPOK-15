package View;

public class Menu_anggotakom_pembayaran_warga extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_anggotakom_pembayaran_warga.class.getName());

    private final dao.PembayaranDao pembayaranDao = new dao.PembayaranDao();

    // --- Mode edit: true kalau form sedang menampilkan data lama dari tabel
    private boolean editingExisting = false;

    // Guard read-only: bedakan pesan untuk tambah vs perbarui
    private void guardReadOnly(javax.swing.JTextField tf, String label, boolean isIdField) {
        tf.setEditable(false);
        tf.setFocusable(true);
        tf.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));
        tf.setCaretColor(new java.awt.Color(0, 0, 0, 0));
        tf.setBackground(new java.awt.Color(245, 245, 245));

        if (Boolean.TRUE.equals(tf.getClientProperty("ro-guard"))) {
            return;
        }

        java.awt.event.MouseAdapter ma = new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                // ID: selalu beri pesan, tapi isinya beda tergantung mode
                if (isIdField) {
                    String msg = editingExisting
                            ? (label + " tidak bisa diubah.")
                            : (label + " dibuat otomatis.");
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_pembayaran_warga.this, msg);
                    e.consume();
                    return;
                }
                // Bukan ID: hanya beri pesan saat mode edit (perbarui)
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_anggotakom_pembayaran_warga.this,
                            label + " terisi otomatis dan tidak dapat diubah di sini.");
                    e.consume();
                }
            }
        };
        java.awt.event.KeyAdapter ka = new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        };
        tf.addMouseListener(ma);
        tf.addKeyListener(ka);
        tf.putClientProperty("ro-guard", Boolean.TRUE);

        // Tooltip kecil biar informatif tanpa pop-up
        String tip = isIdField
                ? "Klik: info ID (otomatis/terkunci)."
                : "Nilai ini terisi otomatis.";
        tf.setToolTipText(tip);
    }

    // ================== TAMBAH (CASH) ==================
    /**
     * Insert pembayaran CASH oleh petugas untuk warga dalam komunitasnya. Akan
     * menambahkan baris RIWAYAT ke tabel 'pembayaran' sehingga otomatis terbaca
     * di menu Riwayat Pembayaran milik warga.
     *
     * Guard komunitas: hanya sukses jika nik berada di komunitas petugas
     * (Model.Session.idUser).
     */
    // return: id_pembayaran baru (0 kalau gagal/tidak berhak)
    // return: id_pembayaran baru (0 kalau gagal)
    private int insertCashPaymentByPetugas(
            String nikWarga, int idTagihan, java.math.BigDecimal jumlahBayar,
            String status, String idUserPetugas
    ) throws java.sql.SQLException {

        final String SQL_INSERT
                = "INSERT INTO pembayaran "
                + " (id_pembayaran, tanggal_pembayaran, metode_pembayaran, jumlah_bayar, status_pembayaran, WARGA_nik, TAGIHAN_BULANAN_id_tagihan) "
                + "SELECT ?, CURRENT_TIMESTAMP, 'CASH', ?, ?, w.nik, t.id_tagihan "
                + // << ganti CURRENT_DATE -> CURRENT_TIMESTAMP (atau NOW())
                "FROM warga w "
                + "JOIN rumah r ON r.USER_id_user = w.id_user "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "JOIN tagihan_bulanan t ON t.id_tagihan = ? "
                + "WHERE w.nik = ? AND ak.id_user = ?";

        // Catatan: gunakan engine InnoDB agar transaksi/lock bekerja
        try (java.sql.Connection c = dao.DB.getConnection()) {
            c.setAutoCommit(false);

            // --- Kunci baris terakhir supaya tidak bentrok saat hitung nextId ---
            int nextId;
            try (java.sql.PreparedStatement psLast
                    = c.prepareStatement("SELECT id_pembayaran FROM pembayaran ORDER BY id_pembayaran DESC LIMIT 1 FOR UPDATE"); java.sql.ResultSet rs = psLast.executeQuery()) {
                nextId = rs.next() ? (rs.getInt(1) + 1) : 1;
            }

            // --- Insert pakai id yang kita buat sendiri ---
            try (java.sql.PreparedStatement ps = c.prepareStatement(SQL_INSERT)) {
                int i = 1;
                ps.setInt(i++, nextId);
                ps.setBigDecimal(i++, jumlahBayar);
                ps.setString(i++, status);
                ps.setInt(i++, idTagihan);
                ps.setString(i++, nikWarga);
                ps.setString(i++, idUserPetugas);

                int n = ps.executeUpdate();
                if (n <= 0) {
                    c.rollback();
                    return 0;
                }
            }

            c.commit();
            return nextId;
        }
    }

    /**
     * (Opsional) Tandai tagihan menjadi LUNAS jika petugas berhak. Abaikan
     * kalau kolom status tagihan di skema kamu berbeda.
     */
    private int markTagihanLunasIfAllowed(int idTagihan, String nikWarga, String idUserPetugas)
            throws java.sql.SQLException {
        final String sql
                = "UPDATE tagihan_bulanan t "
                + "JOIN warga w ON w.nik = ? "
                + "JOIN rumah r ON r.USER_id_user = w.id_user "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "SET t.status_tagihan = 'LUNAS' "
                + "WHERE t.id_tagihan = ? AND ak.id_user = ?";

        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nikWarga);
            ps.setInt(2, idTagihan);
            ps.setString(3, idUserPetugas);
            return ps.executeUpdate();
        } catch (java.sql.SQLException ex) {
            // Kalau struktur tabelnya beda, kita biarkan tanpa gagal total.
            return 0;
        }
    }

    /**
     * Ambil nominal tagihan (mis. jumlah_tagihan) jika NIK & tagihan itu berada
     * di komunitas petugas yang login. Return NULL kalau tidak berhak / tidak
     * ada.
     */
    private java.math.BigDecimal findNominalTagihanIfAllowed(
            String nikWarga, int idTagihan, String idUserPetugas
    ) throws java.sql.SQLException {

        final String sql
                = "SELECT t.total_tagihan "
                + // << ganti di sini
                "FROM tagihan_bulanan t "
                + "JOIN warga w ON w.nik = ? "
                + "JOIN rumah r ON r.USER_id_user = w.id_user "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "WHERE t.id_tagihan = ? AND ak.id_user = ?";

        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nikWarga);
            ps.setInt(2, idTagihan);
            ps.setString(3, idUserPetugas);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    java.math.BigDecimal amt = rs.getBigDecimal(1);
                    return (amt == null ? null : amt.stripTrailingZeros());
                }
                return null;
            }
        }
    }

    private int updateStatusOnlyByPetugas(int idPembayaran, String status, String idUserPetugas)
            throws java.sql.SQLException {

        final String sql
                = "UPDATE pembayaran p "
                + "JOIN tagihan_bulanan t ON t.id_tagihan = p.TAGIHAN_BULANAN_id_tagihan "
                + "JOIN warga w ON w.nik = p.WARGA_nik "
                + "JOIN rumah r ON r.USER_id_user = w.id_user "
                + "JOIN anggota_komunitas ak ON ak.KOMUNITAS_id_komunitas = r.KOMUNITAS_id_komunitas "
                + "SET p.status_pembayaran=? "
                + "WHERE p.id_pembayaran=? AND ak.id_user=?";

        try (java.sql.Connection c = dao.DB.getConnection(); java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, idPembayaran);
            ps.setString(3, idUserPetugas);
            return ps.executeUpdate();
        }
    }

    /**
     * Creates new form Menu_anggotakom_warga
     */
    public Menu_anggotakom_pembayaran_warga() {
        initComponents();

        setSize(820, 540);
        setLocationRelativeTo(null);
        setResizable(false);

        var url = getClass().getResource("/View/assets/HALAMAN_ANGGOTA_KOMUNITAS_1.png");
        jLabel11.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling belakang
        getContentPane().setComponentZOrder(jLabel11, getContentPane().getComponentCount() - 1);

        // KUNCI FIELD
        guardReadOnly(jTextField1, "ID Pembayaran", true);   // ← ini field ID: selalu warning
        guardReadOnly(jTextField2, "Tanggal Pembayaran", false);
        guardReadOnly(jTextField3, "Metode Pembayaran", false);
        guardReadOnly(jTextField4, "Jumlah Bayar", false);

        // (opsional) set pilihan default status
        if (jComboBox1.getItemCount() == 0) {
            jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(
                    new String[]{"LUNAS", "BELUM LUNAS"} // atur sesuai kebutuhanmu
            ));
        }

        // tampilkan (AUTO) saat form dibuka pertama kali
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                refreshTable();
                clearFormForInsert();
            }
        });

        // Klik baris tabel → isi form & aktifkan mode edit
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int r = jTable1.getSelectedRow();
                if (r >= 0) {
                    fillFormFromRow(r);
                }
            }
        });

        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
    }

    private void refreshTable() {
        try {
            jTable1.setModel(pembayaranDao.tableModelByKomunitasPetugas(Model.Session.idUser));
            jTable1.clearSelection();
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Gagal load: " + ex.getMessage());
        }
    }

    // Saat klik baris tabel → isi form
    private void fillFormFromRow(int r) {
        editingExisting = true; // sekarang mode edit data lama
        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0))); // id_pembayaran
        Object ts = jTable1.getValueAt(r, 1);                          // tanggal
        jTextField2.setText(ts == null ? "" : ts.toString());
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2))); // metode
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3))); // jumlah
        jComboBox1.setSelectedItem(String.valueOf(jTable1.getValueAt(r, 4))); // status
    }

    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();

        jTextField1.setText("(AUTO)");  // ← tampilkan AUTO
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        if (jComboBox1.getItemCount() > 0) {
            jComboBox1.setSelectedIndex(0);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Perbarui");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(140, 410, 100, 30);

        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(10, 460, 110, 30);

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setText("Muat Ulang");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(260, 410, 110, 30);

        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setText("Tambah");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(20, 410, 100, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id_Pembayaran", "Tanggal_Pembayaran", "Metode_Pembayaran", "Jumlah_Bayar", "Status_Pembayaran"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(380, 20, 390, 460);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Pembayaran");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(30, 210, 160, 20);

        jLabel3.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel3.setText("PEMBAYARAN LISTRIK");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(50, 130, 280, 30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Tanggal Pembayaran");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(30, 250, 160, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Metode Pembayaran");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(30, 290, 160, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Jumlah Bayar");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(30, 330, 160, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Status Pembayaran");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(30, 370, 160, 20);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(190, 200, 170, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(190, 240, 170, 30);
        getContentPane().add(jTextField3);
        jTextField3.setBounds(190, 280, 170, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(190, 320, 170, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LUNAS", "BELUM LUNAS" }));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(190, 360, 170, 30);

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_ANGGOTA_KOMUNITAS_1.png")); // NOI18N
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Menu_anggota_komunitas anggotaKomunitas = new Menu_anggota_komunitas();
        anggotaKomunitas.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if (!editingExisting || jTextField1.getText().trim().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Pilih data dari tabel terlebih dahulu.");
                return;
            }
            int id = Integer.parseInt(jTextField1.getText().trim());
            String status = String.valueOf(jComboBox1.getSelectedItem());

            int okc = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Ubah status pembayaran menjadi \"" + status + "\" ?",
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION
            );
            if (okc != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            int changed = updateStatusOnlyByPetugas(id, status, Model.Session.idUser);
            if (changed > 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "Status pembayaran diperbarui.");
                refreshTable();
            } else {
                javax.swing.JOptionPane.showMessageDialog(this,
                        "Gagal memperbarui (data tidak ditemukan / bukan komunitasmu).",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int kon = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan dan muat ulang data?",
                "Muat Ulang", javax.swing.JOptionPane.YES_NO_OPTION
        );
        if (kon != javax.swing.JOptionPane.YES_OPTION) {
            return;
        }

        refreshTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            String nik = javax.swing.JOptionPane.showInputDialog(
                    this, "Masukkan NIK warga:", "Tambah (Cash)", javax.swing.JOptionPane.QUESTION_MESSAGE);
            if (nik == null || nik.trim().isEmpty()) {
                return;
            }
            nik = nik.trim();

            String sIdTag = javax.swing.JOptionPane.showInputDialog(
                    this, "Masukkan ID Tagihan Bulanan:", "Tambah (Cash)", javax.swing.JOptionPane.QUESTION_MESSAGE);
            if (sIdTag == null || sIdTag.trim().isEmpty()) {
                return;
            }
            int idTagihan = Integer.parseInt(sIdTag.trim());

            java.math.BigDecimal jumlah = findNominalTagihanIfAllowed(nik, idTagihan, Model.Session.idUser);
            if (jumlah == null) {
                String sJumlah = javax.swing.JOptionPane.showInputDialog(
                        this, "Nominal tagihan tidak ditemukan atau tidak berhak.\nMasukkan Jumlah Bayar (angka):",
                        "Tambah (Cash)", javax.swing.JOptionPane.WARNING_MESSAGE);
                if (sJumlah == null || sJumlah.trim().isEmpty()) {
                    return;
                }
                try {
                    jumlah = new java.math.BigDecimal(sJumlah.trim());
                    if (jumlah.signum() <= 0) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException nfe) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Jumlah bayar harus angka positif.");
                    return;
                }
            }

            String status = String.valueOf(jComboBox1.getSelectedItem());

            int okc = javax.swing.JOptionPane.showConfirmDialog(
                    this,
                    "Simpan pembayaran CASH?\n"
                    + "- NIK         : " + nik + "\n"
                    + "- ID Tagihan  : " + idTagihan + "\n"
                    + "- Jumlah      : " + jumlah + "\n"
                    + "- Status      : " + status,
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (okc != javax.swing.JOptionPane.YES_OPTION) {
                return;
            }

            // INSERT & dapatkan ID baru
            int newId = insertCashPaymentByPetugas(nik, idTagihan, jumlah, status, Model.Session.idUser);
            if (newId > 0) {
                if ("LUNAS".equalsIgnoreCase(status)) {
                    markTagihanLunasIfAllowed(idTagihan, nik, Model.Session.idUser);
                }
                // tampilkan ID hasil auto di form
                jTextField1.setText(String.valueOf(newId));
                javax.swing.JOptionPane.showMessageDialog(this, "Pembayaran CASH disimpan. ID: " + newId);
                refreshTable();
                clearFormForInsert(); // kembali ke (AUTO)
            } else {
                javax.swing.JOptionPane.showMessageDialog(
                        this,
                        "Gagal menambah pembayaran.\nPastikan NIK & ID Tagihan valid dan warga berada di komunitas Anda.",
                        "Gagal", javax.swing.JOptionPane.WARNING_MESSAGE
                );
            }
        } catch (NumberFormatException nfe) {
            javax.swing.JOptionPane.showMessageDialog(this, "ID Tagihan harus angka.");
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err: " + ex.getMessage());
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_anggotakom_pembayaran_warga().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
