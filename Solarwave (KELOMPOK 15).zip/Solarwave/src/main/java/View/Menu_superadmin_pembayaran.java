package View;

public class Menu_superadmin_pembayaran extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Menu_superadmin_pembayaran.class.getName());
    private final dao.PembayaranDao pembayaranDao = new dao.PembayaranDao();

    // ====== STATE ======
    private boolean editingExisting = false;
    private boolean idGuardAttached = false;
    private boolean busyAdd = false, busyUpdate = false, busyDelete = false;

    public Menu_superadmin_pembayaran() {
        initComponents();
        setSize(820, 540);
        setLocationRelativeTo(null); // center window
        setResizable(false);
        
        // di constructor setelah initComponents()
        jTextField4.setEditable(false);
        jTextField4.setFocusable(false);


        var url = getClass().getResource("/View/assets/HALAMAN_SUPER_ADMIN_1.png");
        jLabel8.setIcon(new javax.swing.ImageIcon(
                java.util.Objects.requireNonNull(url, "Gambar tidak ditemukan di classpath")
        ));

        // kirim background ke paling beSlakang
        getContentPane().setComponentZOrder(jLabel8, getContentPane().getComponentCount() - 1);

        // opsi status
        if (jComboBox1.getItemCount() == 0) {
            jComboBox1.addItem("LUNAS");
            jComboBox1.addItem("BELUM LUNAS");
        }

        // load awal & set mode tambah
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent e) {
                reloadTable();
                clearFormForInsert();
            }
        });

        // klik tabel → isi field
        jTable1.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFieldsFromRow();
            }
        });

        // guard ID (boleh fokus, tapi saat sedang edit akan muncul pesan)
        attachIdGuard();
    }
    
    // Isi jTextField4 (Jumlah Bayar) dari tagihan jika masih kosong.
// Mengembalikan ID Tagihan yang dipilih, atau null bila dibatalkan/err.
    private Integer prefillJumlahFromTagihanIfEmpty() {
        Integer idTagihan = askIdTagihan();     // popup minta ID
        if (idTagihan == null) {
            return null;
        }
        if (jTextField4.getText().trim().isEmpty()) {
            try {
                // PILIH SALAH SATU:
                var nominal = pembayaranDao.getTotalTagihan(idTagihan); // full bayar
//            var nominal = pembayaranDao.getSisaTagihan(idTagihan);     // sisa (rekomendasi)

                jTextField4.setText(nominal.toPlainString()); // << tampil di FIELD
            } catch (Exception ex) {
                showSqlError(ex, "Ambil jumlah dari tagihan");
                return null;
            }
        }
        return idTagihan;
    }


    // ====== HELPERS ======
    private void reloadTable() {
        try {
            jTable1.setModel(pembayaranDao.loadTableForAdmin());
            jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        } catch (Exception ex) {
            javax.swing.JOptionPane.showMessageDialog(this, "Err reload: " + ex.getMessage());
        }
    }

    private void clearFormForInsert() {
        editingExisting = false;
        jTable1.clearSelection();

        // ID otomatis → tampilkan (AUTO) supaya user paham
        jTextField1.setText("(AUTO)");
        jTextField2.setText("");     // tgl (yyyy-MM-dd HH:mm:ss)
        jTextField3.setText("");     // metode
        jTextField4.setText("");     // jumlah
        if (jComboBox1.getItemCount() > 0) {
            jComboBox1.setSelectedIndex(1); // default BELUM LUNAS
        }
    }

    private void fillFieldsFromRow() {
        int r = jTable1.getSelectedRow();
        if (r < 0) {
            return;
        }

        editingExisting = true;

        jTextField1.setText(String.valueOf(jTable1.getValueAt(r, 0))); // id_pembayaran
        Object ts = jTable1.getValueAt(r, 1); // kolom tanggal_pembayaran
        String s = (ts == null) ? "" : String.valueOf(ts);
        s = s.replace('T', ' ').replaceFirst("\\.\\d+$", ""); // buang .0 / .xxx
        jTextField2.setText(s);
                        // tanggal_pembayaran
        jTextField2.setText(ts == null ? "" : ts.toString());
        jTextField3.setText(String.valueOf(jTable1.getValueAt(r, 2))); // metode
        jTextField4.setText(String.valueOf(jTable1.getValueAt(r, 3))); // jumlah
        Object st = jTable1.getValueAt(r, 4);
        if (st != null) {
            jComboBox1.setSelectedItem(st.toString());
        }
    }

    private void attachIdGuard() {
        if (idGuardAttached) {
            return;
        }
        idGuardAttached = true;

        jTextField1.setEditable(false);
        jTextField1.setFocusable(true);
        jTextField1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.TEXT_CURSOR));

        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (editingExisting) {
                    javax.swing.JOptionPane.showMessageDialog(
                            Menu_superadmin_pembayaran.this,
                            "ID Pembayaran tidak boleh diubah."
                    );
                    e.consume();
                }
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {
                e.consume();
            }
        });
    }

    // ==================== VALIDASI & PARSER ====================
    private static final java.util.regex.Pattern P_DATETIME =
    java.util.regex.Pattern.compile(
        "^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])\\s([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d(?:\\.\\d{1,6})?$"
    );
    private static final java.util.regex.Pattern P_METODE
            = java.util.regex.Pattern.compile("^.{3,50}$"); // 3..50
    private static final java.util.regex.Pattern P_DEC_12_2
            = java.util.regex.Pattern.compile("^\\d{1,12}(?:\\.\\d{1,2})?$"); // DECIMAL(12,2)
    private static final java.util.Set<String> STATUS_OK
            = new java.util.HashSet<>(java.util.Arrays.asList("LUNAS", "BELUM LUNAS"));

    private String normNum(String s) {
        return (s == null) ? "" : s.trim().replace(',', '.');
    }

    private java.sql.Timestamp parseTimestamp(String s) {
        String v = (s == null) ? "" : s.trim().replace('T', ' ');

        // Jika user tulis tanpa detik → tambahkan :00
        if (v.matches("^\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}$")) {
            v += ":00";
        }

        if (!P_DATETIME.matcher(v).matches()) {
            throw new IllegalArgumentException("Tgl. Pembayaran harus format yyyy-MM-dd HH:mm:ss");
        }

        // Potong fraksi detik >6 agar aman untuk Timestamp
        v = v.replaceFirst("(\\.\\d{1,6})\\d+$", "$1");
        return java.sql.Timestamp.valueOf(v);   // ini menerima .f (opsional)
    }

    private java.math.BigDecimal parseMoney(String s) {
        String v = normNum(s);
        if (!P_DEC_12_2.matcher(v).matches()) {
            throw new IllegalArgumentException("Jumlah Bayar harus angka (maks 12 digit, 2 desimal).");
        }
        java.math.BigDecimal bd = new java.math.BigDecimal(v);
        if (bd.signum() <= 0) {
            throw new IllegalArgumentException("Jumlah Bayar harus > 0.");
        }
        return bd.setScale(2, java.math.RoundingMode.HALF_UP);
    }

    private java.util.List<String> validateForInsert() {
        var errs = new java.util.ArrayList<String>();
        if (!"(AUTO)".equalsIgnoreCase(jTextField1.getText().trim())) {
            errs.add("ID Pembayaran diisi otomatis. Biarkan '(AUTO)'.");
        }
        try {
            parseTimestamp(jTextField2.getText());
        } catch (IllegalArgumentException e) {
            errs.add(e.getMessage());
        }
        if (!P_METODE.matcher(jTextField3.getText().trim()).matches()) {
            errs.add("Metode Pembayaran minimal 3 karakter dan maksimal 50.");
        }
        try {
            String s = jTextField4.getText().trim();
            if (!s.isBlank()) {
                parseMoney(s);
            }
        } catch (IllegalArgumentException e) {
            errs.add(e.getMessage());
        }


        String st = String.valueOf(jComboBox1.getSelectedItem());
        if (!STATUS_OK.contains(st)) {
            errs.add("Status harus LUNAS / BELUM LUNAS.");
        }
        return errs;
    }

    private java.util.List<String> validateForUpdate() {
        var errs = new java.util.ArrayList<String>();
        try {
            Integer.parseInt(jTextField1.getText().trim());
        } catch (Exception e) {
            errs.add("Pilih data dari tabel dulu.");
        }
        errs.addAll(validateForInsert()); // sama dengan insert (kecuali ID)
        // hapus pesan auto-id duplikat saat update
        errs.removeIf(s -> s.startsWith("ID Pembayaran diisi otomatis"));
        return errs;
    }

    private void showErrors(java.util.List<String> errs) {
        javax.swing.JOptionPane.showMessageDialog(
                this, "Periksa data berikut:\n- " + String.join("\n- ", errs),
                "Validasi gagal", javax.swing.JOptionPane.WARNING_MESSAGE
        );
    }

    // ====== Prompt FK ======
    private Integer askIdTagihan() {
        String s = javax.swing.JOptionPane.showInputDialog(this, "Masukkan TAGIHAN_BULANAN.id_tagihan:", "ID Tagihan", javax.swing.JOptionPane.QUESTION_MESSAGE);
        if (s == null) {
            return null;
        }
        s = s.trim();
        if (s.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "ID Tagihan wajib diisi.");
            return null;
        }
        try {
            int v = Integer.parseInt(s);
            if (v <= 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "ID Tagihan harus > 0.");
                return null;
            }
            return v;
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "ID Tagihan harus angka.");
            return null;
        }
    }

    /**
     * WARGA_nik boleh NULL (sesuai skema). Jika diisi, wajib 16 karakter.
     */
    private String askNikOptional() {
        String s = javax.swing.JOptionPane.showInputDialog(this, "Masukkan WARGA.nik (opsional, 16 karakter):", "NIK (opsional)", javax.swing.JOptionPane.QUESTION_MESSAGE);
        if (s == null) {
            return null;           // batal
        }
        s = s.trim();
        if (s.isEmpty()) {
            return "";           // interpretasikan sebagai NULL di DAO (jika mendukung)
        }
        if (s.length() != 16) {
            javax.swing.JOptionPane.showMessageDialog(this, "NIK harus 16 karakter.");
            return null;
        }
        return s;
    }

    // ====== SQL error mapping ======
    private void showSqlError(Exception ex, String ctx) {
        if (ex instanceof java.sql.SQLIntegrityConstraintViolationException) {
            // bisa karena UNIQUE (TAGIHAN_BULANAN_id_tagihan) atau FK (id_tagihan/nik)
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: pelanggaran relasi/unik. "
                    + "Pastikan ID Tagihan ada, NIK valid (16), dan belum ada pembayaran untuk ID Tagihan ini.");
            return;
        }
        if (ex instanceof java.sql.SQLDataException) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    ctx + " gagal: format/ukuran data tidak cocok (cek datetime, panjang metode<=50, uang 12,2).");
            return;
        }
        if (ex instanceof java.sql.SQLSyntaxErrorException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: sintaks SQL bermasalah.");
            return;
        }
        if (ex instanceof java.sql.SQLTransientConnectionException
                || ex instanceof java.sql.SQLNonTransientConnectionException) {
            javax.swing.JOptionPane.showMessageDialog(this, ctx + " gagal: koneksi database terputus.");
            return;
        }
        javax.swing.JOptionPane.showMessageDialog(this, "Err (" + ctx + "): " + ex.getMessage());
    }

    private java.sql.Timestamp ts(String s) {
        return parseTimestamp(s);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        kembali = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 24)); // NOI18N
        jLabel1.setText("PEMBAYARAN");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(470, 10, 180, 30);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Id Pembayaran");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(30, 130, 100, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Tgl. Pembayaran");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(30, 170, 110, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Metode Pembayaran");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(30, 210, 140, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Jumlah Bayar");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(30, 250, 100, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Status Pembayaran");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(30, 290, 140, 20);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(40, 300, 0, 0);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1);
        jTextField1.setBounds(180, 130, 130, 30);
        getContentPane().add(jTextField2);
        jTextField2.setBounds(180, 170, 130, 30);

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3);
        jTextField3.setBounds(180, 210, 130, 30);
        getContentPane().add(jTextField4);
        jTextField4.setBounds(180, 250, 130, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LUNAS", "BELUM LUNAS" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(180, 290, 130, 30);

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(20, 370, 90, 23);

        jButton2.setText("Hapus");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(220, 370, 90, 23);

        jButton3.setText("Perbarui");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(120, 370, 90, 23);

        jButton4.setText("Muat Ulang");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(170, 420, 100, 23);

        kembali.setText("Kembali");
        kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(kembali);
        kembali.setBounds(60, 420, 100, 23);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id_Pembayaran", "Tgl_Pembayaran", "Metode_Pembayaran", "Jumlah_Bayar", "Status_Pembayaran"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(328, 41, 452, 440);

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\LENOVO\\Documents\\NetBeansProjects\\Solarwave\\src\\main\\resources\\View\\assets\\HALAMAN_SUPER_ADMIN_1.png")); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (busyUpdate) return; busyUpdate = true; jButton3.setEnabled(false);
        var errs = validateForUpdate();
        if (!errs.isEmpty()) { showErrors(errs); busyUpdate = false; jButton3.setEnabled(true); return; }

        try {
            int id = Integer.parseInt(jTextField1.getText().trim());
            java.sql.Timestamp tgl = ts(jTextField2.getText());
            String metode = jTextField3.getText().trim();
            java.math.BigDecimal jumlah = parseMoney(jTextField4.getText());
            String status = String.valueOf(jComboBox1.getSelectedItem());

            int okc = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Simpan perubahan untuk ID " + id + " ?",
                    "Konfirmasi", javax.swing.JOptionPane.YES_NO_OPTION);
            if (okc != javax.swing.JOptionPane.YES_OPTION) return;

            int upd = pembayaranDao.updateAdmin(id, tgl, metode, jumlah, status);
            javax.swing.JOptionPane.showMessageDialog(this, upd > 0 ? "Perbarui OK" : "Data tidak ditemukan");
            reloadTable();
        } catch (IllegalArgumentException v) {
            javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal", javax.swing.JOptionPane.WARNING_MESSAGE);
        } catch (Exception ex) {
            showSqlError(ex, "Perbarui");
        } finally {
            busyUpdate = false; jButton3.setEnabled(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembaliActionPerformed
        Menu_superadmin admin = new Menu_superadmin();
        admin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_kembaliActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (busyDelete) return; busyDelete = true; jButton2.setEnabled(false);
        try {
            int id = Integer.parseInt(jTextField1.getText().trim());
            int ok = javax.swing.JOptionPane.showConfirmDialog(
                    this, "Hapus pembayaran id " + id + " ?", "Konfirmasi",
                    javax.swing.JOptionPane.YES_NO_OPTION);
            if (ok != javax.swing.JOptionPane.YES_OPTION) return;

            int del = pembayaranDao.deleteAdmin(id);
            javax.swing.JOptionPane.showMessageDialog(this, del > 0 ? "Hapus OK" : "Data tidak ditemukan");
            reloadTable();
            clearFormForInsert();
        } catch (Exception ex) {
            showSqlError(ex, "Hapus");
        } finally {
            busyDelete = false; jButton2.setEnabled(true);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (busyAdd) return; busyAdd = true; jButton1.setEnabled(false);
    try {
        // 1) VALIDASI INPUT FORM DULU (tanpa bergantung ke ID Tagihan)
        var errs = validateForInsert();            // pastikan validateForInsert TIDAK mewajibkan Jumlah
        if (!errs.isEmpty()) { showErrors(errs); return; }

        // 2) MINTA FK SETELAH VALIDASI LULUS + PREFILL JUMLAH JIKA KOSONG
        Integer idTagihan = prefillJumlahFromTagihanIfEmpty();  // akan popup minta ID
        if (idTagihan == null) return;                          // batal / error ambil total

        String nik = askNikOptional();
        if (nik == null) return;
        if (nik.isEmpty()) nik = null;

        // 3) BACA FIELD & SIMPAN
        int nextId = pembayaranDao.nextId();
        java.sql.Timestamp tgl = ts(jTextField2.getText());
        String metode = jTextField3.getText().trim();
        java.math.BigDecimal jumlah = parseMoney(jTextField4.getText().trim());
        String status = String.valueOf(jComboBox1.getSelectedItem());

        int ok = pembayaranDao.insertAdmin(nextId, tgl, metode, jumlah, status, idTagihan, nik);
        javax.swing.JOptionPane.showMessageDialog(this, ok > 0 ? "Tambah OK" : "Gagal tambah (cek FK/unik)");
        reloadTable();
        clearFormForInsert();
    } catch (IllegalArgumentException v) {
        javax.swing.JOptionPane.showMessageDialog(this, v.getMessage(), "Validasi Gagal",
                javax.swing.JOptionPane.WARNING_MESSAGE);
    } catch (Exception ex) {
        showSqlError(ex, "Tambah");
    } finally {
        busyAdd = false; jButton1.setEnabled(true);
    }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       int yn = javax.swing.JOptionPane.showConfirmDialog(
                this, "Batalkan perubahan & muat ulang data?", "Muat Ulang",
                javax.swing.JOptionPane.YES_NO_OPTION);
        if (yn != javax.swing.JOptionPane.YES_OPTION) return;
        reloadTable();
        clearFormForInsert();
        javax.swing.JOptionPane.showMessageDialog(this, "Data dimuat ulang.");
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Menu_superadmin_pembayaran().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton kembali;
    // End of variables declaration//GEN-END:variables
}
